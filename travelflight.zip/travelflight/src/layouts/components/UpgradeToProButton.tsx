
// // ** React Import
// import { useState } from 'react'

// // ** MUI Imports
// import Box from '@mui/material/Box'
// import Fade from '@mui/material/Fade'
// import Paper from '@mui/material/Paper'
// import Button from '@mui/material/Button'
// // import Typography from '@mui/material/Typography'

// import dynamic from 'next/dynamic' // import the dynamic function from next/dynamic

// // Dynamically import the Typography component  
// const Typography = dynamic(() => import('@mui/material/Typography'), {
//   ssr: false // Set `ssr` option to `false` to prevent hydration errors
// })
// import CardContent from '@mui/material/CardContent'
// import CommentIcon from 'mdi-material-ui/Comment'
// // ** Third Party Imports
// import { usePopper } from 'react-popper'

// const BuyNowButton = () => {
//   // ** States
//   const [open, setOpen] = useState<boolean>(false)
//   const [popperElement, setPopperElement] = useState(null)
//   const [referenceElement, setReferenceElement] = useState(null)

//   const { styles, attributes, update } = usePopper(referenceElement, popperElement, {
//     placement: 'top-end'
//   })

//   const handleOpen = () => {
//     setOpen(true)
//     update ? update() : null
//   }

//   const handleClose = () => {
//     setOpen(false)
//   }

//   return (
//     <>
//     {/* <Box
//       className='upgrade-to-pro-button mui-fixed'
//       sx={{ right: theme => theme.spacing(20), bottom: theme => theme.spacing(10), zIndex: 11, position: 'fixed' }}
//     >
//       <Button
//         component='a'
//         target='_blank'
//         variant='contained'
//         onMouseEnter={handleOpen}
//         onMouseLeave={handleClose}
//         ref={(e: any) => setReferenceElement(e)}
//         href='https://themeselection.com/products/materio-mui-react-nextjs-admin-template/'
//         sx={{
//           backgroundColor: '#4b2088',
//           boxShadow: '0 1px 20px 1px #9155fd',
//           '&:hover': {
//             boxShadow: 'none',
//             backgroundColor: '#4b2088'
//           }
//         }}
//       >
//         <CommentIcon/>
//       </Button>
//       <Fade in={open} timeout={700}>
//         <Box
//           style={styles.popper}
//           ref={setPopperElement}
//           {...attributes.popper}
//           onMouseEnter={handleOpen}
//           onMouseLeave={handleClose}
//           sx={{ pb: 4, minWidth: theme => (theme.breakpoints.down('sm') ? 400 : 300) }}
//         >
//           <Paper elevation={9} sx={{ borderRadius: 1, overflow: 'hidden' }}>
//             <CardContent>
//               <Typography sx={{ mb: 4 }} variant='h6'>
//                 Next Travel support Center!
//               </Typography>
//               <Typography sx={{ mb: 4 }} variant='body2'>
//                 Please click on below links to take help from our support center.
//               </Typography>
//               <Typography sx={{ mb: 4 }} variant='body2'>
//                 We are happy to assist you.Please email at test@test.com in case of any assistance.
//               </Typography>
//               <Button
//                 component='a'
//                 sx={{ mr: 4 }}
//                 target='_blank'
//                 variant='contained'
//                 href='#'
//               >
//                 Need Help?
//               </Button>
//               <Button
//                 component='a'
//                 target='_blank'
//                 variant='outlined'
//                 href='#'
//               >
//                 Support Forum
//               </Button>
//             </CardContent>
//           </Paper>
//         </Box>
//       </Fade>
//     </Box> */}
//     </>
//   )
// }

// export default BuyNowButton
