import { FormControl, FormControlLabel, Grid, Radio, RadioGroup,Box,ListItemIcon, ListItem } from "@mui/material" 
import Image from 'next/image'; 
import * as React from 'react';
import { useTheme } from '@mui/material/styles';


const WalletPayment = () => {
    const [value, setValue] = React.useState('paytm');

    const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
      setValue((event.target as HTMLInputElement).value);
    };

    // let autoWidth:'auto';

    const theme = useTheme();
    
   return (
    <>
      <Grid container spacing={2} sx={{gap:'1rem 0rem'}} className='walletsBox'>
              <Grid item xs={12}>
              <FormControl fullWidth >
      {/* <FormLabel id="demo-controlled-radio-buttons-group">Gender</FormLabel> */}
      <RadioGroup
        aria-labelledby="demo-controlled-radio-buttons-group"
        name="controlled-radio-buttons-group"
        value={value}
        onChange={handleChange}
      >  
        <FormControlLabel value="paytm" 
        control={<Radio   
          sx={{'&.Mui-checked':{
          color:theme.palette.secondary.main
        }} 
      }
        />} label={
                  <Box sx={{ display: 'flex', alignItems: 'center' }}>  
                    <ListItem>Paytm(Wallet, Postpaid)</ListItem>
                    <ListItemIcon>
                      {/* <Payment /> */} 
                      <Image src="/images/logos/Paytm_logo_PNG1 1.png"  width={40} height={13} alt="Paytm Logo"/>
                    </ListItemIcon>
                  </Box>
                } />  
        <FormControlLabel value="freecharge"  
        control={<Radio  
          sx={{'&.Mui-checked':{
          color:theme.palette.secondary.main
        }} 
        }
        />} label={
                  <Box sx={{ display: 'flex', alignItems: 'center' }}>  
                    <ListItem>Freecharge(Wallet+Pay Later)</ListItem>
                    <ListItemIcon>
                      {/* <Payment /> */}
                      <Image src="/images/logos/freecharge-logo-icon1.svg" width={35}  height={35} alt="Freecharge Logo"/>
                    </ListItemIcon>
                  </Box>
                } /> 
        <FormControlLabel value="airtelmoney"  
        control={<Radio  
          sx={{'&.Mui-checked':{
          color:theme.palette.secondary.main
        }} 
        }
        />} label={
                  <Box sx={{ display: 'flex', alignItems: 'center' }}>  
                    <ListItem>Airtel Money</ListItem>
                    <ListItemIcon>
                    <Image src="/images/logos/airtel.png" width={35}  height={35} alt="Freecharge Logo"/>
                    </ListItemIcon>
                  </Box>
                } /> 

      </RadioGroup>
    </FormControl>
              </Grid>
      </Grid>
    </>
   )
}

export default WalletPayment