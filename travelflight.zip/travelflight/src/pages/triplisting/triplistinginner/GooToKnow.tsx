import React, {useEffect, useState} from 'react';

import { Typography, Table, TableBody, TableCell, TableHead, TableRow, TableContainer, Box , Button} from '@mui/material';
import { useTheme } from '@mui/material/styles';  
import { Error } from '@mui/icons-material' 

const GoodToKnow = () => {
    const theme = useTheme();


 return (
    <>
    <Box sx={{ padding: '1rem 1.5rem 2rem 1.5rem' }}>
     <Box>
        <Typography variant="h6" component="h1" gutterBottom  sx={{marginBottom:'0rem'}}>
           Good to Know
        </Typography>
        <Typography variant="subtitle2" sx={{ color:theme.palette.common.black, marginBottom:'1.5rem'}} gutterBottom>
        Information you should know
        </Typography>
        <Typography variant='body2'>
        Airline Cancellation Fee is Rs 3500 per passenger for your selected flight on the sector. <br/>Certify your health status through the Aarogya Setu app or the self-declaration form at the airport. <br/>Remember to web check-in baggage and entry before arriving at the airport treminal.<br/> Face masks are compulsory as per Aarogya Setu app OR COVID-19 Guidelines. 
        </Typography>
    </Box>
   <Box sx={{ border: '1px solid #ddd', padding: '16px', marginTop: '2rem', display:'flex' }}>
   <Typography variant="body2" sx={{color:theme.palette.error.dark,fontWeight:'500',minWidth:'6rem'}}>
        <Error/>
   </Typography>
   <Box> 
   <Typography variant="subtitle2" sx={{ color:theme.palette.common.black,}} gutterBottom>
      COVID-19 information
    </Typography>
   <Typography variant='body2'>
     Please check your itinerary, including layovers, for travel restrictions prior to booking. A displayed itinerary is not confirmation of your eligibility to travel.
   </Typography>
   
    </Box>
 </Box>
 </Box>
    </>
 )
}

export default GoodToKnow