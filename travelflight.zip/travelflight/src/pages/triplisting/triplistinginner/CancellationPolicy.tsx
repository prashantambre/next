import React, {useEffect, useState} from 'react';

import { Typography, Table, TableBody, TableCell, TableHead, TableRow, TableContainer, Box , Button} from '@mui/material';
import { useTheme } from '@mui/material/styles';  
import { Flight } from '@mui/icons-material' 
import { useQuery } from '@apollo/client'
import { gql } from '@apollo/client'


const CANCELLATION_QUERY = gql`
  query CancellationRows {
    cancellationRows {
       id
       timeFrame
       fee
    }
  }
`

interface CancellationRows {
  id:number
  timeFrame:string
  fee:string
}

interface CancellationRowsData {
  cancellationRows: CancellationRows[]
}




const CancellationPolicy = () => {
    const theme = useTheme();
     
    // const cancellationRows = [
    //   { timeFrame: '0 hours to 4 hours', fee: 'Adult: Non Refundable' },
    //   { timeFrame: '0 hours to 365 days', fee: 'Adult: ₹1000' },
    //   // Add more rows as needed
    // ];
  

    const [ cancellationRows, setCancellationRows] = React.useState<CancellationRowsData["cancellationRows"]>([]);
    


    const { loading,  data } = useQuery<CancellationRowsData>(CANCELLATION_QUERY);
    React.useEffect(() =>{
      if(!loading && data){
        setCancellationRows(data.cancellationRows) 
      }
    }, [loading, data])

    

 return (
    <>
    <Box sx={{ padding: '1rem 1.5rem 2rem 1.5rem' }}>
        <Typography variant="h6" component="h1" gutterBottom sx={{marginBottom:'1.5rem'}}>
          Cancellation policy
        </Typography>

    <Button variant="outlined"
        sx={{
         '&.MuiButton-root':{
            color:theme.palette.secondary.light,
            borderColor:theme.palette.secondary.light,
           padding:'5px 10px 5px',
         },
         '&.MuiButton-root :hover':{
           background:'transparent'
         }
       }}
        
        >
         DEL
              <Flight
                 sx={{
                   rotate: '-90deg',
                   marginRight:'10px',
                   position: 'relative',
                   left: '4px',
                   top: '0px',
                   fontSize: '1.25rem'
                 }}
               /> MUM</Button>
     <TableContainer className="customTable cancelPolicy" sx={{ marginTop: '1rem' }}>
          <Table aria-label="simple table">
            <TableHead>
              <TableRow>
                <TableCell className="timeFrame left">
                  <Typography variant="button" sx={{ textTransform: 'capitalize', color: theme.palette.common.black }} display="block" gutterBottom>
                    Time frame
                  </Typography>
                  <Typography variant="body2" sx={{ textTransform: 'capitalize' }} gutterBottom>
                    Duration(From Scheduled flight departure)
                  </Typography>
                </TableCell>
                <TableCell className="timeFrame right">
                  <Typography variant="button" sx={{ textTransform: 'capitalize', color: theme.palette.common.black }} display="block" gutterBottom>
                    Airline Cancellation fee
                  </Typography>
                  <Typography variant="body2" sx={{ textTransform: 'capitalize' }} gutterBottom>
                    (Per passenger)
                  </Typography>
                </TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {cancellationRows.map((row, index) => (
                <TableRow key={index}>
                  <TableCell className="timeFrame">{row.timeFrame}</TableCell>
                  <TableCell className="timeFrame">{row.fee}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>

   <Box sx={{ border: '1px solid #ddd', padding: '16px', marginTop: '16px', display:'flex' }}>
   <Typography variant="body2" sx={{color:theme.palette.error.dark,fontWeight:'500',minWidth:'6rem'}}>
     Please note:  
   </Typography>
   <Typography variant='body2'>
     The airline fee is indicative. Genie service fee is over and above the airline cancellation fee due to which -- refund type may vary.
   </Typography>
 </Box>
 </Box>
    </>
 )
}

export default CancellationPolicy