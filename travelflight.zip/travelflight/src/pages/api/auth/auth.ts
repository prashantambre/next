// import { NextResponse,NextRequest } from 'next/server'
// import env from '../../../env.json';

// // import {SignJWT, jwtVerify, type JWTPayload} from 'jose';

// import {SignJWT, jwtVerify,} from 'jose';

// // import { getCookies, getCookie, setCookie, deleteCookie } from 'cookies-next';

// import { setCookie, deleteCookie } from 'cookies-next';

// const secretKey = env.secret;
// const iat = Math.floor(Date.now() / 1000);
// const exp = iat + 60 * 60 * 24; // one day

// const login = async (req: NextRequest, res: NextResponse) => {
    
//     const {email,password} = req.body
//     const data = {
//             "email_id": email,
//             "password": password
//     }

//     const authLogin = await fetch("http://localhost:8001/api/login", {
//         method: 'POST',
//         body: JSON.stringify(data),
//         headers: { "Content-Type": "application/json" }
//     }).then((t)=> t.json())

//     if (authLogin.jwt) {
//         const token = await new SignJWT({
//             "emailId":email,
//             token: authLogin.jwt
//         })
        
//         .setProtectedHeader({alg: 'HS256', typ: 'JWT'})
//         .setExpirationTime(exp)
//         .setIssuedAt(iat)
//         .setNotBefore(iat)
//         .sign(new TextEncoder().encode(secretKey));
//         //set token cookie to check if user is logged in
//         setCookie('token', token, { req, res, maxAge: 60 * 60 * 24,httpOnly: true })
//         res.status(200).json({
//             status:true,
//             message: 'Success'
//         })
//     }else{
//         res.status(401).json({ status: false,'message':authLogin.data})
//     }
// }

// export const register = async (req: NextRequest, res: NextResponse) => {
//     const {email,password} = req.body
//     const data = {
//             "email_id": email,
//             "password": password
//     }

//     const authLogin = await fetch("http://localhost:8001/api/register", {
//         method: 'POST',
//         body: JSON.stringify(data),
//         headers: { "Content-Type": "application/json" }
//     }).then((t)=> t.json())
//     if (authLogin.jwt) {
//         // res.json({
//         //     token:jwt.sign({
//         //         email,
//         //         token: authLogin.jwt
//         //     },
//         //     KEY)
//         // })
//     }else{
//         //res.status(authLogin.status).json(authLogin.data)
//     }
// }

//check if user is authenticated via passing request SSR used in middleware
// export const isAuthenticated = async (req: NextRequest) => {
//     const jsWebToken = req.cookies.get('token')
//     if(!jsWebToken){
//         return false;
//     }
//     const { payload, protectedHeader }  = await jwtVerify(jsWebToken, new TextEncoder().encode(secretKey));
//     if(payload.token && iat < payload.exp){
//         return true;
//     }else{
//         //destroy cookie and return false
//         deleteCookie('token', { req, res });
//         return false;
//     }
// }

//check if user is authenticated via passing cookie token from SSR used in login and registeration
// export const isClientAuth = async (jsWebToken:any) => {

//     if(!jsWebToken){
//         return Promise.resolve(false);
//     }
//     const { payload, protectedHeader }  = await jwtVerify(jsWebToken, new TextEncoder().encode(secretKey));
//     if(payload.token && iat < payload.exp ){
//         return Promise.resolve(true);
//     }else{
//         //destroy cookie and return false
//         deleteCookie('token');
//         return Promise.resolve(false);
//     }
// }
  
// export default login
