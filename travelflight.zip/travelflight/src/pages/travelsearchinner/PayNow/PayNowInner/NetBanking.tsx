import { useState } from 'react';
import { FormControl, FormControlLabel,  Grid, Radio, RadioGroup, Box, ListItemIcon, ListItem, InputAdornment, TextField } from '@mui/material';
import {  Search } from '@mui/icons-material';
import Image from 'next/image';
import * as React from 'react';
import { useTheme } from '@mui/material/styles';


const NetBanking = () => {
  const [value, setValue] = React.useState('paytm');
  const [searchTerm, setSearchTerm] = useState('');

  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setValue((event.target as HTMLInputElement).value);
  };

  const handleSearchChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(event.target.value);
  };

  const filteredOptions = [
    {
      value: 'paytm',
      label: 'Paytm(Wallet, Postpaid)',
      logo: '/images/logos/Paytm_logo_PNG1 1.png'
    },
    {
      value: 'freecharge',
      label: 'Freecharge(Wallet+Pay Later)',
      logo: '/images/logos/freecharge-logo-icon1.svg'
    },
    {
      value: 'airtelmoney',
      label: 'Airtel Money',
      logo: '/images/logos/airtel.png'
    }
  ].filter(option =>
    option.label.toLowerCase().includes(searchTerm.toLowerCase())
  );
   const theme = useTheme();
   
  return (
    <>
      <Grid container spacing={2} sx={{ gap: '1rem 0rem' }} className='walletsBox'>
        <Grid item xs={12}>
          <FormControl fullWidth> 
                 <TextField
                     className='boxShadowBox'
                     placeholder='Search your bank'
                     size="small"
                     value={searchTerm}
                     onChange={handleSearchChange}
                     InputProps={{
                        startAdornment: (
                          <InputAdornment position="start">
                            <Search />
                          </InputAdornment>
                        )
                        }}
                    sx={{
                      '& .MuiOutlinedInput-notchedOutline': {
                        borderColor: 'rgba(58, 53, 65, 0.32)',
                        borderWidth: '1px',
                        boxShadow: 'none',
                         border: 'none'
                      },
                      '&:hover .MuiOutlinedInput-notchedOutline': {
                        borderColor: 'rgba(58, 53, 65, 0.32)',
                        borderWidth: '1px'
                      },
                      '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                        borderColor: 'rgba(58, 53, 65, 0.32)',
                        borderWidth: '1px'
                      }

                    }}
                  />
          </FormControl>
        </Grid>
        <Grid item xs={12}>
          <FormControl fullWidth>
            {/* <FormLabel id="demo-controlled-radio-buttons-group">Payment Method</FormLabel> */}
            <RadioGroup
              aria-labelledby="demo-controlled-radio-buttons-group"
              name="controlled-radio-buttons-group"
              value={value}
              onChange={handleChange}
            >
              {filteredOptions.map(option => (
                <FormControlLabel
                  key={option.value}
                  value={option.value}
                  control={<Radio 
                       
                      sx={{'&.Mui-checked':{
                      color:theme.palette.secondary.main
                    }} 
                  }
                  />}
                  label={
                    <Box sx={{ display: 'flex', alignItems: 'center' }}>
                      <ListItem>{option.label}</ListItem>
                      <ListItemIcon>
                        <Image src={option.logo} width={35} height={35} alt={`${option.label} Logo`} />
                      </ListItemIcon>
                    </Box>
                  }
                />
              ))}
            </RadioGroup>
          </FormControl>
        </Grid>
      </Grid>
    </>
  );
}

export default NetBanking;
