import English from './en.json';
import Dutch from './nl.json';

export const useLang = (locale) => {
    switch (locale) {
      case 'en':
        return English;
        break;
      case 'nl':
        return Dutch;
        break;
      default:
        return English;
        break;
    }
  };
  
export default useLang