

// ** MUI Imports

import { Card  } from '@mui/material'

// import Typography from '@mui/material/Typography'

// ** Demo Components Imports 

import FlightResultform from './FlightResultform'
import FilterSection from './FilterSection'
import FlightResultData from './FlightResultData'

const TravelInner = () => {
  return (
    <>
    <Card sx={{p:4}}>   
      <FlightResultform/>
      <FilterSection/>
      <FlightResultData/>
    </Card>
    </>
  )
}

export default TravelInner
