
import * as React from "react";

// import Card from '@mui/material/Card';
// import Typography from '@mui/material/Typography';

import CardHeader from '@mui/material/CardHeader';
import CardContent from '@mui/material/CardContent';

// import FormGroup from '@mui/material/FormGroup';
// import FormControlLabel from '@mui/material/FormControlLabel';
// import Checkbox from '@mui/material/Checkbox';
// import Box from '@mui/material/Box';

import Stack from "@mui/material/Stack";
import ToggleButton from "@mui/material/ToggleButton";
import ToggleButtonGroup from "@mui/material/ToggleButtonGroup";






interface AirportClassProps {
  onAlignmentChange: (newAlignment: string) => void;
}

const AirportClass = ({ onAlignmentChange }: AirportClassProps) => {
  const storedAlignment = localStorage.getItem('alignment');
  const [selectedClasses, setSelectedClasses] = React.useState<string[]>(
    storedAlignment ? JSON.parse(storedAlignment) : []
  );

  const handleChange = (
    event: React.MouseEvent<HTMLElement>,
    newAlignment: string
  ) => {
    // Convert the newAlignment to lowercase
    const lowerCaseAlignment = newAlignment.toLowerCase();

    // Check if the selected class is already in the array
    const isSelected = selectedClasses.includes(lowerCaseAlignment);

    const updatedClasses = isSelected
      ? selectedClasses.filter((item) => item !== lowerCaseAlignment)
      : [...selectedClasses, lowerCaseAlignment];

    setSelectedClasses(updatedClasses);
    onAlignmentChange(updatedClasses.join(' ')); // Pass the comma-separated string to the parent component

    // Store the updated classes in localStorage as lowercase
    storeSelectedClasses(updatedClasses);
  };

  // Custom function to store the selected classes in localStorage as lowercase
  const storeSelectedClasses = (classes: string[]) => {
    localStorage.setItem('alignment', JSON.stringify(classes.map((cls) => cls.toLowerCase())));
  };

  const children = [
    <ToggleButton value="economy" key="economy" sx={{marginRight:'10px'}}>
      Economy
    </ToggleButton>,
    <ToggleButton value="premium" key="premium" sx={{marginRight:'10px'}}> 
      Premium
    </ToggleButton>,
    <ToggleButton value="business" key="business" sx={{marginRight:'10px'}}>
      Business
    </ToggleButton>,
    <ToggleButton value="firstclass" key="firstclass" sx={{marginRight:'10px'}}>
      Firstclass
    </ToggleButton>
  ];

  const control = {
    value: selectedClasses,
    onChange: handleChange,
    exclusive: true
  };

  return (
    <>
      <CardHeader
        title="Class"
        sx={{
          paddingBottom: 1,
          textTransform: 'uppercase'
        }}
      />
      <CardContent sx={{ pt: (theme) => `${theme.spacing(3)} !important` }}>
        <Stack spacing={2} alignItems="left">
          <ToggleButtonGroup
            size="small"
            {...control}
            aria-label="Small sizes"
            sx={{ display: 'block' }}
          >
            {children}
          </ToggleButtonGroup>
        </Stack>
      </CardContent>
    </>
  );
};

export default AirportClass;