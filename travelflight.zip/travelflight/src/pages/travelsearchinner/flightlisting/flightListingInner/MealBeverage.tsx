import * as React from 'react';
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import Box from '@mui/material/Box';
import { useTheme, } from '@mui/material'

import {Flight} from '@mui/icons-material'
import MealBeverageInner from './MealBeverageInner';

interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}

function CustomTabPanel(props: TabPanelProps) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && (
        <>
          {children}
        </>
      )}
    </div>
  );
}

function a11yProps(index: number) {
  return {
    id: `simple-tab-${index}`,
    'aria-controls': `simple-tabpanel-${index}`,
  };
}

const MealBeverage = () => {
  const theme = useTheme()

  const [value, setValue] = React.useState(0);

  const handleChange = (event: React.SyntheticEvent, newValue: number) => {
    setValue(newValue);
  };

  return (
    <Box sx={{ width: '100%' }}>
      <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
        <Tabs value={value} onChange={handleChange} 
           sx={{
            backgroundColor: '#fff',
            width: 'fit-content',
            borderRadius: '0px', 
            paddingBottom:'1rem',
            display:'block',
            '& .MuiTabs-indicator': { display: 'none' },
            '& .Mui-selected': { backgroundColor: theme.palette.common.black, borderRadius: '6px', display:'block' }
          }}
        >
          <Tab 
            label={
                <>
                  MUM
                  <Flight
                    sx={{
                      rotate: '90deg',
                      marginRight: '10px',
                      position: 'relative',
                      left: '4px',
                      top: '5px',
                      fontSize: '1.25rem',
                    }}
                  />
                  DEL
               </>
              }
          
          {...a11yProps(0)}
          sx={{
            minHeight: 'auto',
            paddingTop: '5px',
            paddingBottom: '10px',
            textTransform:'capitalize',
            display:'block',
            '&.Mui-selected': { color: theme.palette.common.white, dispaly:'block' }
          }}
          />
          <Tab 
          
          label={
              <>
              Del
              <Flight
                sx={{
                  rotate: '90deg',
                  marginRight: '10px',
                  position: 'relative',
                  left: '4px',
                  top: '5px',
                  fontSize: '1.25rem',
                }}
              />
              Mum
              </>
          }


          {...a11yProps(1)}
           sx={{
            minHeight: 'auto',
            paddingTop: '5px',
            paddingBottom: '10px',
            textTransform:'capitalize',
            display:'block',
            '&.Mui-selected': { color: theme.palette.common.white, dispaly:'block' }
          }}
          /> 
        </Tabs>
      </Box>
      <CustomTabPanel value={value} index={0}>
         <MealBeverageInner/>
      </CustomTabPanel>
      <CustomTabPanel value={value} index={1}>
      <MealBeverageInner/>
      </CustomTabPanel>
   
    </Box>
  );
}


export default MealBeverage