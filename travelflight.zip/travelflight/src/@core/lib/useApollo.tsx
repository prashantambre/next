
import { ApolloClient, NormalizedCacheObject } from "@apollo/client";
import { client } from "./apolloClient";

let apolloClient: ApolloClient<NormalizedCacheObject>;

function createApolloClient() {
  return client;
}

export function useApollo(pageProps: any) {
  const _apolloClient = apolloClient ?? createApolloClient();

  if (pageProps) {
    _apolloClient.cache.restore(pageProps.initialApolloState);
  }

  if (!apolloClient) {
    apolloClient = _apolloClient;
  }

  return _apolloClient;
}