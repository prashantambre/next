
import React, { useEffect } from "react";

import { ExpandMore } from "@mui/icons-material";
import { Accordion, AccordionDetails, AccordionSummary, Card, Divider, Grid, Typography,Box } from "@mui/material";
import { useState } from "react";
import TravelerDetails from "./flightListingInner/TravelerDetails";
import TotalFare from "./flightListingInner/TotalFare";

// import PromoCode from "./flightListingInner/PromoCode";

import FlightDetails from "./flightListingInner/FlightDetails";
import ModeOutlinedIcon from '@mui/icons-material/ModeOutlined';
import { useTheme } from '@mui/material/styles'
import MealBeverage from "./flightListingInner/MealBeverageInner";
import SelectBaggage from "./flightListingInner/SelectBaggageInner";
import SeatSelection from "./flightListingInner/SeatSelection";




const FlightListing = () => {
    const [expanded, setExpanded] = useState<string | false>(false);

    const [dataFromChild, setDataFromChild] = useState('');
    const handleDataFromChild = (data) => { 
      setDataFromChild(data);
    };

    const [dataFromChildBaggage, setDataFromChildBaggage] = useState('');
    const handleDataFromChildBaggage = (data) => { 
      setDataFromChildBaggage(data);
    };

    const [dataFromChildMeal, setDataFromChildMeal] = useState('');
    
    const [dataFromChildSeat, setDataFromChildSeat] = useState([]);
    

    const handleDataFromChildMeal = (data) => { 
      setDataFromChildMeal(data);
     
    };

    const handleUpdateId = (updateId) => {
      console.log(updateId);
      // You can now use the 'updateId' value here in index.tsx
      setDataFromChildSeat(updateId)
      // Perform any other actions you need with 'updateId'
    };

    


  const handleChange =
    (panel: string) => (event: React.SyntheticEvent, isExpanded: boolean) => {
      setExpanded(isExpanded ? panel : false);
    };
    useEffect(() => {
      // You can also set the initial state here
      setExpanded("panel3"); 
    }, []);
    const travelerNames = ['Oliver James', 'John Doe', 'Alice Smith', 'Bob Johnson', 'Bob Johnsons'];


    const theme = useTheme()

    return(
        <>
        <Grid container spacing={6}>
            <Grid item sm={8} xs={12}>
            <Card>   
        <Accordion expanded={expanded === 'panel1'} onChange={handleChange('panel1')}>
        <AccordionSummary 
          expandIcon={ 
          <ExpandMore sx={{
            '&.MuiSvgIcon-root':{
              color:'rgba(58, 53, 65, 0.54)'
            },
            
          }}
          />
          }
          aria-controls="panel1bh-content"
          id="panel1bh-header"
          sx={{minHeight:'4.063rem'}}
        > 
          <Box>
          <Typography variant="h6" component="h1" gutterBottom>
           Flight details  
          </Typography> 
          <Typography variant="subtitle2" gutterBottom>
            {dataFromChild}
            </Typography>
          </Box>
        </AccordionSummary>
        <AccordionDetails>
           <FlightDetails  onDataUpdate={handleDataFromChild}  />  
        </AccordionDetails>
      </Accordion>
      </Card>
      <Card sx={{mt:4,overflow:'visible'}} >
      <Accordion expanded={expanded === 'panel2'} onChange={handleChange('panel2')}>
        <AccordionSummary
          expandIcon={<ModeOutlinedIcon 
            sx={{
            '&.MuiSvgIcon-root':{
             color:theme.palette.primary.light
            }
          }}/>}
          aria-controls="panel2bh-content"
          id="panel2bh-header"
          sx={{minHeight:'4.063rem'}}
        >
          <Box>
          <Typography  variant="h6" component="h1" gutterBottom>
          Traveler details
          </Typography>

          <Typography variant="subtitle2" gutterBottom>
          {travelerNames.length > 0 ? (
    <>
      {travelerNames.slice(0, 2).map((name, index) => (
        <React.Fragment key={index}>
          {name}
          {index < 1 && ', '}
        </React.Fragment>
      ))}
      {/* {travelerNames.length > 2 && `, +${travelerNames.length - 2} more`} */}
      {travelerNames.length > 2 && (
        <span style={{ color: theme.palette.primary.light }}>
          , +{travelerNames.length - 2} more
        </span>
      )}
    </>
  ) : (
    'No travelers'
  )}
      </Typography>
      </Box>

        </AccordionSummary>
        <Divider sx={{mt:0}}/>
        <AccordionDetails >
        {/* <TravelerDetails travelerName="Oliver James" initialExpanded={true} />
         <TravelerDetails travelerName="John Doe" initialExpanded={false} /> */}
            {travelerNames.map((name, index) => (
              <TravelerDetails key={index} travelerName={name} initialExpanded={index === 0} />
            ))}
        </AccordionDetails>
      </Accordion>
      </Card>
      <Card sx={{mt:4}}>
      <Accordion expanded={expanded === 'panel3'} onChange={handleChange('panel3')}>
        <AccordionSummary
          expandIcon={<ExpandMore />}
          aria-controls="panel3bh-content"
          id="panel3bh-header"
          sx={{minHeight:'4.063rem'}}
        > 
          <Box>
          <Typography  variant="h6" component="h1" gutterBottom>
           Seat selection(Optional)
          </Typography>
        
          <Typography variant="subtitle2" gutterBottom>
            Departure:
            <Box sx={{display:'flex'}} className="seatIdboxSummary">
            {dataFromChildSeat.map((item, index) => (
            <Typography key={index} variant="subtitle2" gutterBottom>
            <span className='dot'>.</span> {item}
            </Typography>
            ))}
             
            </Box>
            </Typography>
            </Box>

        </AccordionSummary>
        <AccordionDetails>
            <SeatSelection onSeatUpdate={handleUpdateId}/>
        </AccordionDetails>
      </Accordion>
      </Card>
      <Card sx={{mt:4}}>
      <Accordion expanded={expanded === 'panel4'} onChange={handleChange('panel4')}>
        <AccordionSummary
          expandIcon={<ExpandMore/>}
          aria-controls="panel4bh-content"
          id="panel4bh-header"
          sx={{minHeight:'4.063rem'}}
        >
          {/* <Typography sx={{ width: '33%', flexShrink: 0 }} variant="h6" component="h1">Meals-beverage(Optional)</Typography>
          <Typography variant="subtitle2" gutterBottom>
            {dataFromChildMeal}
            </Typography> */}


            <Box>
          <Typography  variant="h6" component="h1" gutterBottom>
          Meals-beverage(Optional)
          </Typography>
        
          <Typography variant="subtitle2" gutterBottom>
            Departure:
            <Box sx={{display:'flex'}}>
              {dataFromChildMeal}
            </Box>
            </Typography>
            </Box>

            
        </AccordionSummary>
        <AccordionDetails>
             <MealBeverage onDataUpdateMeal={handleDataFromChildMeal}/>
        </AccordionDetails>
      </Accordion>
        </Card> 

        <Card sx={{mt:4}}>
      <Accordion expanded={expanded === 'panel5'} onChange={handleChange('panel5')}>
        <AccordionSummary
          expandIcon={<ExpandMore/>}
          aria-controls="panel4bh-content"
          id="panel4bh-header"
          sx={{minHeight:'4.063rem'}}
        >
           <Box>
          <Typography  variant="h6" component="h1" gutterBottom>
            Select baggage(Optional)
          </Typography>
        
          <Typography variant="subtitle2" gutterBottom>
            Departure:
            <Box sx={{display:'flex'}}>
              Additional {dataFromChildBaggage}
            </Box>
            </Typography>
            </Box>
        </AccordionSummary>
        <AccordionDetails>
             <SelectBaggage onDataUpdateBaggage={handleDataFromChildBaggage} /> 
             {/* <SelectBaggage /> */}
        </AccordionDetails>
      </Accordion>
        </Card> 

            </Grid>
            <Grid item sm={4} xs={12}>
              <TotalFare/>   
              {/* <PromoCode/> */}
            </Grid>
        </Grid>
       
        </>
    )
}
export default FlightListing;
