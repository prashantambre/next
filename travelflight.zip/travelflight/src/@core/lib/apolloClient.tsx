import { ApolloClient, InMemoryCache } from "@apollo/client";

import { CreditCard, Sell} from '@mui/icons-material';


// export const client = new ApolloClient({ 
//   uri:"https://countries.trevorblades.com/",
//   cache: new InMemoryCache(),
// }); 

// Define the static data for a list of countries
const countriesData = {
  countries: [
    {
      name: "United Statese",
      code: "US",
      emoji: "🇺🇸",
    },
    {
      name: "Canada",
      code: "CA",
      emoji: "🇨🇦",
    },
    {
      name: "Mexico",
      code: "MX",
      emoji: "🇲🇽",
    },
    {
      name: "United Kingdom",
      code: "GB",
      emoji: "🇬🇧",
    },
    {
      name: "France",
      code: "FR",
      emoji: "🇫🇷",
    },
  ],
};

const usersData = {
  users: [
    {
      id: "1",
      name: "Alice",
    },
    {
      id: "2",
      name: "Bob",
    },
    {
      id: "3",
      name: "Charlie",
    },
  ],
};

const languageData = {
  languages: [
    {
      id: "1",
      name: "English",
      flag: 'US',
    },
    {
      id: "2",
      name: "Dutch",
      flag: 'NL',
    },
  ],
};

const currencyData = {
  currencies: [
    {
      id: "1",
      name: "EUR",
      icon: "USD",
     
    },
    {
      id: "2",
      name: "GBP",
      icon: "INR",
      
    },
  ],
};

const walletData = {
  walletamount: [
    {
      id: "1",
      amount: 10000,
      icon: "INR",
    }
  ],
};

const notificationsData = {
  notifications: [
    {
       id:"1",
       title:"Congratulation Flora!",
       description:"Won the monthly best seller badge",
       image:"http://localhost:3000/images/avatars/1.png",
       date:"Today"
    },
    {
     id:"2",
     title:"Congratulation Flora!",
     description:"Won the monthly best seller badge",
     image:"http://localhost:3000/images/avatars/1.png",
     date:"Yesterday"
   },
   {
     id:"3",
     title:"Congratulation Flora!",
     description:"Won the monthly best seller badge",
     image:"http://localhost:3000/images/avatars/1.png",
     date:"11 Aug"
  },
  {
   id:"4",
   title:"Congratulation Flora!",
   description:"Won the monthly best seller badge",
   image:"http://localhost:3000/images/avatars/1.png",
   date:"25 May"
  },
  {
   id:"5",
   title:"Congratulation Flora!",
   description:"Won the monthly best seller badge",
   image:"http://localhost:3000/images/avatars/1.png",
   date:"19 Mar"
  },
  {
   id:"6",
   title:"Congratulation Flora!",
   description:"Won the monthly best seller badge",
   image:"http://localhost:3000/images/avatars/1.png",
   date:"13 May"
  },
  ],
};

const airtportsData={
 top100Films : [
  { 
    cityName: 'Mumbai', 
    airportName:'Chhatrapati Shivaji International Airport',
    country:'India',
    countryCode: 'IN'
   },
  { 
    cityName: 'New Delhi', 
    airportName:'Indira Gandhi International Airport',
    country:'India',
    countryCode: 'IN'
  },
  { 
    cityName: 'Bangkok', 
    airportName:'Bangkok',
    country:'Thailand',
    countryCode: 'TH'
  },
  { 
    cityName: 'Bengaluru', 
    airportName:'Bengaluru International Airport',
    country:'India',
    countryCode: 'IN'
  },
  { 
    cityName: 'Hyderabad', 
    airportName:'Rajiv Gandhi International Airport',
    country:'India',
    countryCode: 'IN'
  },
  { 
    cityName: 'Kolkata', 
    airportName:'Netaji Subhash Chandra Bose International Airport',
    country:'India',
    countryCode: 'IN'
  },
  { 
    cityName: 'Chennai', 
    airportName:'Chennai International Airport',
    country:'India',
    countryCode: 'IN'
  },
  
],
};

const selectUserData={
  usersClient : [
   { 
     name: 'Rosh Williams', 
     emailId: 'Rosh@geniebazaar.com'
    },
   { 
    name: 'John Doe', 
    emailId: 'John@geniebazaar.com'
   }
 ],
 };

const airlinesData = {
    airlineNames : [
      {
         name:'Air India'
      },
      {
        name:'AirAsia(India)'
      },
      {
        name:'Ethiopian'
      },
      {
        name:'FlexFlight'
      },
      {
        name:'Go FIRST'
      },
      {
        name:'IndiGo'
      },
      {
        name:'Oman Air'
      }
    ]
};
const stopsData = {
  stops : [
    {
       name:'Any number of stops'
    },
    {
      name:'Nonstop only'
    },
    {
      name:'1 stop or fewer'
    },
    {
      name:'2 stops or fewer'
    }
  ]
};
const refundabilityData = {
  refunds : [
    {
       type:'Any number of stops'
    },
    {
      type:'Nonstop only'
    },
    {
      type:'1 stop or fewer'
    }
  ]
};
const emissionsData = {
  emissions : [
    {
      type:'Any emissions'
    },
    {
      type:'Less emissions only'
    }, 
  ]
}
const policiesData = {
  policies : [
    {
      type:'In Policy'
    },
    {
      type:'Out of Policy'
    }, 
    {
      type:'No Preference'
    }, 
  ]
}
const priceData = {
  prices : [
    {
      type:'One way price'
    },
    {
      type:'Two way price'
    }, 
  ]
}

const flightDurationData = {
  durations: {
    type: 'Flight Duration',
    max: 40,
    marks: [
      { value: 0, label: '0' },
      { value: 5, label: '5' },
      { value: 10, label: '10' },
      { value: 15, label: '15' },
      { value: 20, label: '20' },
      { value: 25, label: '25' },
      { value: 30, label: '30' },
      { value: 35, label: '35' },
      { value: 40, label: '40' },
    ],
  },
};

const flightDetailsData = {
  flightDetails : [
    {
      name:'Air India',
      arrivalTime:'00.45 AM',
      arrivalPlace:'MUM',
      timeDuration:'2HRS',
      stopDuration:'1-stop',
      departureTime:'01.45 AM',
      departurePlace:'DEL',
      weight:'83kgCO2',
      amount:'5,777',
      day:'Wednesday',
      date:'19 Apr'
    },
    {
      name:'Air India',
      arrivalTime:'01.45 AM',
      arrivalPlace:'DEL',
      timeDuration:'2HRS',
      stopDuration:'2-stop',
      departureTime:'03.45 AM',
      departurePlace:'MUM',
      weight:'82kgCO2',
      amount:'6,777',
      day:'Thusday',
      date:'18 Apr'
    }
  ]
};


const upcomingTripsData = {
  upcomingTrips : [
    {
      title: 'Trip to Goa',
      date: '30 Jan - 31 Jan',
    },
    {
      title: 'Trip to Dubai',
      date: '1 Jan - 3 Jan',
    },
    {
      title: 'Trip to Delhi',
      date: '4 Feb - 10 Feb',
    },
    
  ]
};


const pendingRequestData = {
  pendingRequest : [
    {
      tripId: 'E40',
      travelerDetails: 'Rupesh T (Primary)',
      date:'30th Jan - 31 Jan',
      dastination:'Mumbai, Maharashtra, India', 
      tripPurpose:'Client Meeting',
      tripPurposeDescription: 'New location proposal client and dealings...',
      amount:1000

    },
    {
      tripId: 'E41',
      travelerDetails: 'Rahul T (Primary) ',
      date:'23th Feb - 28 Feb',
      dastination:'Pune, Maharashtra, India', 
      tripPurpose:'Client Meeting',
      tripPurposeDescription: 'New location proposal client and dealings...',
      amount:3000

    },
    {
      tripId: 'E42',
      travelerDetails: 'Rohit T (Primary)',
      date:'28th March - 29 March',
      dastination:'Delhi, Maharashtra, India', 
      tripPurpose:'Client Meeting',
      tripPurposeDescription: 'New location proposal client and dealings...',
      amount:2000

    },
    
  ]
};


const promoCodesData = {
  promoCodes :[ {
    code: "MMTYESEMI",
    discount: "Get INR 245 instant discount on your Yes Bank Credit Card No Cost EMI",
    icon: <CreditCard />,
    offer: 245
  },
  {
    code: "BOOKINSTANT",
    discount: "Use this coupon and get Rs 300 instant discount on your flight booking",
    icon: <Sell />,
    offer: 300
  },

  
]
};


const selectBaggageData = {
  selectBaggage :[  {
    id:1,
    weight: '15 kg',
    price: 200,
  },
  {
    id:2,
    weight: '18 kg',
    price: 200,
  },
  {
    id:3,
    weight: '14 kg',
    price: 300,
  },
  {
    id:4,
    weight: '19 kg',
    price: 140,
  },
  {
    id:5,
    weight: '21 kg',
    price: 100,
  },
  {
    id:6,
    weight: '20 kg',
    price: 190,
  },
 
]
};

const mealBeverageData = {
  mealBeverage :[   {
    id:1,
    type: 'non-veg',
    name: 'Chicken Cheese Sandwich',
    price: 1335,
  },
  {
    id:2,
    type: 'veg',
    name: 'Panner Cheese Sandwich',
    price: 1135,
  },
  {
    id:3,
    type: 'non-veg',
    name: 'Chicken Cheese Sandwich',
    price: 1235,
  },
  {
    id:4,
    type: 'veg',
    name: 'Paneer Cheese Sandwich',
    price: 1435,
  },
  {
    id:5,
    type: 'non-veg',
    name: 'Chicken Cheese Sandwich',
    price: 1035,
  },
  {
    id:6,
    type: 'veg',
    name: 'Cheese Sandwich',
    price: 1315,
  },
  {
    id:7,
    type: 'non-veg',
    name: 'Chicken Cheese Sandwich',
    price: 1835,
  },
  {
    id:8,
    type: 'veg',
    name: 'Paneer Cheese Sandwich',
    price: 1135,
  },
  {
    id:9,
    type: 'non-veg',
    name: 'Chicken Cheese Sandwich',
    price: 1635,
  },
  {
    id:10,
    type: 'veg',
    name: 'Cheese Sandwich',
    price: 1535,
  },
 
]
};

const travelerDetailsViewData = {  
  travelerDetailsView :[  {
    id:1,
    name: 'Richard Williams',
    pnr: 'FT23654V',
    seat:'31C',
    meal:'Veg sandwich',
    baggage:'5 kg'
  },
  {
    id:2,
    name: 'Charles',
    pnr: 'FT25424V',
    seat:'33C',
    meal:'Samosa',
    baggage:'15 kg'
  },
  {
    id:3,
    name: 'Paper Pots',
    pnr: 'FT23424V',
    seat:'32C',
    meal:'Puri Bhaji',
    baggage:'10 kg'
  },
  {
    id:4,
    name: 'Danny R',
    pnr: 'FT43524V',
    seat:'41C',
    meal:'Noodles',
    baggage:'10 kg'
  },
  {
    id:5,
    name: 'Sam Steve',
    pnr: 'FT12344V',
    seat:'43C',
    meal:'Non-veg sandwich',
    baggage:'5 kg'

    
  },
]

};

const cancellationRowsData = {
  cancellationRows :[   {
    id:1,
    timeFrame: '0 hours to 4 hours',
    fee: 'Adult: Non Refundable' 
  },
  {
    id:2,
    timeFrame: '0 hours to 365 days', 
    fee: 'Adult: ₹1000'
  },
 ]
}

const seatLayoutData = {
  seatLayout: {
    Lowerdeck: [],
    Maindeck: {
      equipmentInfo: {
        fareType: "Refundable",
        nft: "Refundable",
        columns: "A|B|C|BL1|D|E|F|BL2", 
        wingsStart: "9",
        wingsEnd: "14",
        cabinName: "F",
        cabinType: "Y",
        cabinStart: "1",
        cabinEnd: "30"
      },
      rowInfo: {
        "1": {
          rchar: "",
          rseats: [
            {
              sn: "1A",
              ns: "",
              is_available: false,
              price: 3500,
              is_seat: 0,
              sc: ""
            },
            {
              sn: "1B",
              ns: "",
              is_available: false,
              price: 0,
              is_seat: 0,
              sc: ""
            },
            {
              sn: "1C",
              ns: "",
              is_available: false,
              price: 3500,
              is_seat: 0,
              sc: ""
            },
            {
              sn: "1D",
              ns: "",
              is_available: false,
              price: 3500,
              is_seat: 0,
              sc: ""
            },
            {
              sn: "1E",
              ns: "",
              is_available: false,
              price: 0,
              is_seat: 0,
              sc: ""
            },
            {
              sn: "1F",
              ns: "",
              is_available: true,
              price: 3500,
              is_seat: 0,
              sc: ""
            }
          ]
        },
        "2": {
          rchar: "",
          rseats: [
            {
              sn: "2A",
              ns: "",
              is_available: true,
              price: 3500,
              is_seat: 0,
              sc: ""
            },
            {
              sn: "2B",
              ns: "",
              is_available: false,
              price: 0,
              is_seat: 0,
              sc: ""
            },
            {
              sn: "2C",
              ns: "",
              is_available: true,
              price: 3500,
              is_seat: 0,
              sc: ""
            },
            {
              sn: "2D",
              ns: "",
              is_available: true,
              price: 3500,
              is_seat: 0,
              sc: ""
            },
            {
              sn: "2E",
              ns: "",
              is_available: false,
              price: 0,
              is_seat: 0,
              sc: ""
            },
            {
              sn: "2F",
              ns: "",
              is_available: true,
              price: 3500,
              is_seat: 0,
              sc: ""
            }
          ]
        },
        "3": {
          rchar: "",
          rseats: [
            {
              sn: "3A",
              ns: "",
              is_available: true,
              price: 3500,
              is_seat: 0,
              sc: ""
            },
            {
              sn: "3B",
              ns: "",
              is_available: false,
              price: 0,
              is_seat: 0,
              sc: ""
            },
            {
              sn: "3C",
              ns: "",
              is_available: true,
              price: 3500,
              is_seat: 0,
              sc: ""
            },
            {
              sn: "3D",
              ns: "",
              is_available: true,
              price: 3500,
              is_seat: 0,
              sc: ""
            },
            {
              sn: "3E",
              ns: "",
              is_available: false,
              price: 0,
              is_seat: 0,
              sc: ""
            },
            {
              sn: "3F",
              ns: "",
              is_available: true,
              price: 3500,
              is_seat: 0,
              sc: ""
            }
          ]
        },
        "4": {
          rchar: "",
          rseats: [
            {
              sn: "4A",
              ns: "",
              is_available: true,
              price: 2000,
              is_seat: 0,
              sc: ""
            },
            {
              sn: "4B",
              ns: "",
              is_available: true,
              price: 1500,
              is_seat: 0,
              sc: ""
            },
            {
              sn: "4C",
              ns: "",
              is_available: true,
              price: 2000,
              is_seat: 0,
              sc: ""
            },
            {
              sn: "4D",
              ns: "",
              is_available: true,
              price: 2000,
              is_seat: 0,
              sc: ""
            },
            {
              sn: "4E",
              ns: "",
              is_available: true,
              price: 1500,
              is_seat: 0,
              sc: ""
            },
            {
              sn: "4F",
              ns: "",
              is_available: true,
              price: 2000,
              is_seat: 0,
              sc: ""
            }
          ]
        },
        "5": {
          rchar: "",
          rseats: [
            {
              sn: "5A",
              ns: "",
              is_available: false,
              price: 350,
              is_seat: 0,
              sc: ""
            },
            {
              sn: "5B",
              ns: "",
              is_available: false,
              price: 250,
              is_seat: 0,
              sc: ""
            },
            {
              sn: "5C",
              ns: "",
              is_available: false,
              price: 350,
              is_seat: 0,
              sc: ""
            },
            {
              sn: "5D",
              ns: "",
              is_available: false,
              price: 350,
              is_seat: 0,
              sc: ""
            },
            {
              sn: "5E",
              ns: "",
              is_available: true,
              price: 250,
              is_seat: 0,
              sc: ""
            },
            {
              sn: "5F",
              ns: "",
              is_available: false,
              price: 350,
              is_seat: 0,
              sc: ""
            }
          ]
        },
        "6": {
          rchar: "",
          rseats: [
            {
              sn: "6A",
              ns: "",
              is_available: true,
              price: 350,
              is_seat: 0,
              sc: ""
            },
            {
              sn: "6B",
              ns: "",
              is_available: true,
              price: 250,
              is_seat: 0,
              sc: ""
            },
            {
              sn: "6C",
              ns: "",
              is_available: false,
              price: 350,
              is_seat: 0,
              sc: ""
            },
            {
              sn: "6D",
              ns: "",
              is_available: true,
              price: 350,
              is_seat: 0,
              sc: ""
            },
            {
              sn: "6E",
              ns: "",
              is_available: true,
              price: 250,
              is_seat: 0,
              sc: ""
            },
            {
              sn: "6F",
              ns: "",
              is_available: false,
              price: 350,
              is_seat: 0,
              sc: ""
            }
          ]
        },
      },
    
    },
    Upperdeck: []
  }
};

// const seatLayoutData = {
//   seatLayout :[   {
//     id:1,
//     timeFrame: '0 hours to 4 hours',
//     fee: 'Adult: Non Refundable' 
//   },
//   {
//     id:2,
//     timeFrame: '0 hours to 365 days', 
//     fee: 'Adult: ₹1000'
//   },
//  ]
// }

export const client = new ApolloClient({
  cache: new InMemoryCache({
    typePolicies: {
      Query: {
        fields: {
          countries: {
            read() {
              return countriesData.countries;
            },
          },
          users: {
            read() {
              return usersData.users;
            },
          },
          notifications:{
            read(){
              return notificationsData.notifications;
            },
          },
          currencies:{
            read(){
              return currencyData.currencies;
            },
          },
          languages: {
            read() {
              return languageData.languages;
            },
          },
          walletamount: {
            read() {
              return walletData.walletamount;
            },
          },
          top100Films:{
             read(){
               return airtportsData.top100Films;
             }
          },
          airlineNames:{
            read(){
               return airlinesData.airlineNames;
            }
          },
          stops:{
            read(){
              return stopsData.stops;
            }
          },
          refunds:{
             read(){
                return refundabilityData.refunds;
             }
          },
          emissions:{
            read(){
               return emissionsData.emissions;
            }
         },
         policies:{
          read(){
             return policiesData.policies;
          }
         },
         prices:{
          read(){
             return priceData.prices;
          }
        },
        durations:{
          read(){
             return flightDurationData.durations;
          }
        },
        usersClient:{
          read(){
             return selectUserData.usersClient;
          }
        },
        flightDetails:{
          read(){
             return flightDetailsData.flightDetails;
          }
        },
        upcomingTrips:{
          read(){
             return upcomingTripsData.upcomingTrips;
          }
        },
        pendingRequest:{
          read(){
             return pendingRequestData.pendingRequest;
          }
        },
        promoCodes:{
          read(){
               return promoCodesData.promoCodes;
          }
        },
        selectBaggage:{
          read(){
               return selectBaggageData.selectBaggage;
          }
        },
        mealBeverage:{
          read(){
               return mealBeverageData.mealBeverage;
          }
        },
        travelerDetailsView:{
          read(){
               return travelerDetailsViewData.travelerDetailsView;
          }
        },
        cancellationRows:{
          read(){
               return cancellationRowsData.cancellationRows;
          }
        },
        seatLayout:{
          read(){
               return seatLayoutData.seatLayout;
          }
        },
        

        },
      },
    },
  }),
});


