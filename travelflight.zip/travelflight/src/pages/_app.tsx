// ** Next Imports
import Head from 'next/head'
import { Router,useRouter } from 'next/router'
import type { NextPage } from 'next'
import type { AppProps } from 'next/app'
import { ApolloProvider } from "@apollo/client"
import { useApollo } from "../@core/lib/useApollo"

// ** Loader Import
import NProgress from 'nprogress'

// ** Emotion Imports
import { CacheProvider } from '@emotion/react'
import type { EmotionCache } from '@emotion/cache'

// ** Config Imports
import themeConfig from 'src/configs/themeConfig'

// ** Component Imports
import UserLayout from 'src/layouts/UserLayout'
import ThemeComponent from 'src/@core/theme/ThemeComponent'

// ** Contexts
import { SettingsConsumer, SettingsProvider } from 'src/@core/context/settingsContext'

// ** Utils Imports
import { createEmotionCache } from 'src/@core/utils/create-emotion-cache'
import { NoSsr } from '@mui/material'

// ** React Perfect Scrollbar Style

import 'react-perfect-scrollbar/dist/css/styles.css'

// ** Global css styles

import '../../styles/globals.css'

// import '../../styles/style.scss'

import useLang from "../locales"

// import { IntlProvider, FormattedMessage } from 'react-intl';

import { IntlProvider } from 'react-intl';

// ** Extend App Props with Emotion
type ExtendedAppProps = AppProps & {
  Component: NextPage
  emotionCache: EmotionCache
}

const clientSideEmotionCache = createEmotionCache()

// ** Pace Loader
if (themeConfig.routingLoader) {
  Router.events.on('routeChangeStart', () => {
    NProgress.start()
  })
  Router.events.on('routeChangeError', () => {
    NProgress.done()
  })
  Router.events.on('routeChangeComplete', () => {
    NProgress.done()
  })
}

// ** Configure JSS & ClassName
const App = (props: ExtendedAppProps) => {
  
  const { Component, emotionCache = clientSideEmotionCache, pageProps } = props

  // const { asPath, locale, defaultLocale } = useRouter();

  const {  locale, defaultLocale } = useRouter();
  
  // Variables
  const getLayout = Component.getLayout ?? (page => <UserLayout>{page}</UserLayout>)
  const messages = useLang(locale)
  const apolloClient = useApollo(props);

  return (
    <NoSsr>
    <ApolloProvider client={apolloClient}>
    <CacheProvider value={emotionCache}>
      <Head>
        <title>{`${themeConfig.templateName}`}</title>
        <meta
          name='description'
          content={`${themeConfig.templateName}`}
        />
        <meta name='keywords' content='Next Travel, Next,Travel, Travel dubai, Travel Singapore, Travel india, Book Hotel, Book Flight ,Treak Mountains' />
        <meta name='viewport' content='initial-scale=1, width=device-width' />
      </Head>
      <IntlProvider messages={messages} locale={'locale'} defaultLocale={defaultLocale}>
      <SettingsProvider>
        <SettingsConsumer>
          {({ settings }) => {
            return <ThemeComponent settings={settings}>{getLayout(<Component {...pageProps} />)}</ThemeComponent>
          }}
        </SettingsConsumer>
      </SettingsProvider>
      </IntlProvider>
    </CacheProvider>
    </ApolloProvider>
    </NoSsr>
  )
}

export default App



// ** Next Imports
// import Head from 'next/head'
// import { Router, useRouter } from 'next/router'
// import type { NextPage } from 'next'
// import type { AppProps } from 'next/app'
// import { ApolloProvider } from "@apollo/client"
// import { useApollo } from "../@core/lib/useApollo"

// // ** Loader Import
// import NProgress from 'nprogress'

// // ** Emotion Imports
// import { CacheProvider } from '@emotion/react'
// import type { EmotionCache } from '@emotion/cache'

// // ** Config Imports
// import themeConfig from 'src/configs/themeConfig'

// // ** Component Imports
// import UserLayout from 'src/layouts/UserLayout'
// import ThemeComponent from 'src/@core/theme/ThemeComponent'

// // ** Contexts
// import { SettingsConsumer, SettingsProvider } from 'src/@core/context/settingsContext'

// // ** Utils Imports
// import { createEmotionCache } from 'src/@core/utils/create-emotion-cache'
// import { NoSsr } from '@mui/material'
// // ** React Perfect Scrollbar Style
// import 'react-perfect-scrollbar/dist/css/styles.css'

// // ** Global css styles
// import '../../styles/globals.css'
// import useLang from "../locales"
// import { IntlProvider, FormattedMessage } from 'react-intl';

// // ** Extend App Props with Emotion
// type ExtendedAppProps = AppProps & {
//   Component: NextPage
//   emotionCache: EmotionCache
// }

// const clientSideEmotionCache = createEmotionCache()

// // ** Pace Loader
// if (themeConfig.routingLoader) {
//   Router.events.on('routeChangeStart', () => {
//     NProgress.start()
//   })
//   Router.events.on('routeChangeError', () => {
//     NProgress.done()
//   })
//   Router.events.on('routeChangeComplete', () => {
//     NProgress.done()
//   })
// }

// // ** Configure JSS & ClassName
// const App = (props: ExtendedAppProps) => {
//   const { Component, emotionCache = clientSideEmotionCache, pageProps } = props
//   const { asPath, locale, defaultLocale } = useRouter();
//   // Variables
//   const getLayout = Component.getLayout ?? (page => <UserLayout>{page}</UserLayout>)
//   const messages = useLang(locale)
//   const apolloClient = useApollo(pageProps.initialApolloState);

//   return (
//     <NoSsr>
//       <ApolloProvider client={apolloClient}>
//         <CacheProvider value={emotionCache}>
//           <Head>
//             <title>{`${themeConfig.templateName}`}</title>
//             <meta
//               name='description'
//               content={`${themeConfig.templateName}`}
//             />
//             <meta name='keywords' content='Next Travel, Next,Travel, Travel dubai, Travel Singapore, Travel india, Book Hotel, Book Flight ,Treak Mountains' />
//             <meta name='viewport' content='initial-scale=1, width=device-width' />
//           </Head>
//           <IntlProvider messages={messages} locale={locale} defaultLocale={defaultLocale}>
//             <SettingsProvider>
//               <SettingsConsumer>
//                 {({ settings }) => {
//                   return <ThemeComponent settings={settings}>{getLayout(<Component {...pageProps} />)}</ThemeComponent>
//                 }}
//               </SettingsConsumer>
//             </SettingsProvider>
//           </IntlProvider>
//         </CacheProvider>
//       </ApolloProvider>
//     </NoSsr>
//   )
// }

// export default App
