
import {Card,CardContent,Grid } from "@mui/material";

// import { useState } from "react";
// import PromoCode from "../flightlisting/flightListingInner/PromoCode";

import TotalFare from "../flightlisting/flightListingInner/TotalFare";
import ChoosePayment from "./PayNowInner/ChoosePayment";

// import TraverlerDetails from "./FlightListing";
// import TotalFare from "./flightListingInner/TotalFare";
// import PromoCode from "./flightListingInner/PromoCode";

const PayNow = () => {
    return(
        <>
        <Grid container spacing={6}>
            <Grid item sm={8} xs={12}>
            <Card>   
            <CardContent className="payNowBox">
               <ChoosePayment/>
            </CardContent>
            </Card> 
            </Grid>
            <Grid item sm={4} xs={12}>

              {/* <TotalFare/>   
              <PromoCode/> */}
              
              <TotalFare/> 
             
            </Grid>
        </Grid>
       
        </>
    )
}
export default PayNow;
