import { useContext } from 'react';

import { SettingsContext, SettingsContextValue } from '../context/settingsContext';

export const useSettings = (): SettingsContextValue => {

    const settings = useContext(SettingsContext);
    
    if(settings === null || settings === undefined){
         throw new Error('useSettings must be used withing a SettingContextProvider');
    }

    return settings;
};

