// ** React Imports

import { useState,Fragment,useEffect, } from 'react' 
import Box from '@mui/material/Box' 
import { styled } from '@mui/material/styles' 
import MuiMenuItem, { MenuItemProps } from '@mui/material/MenuItem'
import "country-flag-icons/3x2/flags.css"; 

// import PerfectScrollbarComponent from 'react-perfect-scrollbar'

import dynamic from 'next/dynamic'
import { TypographyProps } from '@mui/material/Typography' 
import { useQuery } from "@apollo/client";
import { gql } from "@apollo/client";
import  React from 'react'
import Select, { SelectChangeEvent } from '@mui/material/Select';  
import { useTheme } from '@mui/material/styles' 
import Currency from 'react-currency-icons'   

const Typography = dynamic(
  () => import('@mui/material/Typography'),
  { ssr: false }
) as React.ComponentType<TypographyProps> 

const MenuItem = styled(MuiMenuItem)<MenuItemProps>(({ theme }) => ({
  paddingTop: theme.spacing(3),
  paddingBottom: theme.spacing(3),
  borderBottom: `1px solid ${theme.palette.divider}`
}))

// const styles = {
//   maxHeight: 349,
//   '& .MuiMenuItem-root:last-of-type': {
//     border: 0
//   }
// }
// const PerfectScrollbar = styled(PerfectScrollbarComponent)({
//   ...styles
// })

const MenuItemTitle = styled(Typography)<TypographyProps>(({ theme }) => ({
  fontWeight: 600,
  flex: '1 1 100%',
  overflow: 'hidden',
  fontSize: '0.875rem',
  whiteSpace: 'nowrap',
  textOverflow: 'ellipsis',
  marginBottom: theme.spacing(0.75)
}))

const CURRENCY_QUERY = gql`
  query Currencies {
    currencies {
      id 
      name 
      icon
    }
  }
`;
interface Currencys {
  id: string;
  name : string;
  icon: string;
}

interface CurrencyData {
  currencies: Currencys[];
}


const CurrencyDropdown = () => { 

  const theme = useTheme();
 
  
  const [currencies, setNotifications] = useState<CurrencyData["currencies"]>([]);
  const [currencys, setCurrency] = useState<string>('');

  const { loading, error, data } = useQuery<CurrencyData>(CURRENCY_QUERY);

  useEffect(() =>{
    if(!loading && data){
      setNotifications(data.currencies)
    }
  }, [loading, data])

  useEffect(() => {
    if (currencies.length > 0) {
      
      setCurrency(currencies[0].id);
    }
  }, [currencies])


  if (loading) return <p>Loading...</p>;
  if (error || !data) return <p>Error :</p>;



const handleChange = (event: SelectChangeEvent) => {
  setCurrency(event.target.value);
};


  return (
    <Fragment>  
     
      <Select
     
      className="currencyIcon" 
      value={currencys}
      onChange={handleChange}
      variant="standard"
      disableUnderline
      sx={{ display: 'flex', alignItems: 'center', paddingRight:'0rem',
      '&.Mui-focused': { 
        backgroundColor: '#fff'
      },
      '& .MuiSelect-select:focus': { 
        backgroundColor: '#fff'
      },
      '& .MuiSelect-select': {  
        paddingRight:'0rem !important'
      }
      
      }}

      MenuProps={{
        anchorOrigin: {
          vertical: 'bottom',
          horizontal: 'right'
        },
        transformOrigin: {
          vertical: 'top',
          horizontal: 'right'
        },
       
        sx: {
          overflow: 'hidden',
          marginTop: theme.spacing(4),
          '& .MuiMenu-list': {
            padding: 0,
            minWidth:200,
          },
          '& .MuiMenuItem-root':{
            paddingTop:'0.5rem',
            paddingBottom:'0.5rem'
          },
          [theme.breakpoints.down('sm')]: {
            '& .MuiMenu-paper': { 
              width:'100%'
            }
          }
          
        }
      }}
     
    >
      {currencies?.map((currencys) => (
        <MenuItem key={currencys.id} value={currencys.id}  className="currencyIcon" >
          <Box sx={{ width: '100%', display: 'flex', alignItems: 'center' }}>
            <Typography variant='caption'  sx={{
                '& .MuiSvgIcon-root': { 
                    fontSize:21,
                    position:'relative',
                    top:1
                  },
              }}>
           
            <Currency code={currencys.icon}  size="small" />
            
          </Typography>
          <Box sx={{ mx: 1, flex: '1 1', display: 'flex', overflow: 'hidden', flexDirection: 'column' }}>
          <MenuItemTitle>{currencys.name}</MenuItemTitle>
          </Box>
          </Box>
        </MenuItem>
      ))}
    </Select>

    </Fragment>
  )
}

export default CurrencyDropdown
