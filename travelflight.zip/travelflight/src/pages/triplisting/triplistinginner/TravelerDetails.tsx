import React from 'react';
import { Typography, Table, TableBody, TableCell, TableHead, TableRow, Paper, Box } from '@mui/material';
import { useQuery, gql } from '@apollo/client';
import { useTheme } from '@mui/material/styles';  


const TRAVELER_DETAILS_VIEW_QUERY = gql`
  query TravelerDetailsView {
    travelerDetailsView {
      id
      name
      pnr
      seat
      meal
      baggage
    }
  }
`;


interface TravelerDetailsView {
  id:number
  name:string
  pnr:string
  seat:string
  meal:string
  baggage:string
}

interface TravelerDetailsViewData {
  travelerDetailsView: TravelerDetailsView[]
}


const TravelerDetails = () => {

  const theme = useTheme();
  
  const [travelerDetailsView, setTravelerDetailsView] = React.useState<TravelerDetailsViewData["travelerDetailsView"]>([]);
    
  const { loading, data, error } = useQuery<TravelerDetailsViewData>(TRAVELER_DETAILS_VIEW_QUERY);

  React.useEffect(() => {
    if (error) {
      console.error("Error fetching data:", error);
    } else if (!loading && data) {
      console.log(data);
      setTravelerDetailsView(data.travelerDetailsView);
    }
  }, [loading, data, error]);



  return (
    <>
      <Box sx={{ padding: '1rem 1.5rem 2rem 1.5rem' }}>
        <Typography variant="h6" component="h1" gutterBottom sx={{marginBottom:'1.5rem'}}>
          Traveler Details
        </Typography>

        {/* <TableContainer component={Paper}> */}
          <Table sx={{ minWidth: 650 }} aria-label="simple table" className="travelerViewBox">
            <TableHead>
              <TableRow>
                <TableCell>Traveler</TableCell>
                <TableCell align="left">PNR</TableCell>
                <TableCell align="left">Seat</TableCell>
                <TableCell align="left" style={{minWidth:'4rem'}}></TableCell>
                <TableCell align="left">Meal</TableCell>
                <TableCell align="left">Baggage</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {travelerDetailsView.map((item , id) => (
                <TableRow
                  key={item.id}
                  sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
                >
                  <TableCell component="td">
                    {item.name}
                  </TableCell>
                  <TableCell align="left" className="boldCell">{item.pnr}</TableCell>
                  <TableCell align="left">{item.seat}</TableCell>
                  <TableCell align="left"></TableCell>
                  <TableCell align="left">{item.meal}</TableCell>
                  <TableCell align="left">{item.baggage}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        {/* </TableContainer> */}
      </Box>
    </>
  );
};

export default TravelerDetails;
