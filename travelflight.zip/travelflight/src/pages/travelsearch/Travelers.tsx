import {  useState, useEffect } from 'react';
import Box from '@mui/material/Box';
import Grid from '@mui/material/Grid';

import Typography from '@mui/material/Typography';

import CardContent from '@mui/material/CardContent';

import Button from '@mui/material/Button';
import ButtonGroup from '@mui/material/ButtonGroup';
import AddIcon from '@mui/icons-material/Add';
import RemoveIcon from '@mui/icons-material/Remove';

// interface DataType {
//   stats: string;
//   title: string;
//   color: ThemeColor;
//   icon: ReactElement;
// }

interface TravelersProps {
  onCountsUpdated: (counts: { adult: number; child: number; infant: number }) => void;
  
}

const Travelers = ({ onCountsUpdated }: TravelersProps) => {

  // const [adultsCount, setAdultsCount] = useState(1);
  // const [childrenCount, setChildrenCount] = useState(0);
  // const [infantsCount, setInfantsCount] = useState(0); 

  const storedAdultsCount = Number(localStorage.getItem('adultsCount')) || 1;
  const storedChildrenCount = Number(localStorage.getItem('childrenCount')) || 0;
  const storedInfantsCount = Number(localStorage.getItem('infantsCount')) || 0;

  const [adultsCount, setAdultsCount] = useState(storedAdultsCount);
  const [childrenCount, setChildrenCount] = useState(storedChildrenCount);
  const [infantsCount, setInfantsCount] = useState(storedInfantsCount);

  const incrementCount = (type: string) => {
    if (type === 'adults') {
      if (adultsCount < 10){
        setAdultsCount((prevCount) => prevCount + 1);
      }
    } else if (type === 'children') {
      if (childrenCount < 6){
      setChildrenCount((prevCount) => prevCount + 1);
      }
    } else if (type === 'infants') {
      if (infantsCount < 6){
      setInfantsCount((prevCount) => prevCount + 1);
      }
    }
  };

  const decrementCount = (type: string) => {
    if (type === 'adults') {
      setAdultsCount((prevCount) => Math.max(prevCount - 1, 0));
    } else if (type === 'children') {
      setChildrenCount((prevCount) => Math.max(prevCount - 1, 0));
    } else if (type === 'infants') {
      setInfantsCount((prevCount) => Math.max(prevCount - 1, 0));
    }
  };


  // useEffect(() => {
  //   onCountsUpdated({ adult: adultsCount, child: childrenCount, infant: infantsCount });
  //   // eslint-disable-next-line react-hooks/exhaustive-deps
     
  // }, [adultsCount, childrenCount, infantsCount]);

  useEffect(() => {
    // Save the counts in local storage whenever they are updated
    localStorage.setItem('adultsCount', adultsCount.toString());
    localStorage.setItem('childrenCount', childrenCount.toString());
    localStorage.setItem('infantsCount', infantsCount.toString());

    // Call the onCountsUpdated prop with the updated counts
    onCountsUpdated({ adult: adultsCount, child: childrenCount, infant: infantsCount });
  }, [adultsCount, childrenCount, infantsCount, onCountsUpdated]);

  

  return (
    <>
      <CardContent sx={{ pt: (theme) => `${theme.spacing(0)} !important`, paddingBottom:'0rem' }}>
        <Grid container spacing={[5, 0]}>
          <Grid item xs={12} sm={6}>
            <Box sx={{ display: 'flex', alignItems: 'center',justifyContent:{xs:'space-between',sm:'flex-start', md:'flex-start'}}}>
              <Box sx={{ display: 'flex', flexDirection: 'column', mr: 3 }}>
                <Typography variant='caption' sx={{ fontWeight: 'bold' }}>
                  Adults
                </Typography>
                <Typography variant='caption'>Over 12 years</Typography>
              </Box>
              <ButtonGroup size='small' aria-label='small button group'>
                <Button onClick={() => decrementCount('adults')} sx={{borderColor:'rgba(58, 53, 65, 0.18)'}}>
                  <RemoveIcon/>
                </Button>
                <Button disabled>{adultsCount}</Button>
                <Button onClick={() => incrementCount('adults')} sx={{borderColor:'rgba(58, 53, 65, 0.18)'}}>
                  <AddIcon/>
                </Button>
              </ButtonGroup>
            </Box>
          </Grid>
          <Grid item xs={12} sm={6}>
            <Box sx={{ display: 'flex', alignItems: 'center', justifyContent:{xs:'space-between',sm:'flex-start', md:'flex-start'} }}>
              <Box sx={{ display: 'flex', flexDirection: 'column', mr: 3 }}>
                <Typography variant='caption' sx={{ fontWeight: 'bold' }}>
                  Children
                </Typography>
                <Typography variant='caption'>2-12years</Typography>
              </Box>
              <ButtonGroup size='small' aria-label='small button group'>
                <Button onClick={() => decrementCount('children')} sx={{borderColor:'rgba(58, 53, 65, 0.18)'}}>
                <RemoveIcon/>
                </Button>
                <Button disabled>{childrenCount}</Button>
                <Button onClick={() => incrementCount('children')} sx={{borderColor:'rgba(58, 53, 65, 0.18)'}}>
                <AddIcon/>
                </Button>
              </ButtonGroup>
            </Box>
          </Grid>
          <Grid item xs={12} sm={6} sx={{ marginTop: '1rem' }}>
            <Box sx={{ display: 'flex', alignItems: 'center', justifyContent:{xs:'space-between',sm:'flex-start', md:'flex-start'} }}>
              <Box sx={{ display: 'flex', flexDirection: 'column', mr: 3 }}>
                <Typography variant='caption' sx={{ fontWeight: 'bold' }}>
                  Infants
                </Typography>
                <Typography variant='caption'>Under 2 years</Typography>
              </Box>
              <ButtonGroup size='small' aria-label='small button group'>
                <Button onClick={() => decrementCount('infants')} sx={{borderColor:'rgba(58, 53, 65, 0.18)'}}>
                <RemoveIcon/>
                </Button>
                <Button disabled>{infantsCount}</Button>
                <Button onClick={() => incrementCount('infants')} sx={{borderColor:'rgba(58, 53, 65, 0.18)'}}>
                <AddIcon/>
                </Button>
              </ButtonGroup>
            </Box>
          </Grid>
        </Grid>
      </CardContent>
    </>
  );
};

export default Travelers;