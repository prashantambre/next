import { useState, useId } from 'react'
import {
  FormControl,
  Select,
  FormControlLabel,

  Grid,
  Radio,
  RadioGroup,
  Box,
  ListItemIcon,
  ListItem,

  TextField,
  Accordion,
  AccordionSummary,
  AccordionDetails,

  MenuItem
} from '@mui/material'
import Image from 'next/image'
import * as React from 'react'
import { useTheme } from '@mui/material/styles';

const UpiOptions = () => {
  const [expanded, setExpanded] = useState('paytm')
  const [selectedOptions, setSelectedOptions] = useState(['', '', ''])
  const selectIds = [useId(), useId(), useId()]
  const handleAccordionChange = panel => ( isExpanded) => {
    setExpanded(isExpanded ? panel : '')
  }

  const [value, setValue] = React.useState('paytm')

  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setValue(event.target.value)
  }

  const handleSelectChange = (index, event) => {
    const newSelectedOptions = [...selectedOptions]
    newSelectedOptions[index] = event.target.value
    setSelectedOptions(newSelectedOptions)
  }

  const filteredOptions = [
    {
      label: 'Paytm(Wallet, Postpaid)',
      logo: '/images/logos/Paytm_logo_PNG1 1.png',
      options: [
        { value: 1, label: 'Option 1' },
        { value: 2, label: 'Option 2' },
        { value: 3, label: 'Option 3' }
      ]
    },
    {
      label: 'Freecharge(Wallet+Pay Later)',
      logo: '/images/logos/freecharge-logo-icon1.svg',
      options: [
        { value: 4, label: 'Option 4' },
        { value: 5, label: 'Option 5' },
        { value: 6, label: 'Option 6' }
      ]
    },
    {
      label: 'Airtel Money',
      logo: '/images/logos/airtel.png',
      options: [
        { value: 7, label: 'Option 7' },
        { value: 8, label: 'Option 8' },
        { value: 9, label: 'Option 9' }
      ]
    }
  ]

  const theme = useTheme();

  return (
    <>
      <Grid container spacing={2} sx={{ gap: '1rem 0rem' }} className='walletsBox'>
        <Grid item xs={12}>
          <FormControl fullWidth>
            <RadioGroup
              aria-labelledby='demo-controlled-radio-buttons-group'
              name='controlled-radio-buttons-group'
              value={value}
              onChange={handleChange}
            >
              {filteredOptions.map((option, index) => (
                <Accordion
                  key={index}
                  expanded={expanded === option.label}
                  sx={{
                    boxShadow: 'none',
                    '&.Mui-expanded': {
                      boxShadow: 'none'
                    },
                    '&:before': {
                      display: 'none'
                    }
                  }}
                >
                  <AccordionSummary
                    aria-controls={`${option.label}-content`}
                    id={`${option.label}-header`}
                    sx={{
                      padding: '0rem',
                      '& .MuiAccordionSummary-content': {
                        margin: '0rem'
                      },
                      '& .MuiAccordionSummary-content.Mui-expanded': {
                        margin: '0rem 0rem'
                      }
                    }}
                  >
                    <FormControlLabel
                      sx={{
                        marginBottom: '0rem !important'
                      }}
                      value={option.label}
                      control={<Radio  
                        sx={{'&.Mui-checked':{
                        color:theme.palette.secondary.main
                      }} 
                    }
                      onChange={handleAccordionChange(option.label)} />}
                      label={
                        <Box sx={{ display: 'flex', alignItems: 'center' }}>
                          <ListItem>{option.label}</ListItem>
                          <ListItemIcon sx={{ position: 'relative', right: '-1.5rem' }}>
                            <Image src={option.logo} width={35} height={35} alt={`${option.label} Logo`} />
                          </ListItemIcon>
                        </Box>
                      }
                    />
                  </AccordionSummary>
                  <AccordionDetails sx={{ padding: '0rem' }}>
                    <Box sx={{ display: 'flex', alignItems: 'center' }}>
                      <FormControl
                        fullWidth
                        sx={{
                          '& .MuiInputBase-root': {
                            borderBottomRightRadius: '0px',
                            borderTopRightRadius: '0px',
                            '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                              boxShadow: 'none',
                              borderColor:'rgba(58, 53, 65, 0.22)',
                              borderWidth:'1px'
                            },
                          }
                        }}
                      >
                        <TextField
                          placeholder='Enter promo code here'
                          sx={{
                            '& .MuiOutlinedInput-notchedOutline': {
                              borderColor: 'rgba(58, 53, 65, 0.32)',
                              borderWidth: '1px',
                              boxShadow: 'none'
                              
                            },
                            '&:hover .MuiOutlinedInput-notchedOutline': {
                              borderColor: 'rgba(58, 53, 65, 0.32)',
                              borderWidth: '1px'
                            },
                            '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                              borderColor: 'rgba(58, 53, 65, 0.32)',
                              borderWidth: '1px'
                            }
                          }}
                        />
                      </FormControl>
                      <FormControl
                        fullWidth
                        sx={{
                          width: '58%',
                          '& .MuiInputBase-root': {
                            borderBottomLeftRadius: '0px',
                            borderTopLeftRadius: '0px'
                          },
                          '& .Mui-focused .MuiOutlinedInput-notchedOutline': {
                            boxShadow: 'none',
                            borderColor:'rgba(58, 53, 65, 0.22)',
                            background:'none',
                            borderWidth:'1px'
                           
                          },
                        }}
                      >
                        <Select
                          displayEmpty
                          labelId={`select-label-${selectIds[index]}`}
                          value={selectedOptions[index]}
                          onChange={event => handleSelectChange(index, event)}
                          renderValue={selected => {
                            if (selected.length === 0) {
                              return <pre>Select</pre>
                            }

                            return selected
                          }}
                          inputProps={{ 'aria-label': 'Without label' }}
                        >
                          {option.options.map((selectOption, optionIndex) => (
                            <MenuItem key={optionIndex} value={selectOption.value}>
                              {selectOption.label}
                            </MenuItem>
                          ))}
                        </Select>
                      </FormControl>
                    </Box>
                  </AccordionDetails>
                </Accordion>
              ))}
            </RadioGroup>
          </FormControl>
        </Grid>
      </Grid>
    </>
  )
}

export default UpiOptions
