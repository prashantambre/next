
import * as React from "react";
import {
  Box,
  FormControlLabel,
  Checkbox,
  Button,
  Tooltip,
  IconButton,
} from "@mui/material";
import { useQuery, gql } from "@apollo/client";

const STOPSDATA_QUERY = gql`
  query Stops {
    stops {
      name
    }
  }
`;

interface Stop {
  name: string;
  checked: boolean;
}

interface StopData {
  stops: Stop[];
}

interface StopsFilterProps {
  onStopsClear: (event) => void;
  onStopsSelectedChange: (selectedValue: string[]) => void;
}

const StopsFilter = ({ onStopsClear, onStopsSelectedChange }: StopsFilterProps) => {
  const [stops, setStops] = React.useState<StopData["stops"]>([]);
  const [stopsSelectedValue, setStopsSelectedValue] = React.useState<string[]>(
    []
  );
  const { loading, error, data } = useQuery<StopData>(STOPSDATA_QUERY);

  React.useEffect(() => {
    if (!loading && data) {
      const stopNamesWithChecked = data.stops.map((stop) => ({
        ...stop,

        // checked: stopsSelectedValue.indexOf(stop.name) > -1,
        
        checked: stopsSelectedValue.indexOf(stop.name) > -1,
      }));
      setStops(stopNamesWithChecked);
    }
  }, [loading, data, stopsSelectedValue]);

  React.useEffect(() => {
    const storedSelectedStops = localStorage.getItem('selectedStops');
    if (storedSelectedStops) {
      const parsedStops = JSON.parse(storedSelectedStops);
      setStopsSelectedValue(parsedStops);
    }
  }, []);

  React.useEffect(() => {
    localStorage.setItem('selectedStops', JSON.stringify(stopsSelectedValue));
  }, [stopsSelectedValue]);

  const handleToggleStop = (index: number) => {
    const updatedStops = [...stops];
    updatedStops[index].checked = !updatedStops[index].checked;
    setStops(updatedStops);

    const selectedStops = updatedStops
      .filter((stop) => stop.checked)
      .map((stop) => stop.name);
    setStopsSelectedValue(selectedStops);
    onStopsSelectedChange(selectedStops);
  };

  const handleDeslectAll = (index: number) => {
    const updatedStops = stops.map((stop, i) => ({
      ...stop,
      checked: i === index,
    }));
    setStops(updatedStops);
    const selectedStops = updatedStops
    .filter((stop) => stop.checked)
    .map((stop) => stop.name);
  setStopsSelectedValue(selectedStops);
  onStopsSelectedChange(selectedStops);
  };

  const handleClearAll = () => {
    const updatedStops = stops.map((stop) => ({
      ...stop,
      checked: false,
    }));
    setStops(updatedStops);
    setStopsSelectedValue([]);
    onStopsClear(event);
    
  };

  const handleSelectAll = () => {
    const allChecked = stops.every((stop) => stop.checked);
    const updatedStops = stops.map((stop) => ({
      ...stop,
      checked: !allChecked,
    }));
    setStops(updatedStops);

    const selectedStops = updatedStops
    .filter((stop) => stop.checked)
    .map((stop) => stop.name);
  setStopsSelectedValue(selectedStops);
  onStopsSelectedChange(selectedStops);

  };

  if (loading) return <p>Loading...</p>;
  if (error || !data) return <p>Error :</p>;

  return (
    <>
      <Box sx={{ display: "flex", flexDirection: "column" }} className="filterBox">
        <Button variant="text" onClick={handleClearAll} className="clearButton">
          Clear
        </Button>
        <FormControlLabel
          control={
            <Checkbox
              checked={stops.every((stop) => stop.checked)}
              indeterminate={
                stops.some((stop) => stop.checked) &&
                !stops.every((stop) => stop.checked)
              }
              onChange={handleSelectAll}
            />
          }
          label={stops.every((stop) => stop.checked) ? "All Stops" : "All Stops"}
          sx={{
            "& .Mui-checked": {
              color: "#F0971A !important",
            },
            textTransform: "capitalize",
            "& .MuiCheckbox-indeterminate": {
              color: "#F0971A !important",
            },
          }}
        />
        {stops.map((stop, index) => (
          <Tooltip
            key={stop.name}
            title={
              stop.checked ? (
                <IconButton 
                  onClick={() => { 
                    handleDeslectAll(index);
                  }}
                >
                  Only
                </IconButton>
              ) : (
                ""
              )
            }
            placement="right"  
            classes={{ tooltip: "tooltipBox" }}
          >
            <FormControlLabel
              control={
                <Checkbox
                  checked={stop.checked}
                  onChange={() => handleToggleStop(index)}
                  sx={{
                    "& .Mui-checked": {
                      color: "#F0971A !important",
                    },
                  }}
                />
              }
              label={stop.name}
              sx={{
                "& .Mui-checked": {
                  color: "#F0971A !important",
                },
                textTransform: "capitalize",
                "& .MuiCheckbox-indeterminate": {
                  color: "#F0971A !important",
                },
              }}
            />
          </Tooltip>
        ))}
      </Box>
    </>
  );
};

export default StopsFilter;



