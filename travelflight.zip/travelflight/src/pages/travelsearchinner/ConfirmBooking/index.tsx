import { useTheme } from '@mui/material/styles';
import React, { useEffect, } from 'react'
import GoodToKnow from "./bookingInner/GoodToKnow";
import { Grid, Typography } from "@mui/material"
import TotalFare from "../flightlisting/flightListingInner/TotalFare" 
import BookingTicket from './bookingInner/BookingTicket';
import ClassTravel from './bookingInner/ClassTravel';

import { useRouter } from 'next/router'


const ConfirmBooking = () => {
    const theme = useTheme();
    const router = useRouter();

    useEffect(() => {
      if (router.pathname === '/travelsearchinner/ConfirmBooking') { 
        const travelSearch = document.querySelector('.navList-Box [href="/travelsearch/"] span');
        travelSearch?.classList.add('active');
      }
    }, [router.pathname]);
    
    
   return (
    <>
       <Grid container spacing={0}>
       <Grid item sm={9} xs={12} 
       sx={{border:'1px solid #E4E6E8',
       background:theme.palette.common.white,  
       boxShadow:'1px 1px 10px rgba(0, 0, 0, 0.1)',
       borderRadius:'6px',
       borderRight: '2px dotted #E4E6E8',
       borderTopRightRadius:'0px',
       borderBottomRightRadius:'0px'
       }}>
         <Typography variant="h6" gutterBottom
       sx={{background:theme.palette.secondary.main,
       color:theme.palette.common.white,
       padding:' 0.5rem 2rem',
       borderTopLeftRadius:' 6px',
       position:'relative',
       '&:before':{
        content: '""',
        width:'2px',
        height:'100%',
        position:'absolute',
        right:'-2px',
        zIndex:'999',
        background:theme.palette.secondary.main, 
        top:'0rem'
       }
       }}>
        Trip ID : ISFKJFBSLNKFSKS
      </Typography>
         <BookingTicket/>
       </Grid>
       <Grid item sm={3} xs={12} >  
          <ClassTravel/>
       </Grid>
       </Grid>
       <Grid container spacing={6}>   
            <Grid item sm={8} xs={12}>
                <GoodToKnow />
            </Grid>
            <Grid item sm={4} xs={12} sx={{marginTop:'2rem'}}>    
              <TotalFare/>  
            </Grid>
        </Grid>
    </>
   )
}

export default ConfirmBooking