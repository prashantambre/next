import { Button, ListItem } from '@mui/material';
import React from 'react';

const Seat = ({ seatNumber, isSelected, onSelect }) => {
  const handleClick = () => {
    
    onSelect(seatNumber);
    console.log(seatNumber)
  };

  return (
    <>
    <ListItem
      className={`seat ${isSelected ? 'selected' : ''}`}
      onClick={handleClick}
    >
      <Button variant="text"><span style={{visibility:'hidden'}}>{seatNumber}</span> </Button> 
    </ListItem>
    </>
  );
};

export default Seat;