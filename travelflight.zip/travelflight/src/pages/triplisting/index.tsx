
import React, { useEffect } from "react";

import { ExpandMore } from "@mui/icons-material";
import { Accordion, AccordionDetails, AccordionSummary, Card, Divider, Grid, Typography,Box } from "@mui/material";
import { useState } from "react";
import TravelerDetails from "./triplistinginner/TravelerDetails";
import TotalFare from "./triplistinginner/TotalFare";

// import PromoCode from "./flightListingInner/PromoCode";

import TripDetails from "./triplistinginner/TripDetails";
import ModeOutlinedIcon from '@mui/icons-material/ModeOutlined';
import { useTheme } from '@mui/material/styles'
import CancellationPolicy from "./triplistinginner/CancellationPolicy";
import GoodToKnow from "../travelsearchinner/ConfirmBooking/bookingInner/GoodToKnow"

const FlightListing = () => {
    const [expanded, setExpanded] = useState<string | false>(false);

    

  const handleChange =
    (panel: string) => (event: React.SyntheticEvent, isExpanded: boolean) => {
      setExpanded(isExpanded ? panel : false);
    };
    useEffect(() => {
      // You can also set the initial state here
      setExpanded("panel1"); 
    }, []);
    const travelerNames = ['Oliver James', 'John Doe', 'Alice Smith', 'Bob Johnson', 'Bob Johnsons'];


    const theme = useTheme()

    return(
        <>
        <Grid container spacing={6}>
            <Grid item sm={8} xs={12}>
      <Card> 
     
      <TripDetails />  
      </Card>
      <Card sx={{mt:8,overflow:'visible'}} > 
      <TravelerDetails/>
      </Card>
      <GoodToKnow/> 
      <Card sx={{mt:8}}>
          <CancellationPolicy/>
        </Card> 
            </Grid>
            <Grid item sm={4} xs={12}>
              <TotalFare/>   
             
            </Grid>
        </Grid>
       
        </>
    )
}
export default FlightListing;
