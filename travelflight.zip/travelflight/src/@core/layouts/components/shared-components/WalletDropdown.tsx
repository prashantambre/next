// ** React Imports
import { useState, SyntheticEvent, Fragment } from 'react' 
import Box from '@mui/material/Box' 
import IconButton from '@mui/material/IconButton'
import { styled, Theme } from '@mui/material/styles'
import useMediaQuery from '@mui/material/useMediaQuery'
import MuiMenu, { MenuProps } from '@mui/material/Menu'
import MuiMenuItem, { MenuItemProps } from '@mui/material/MenuItem'  
import dynamic from 'next/dynamic'

// import CurrencyRupeeIcon from '@mui/icons-material/CurrencyRupee';

import { TypographyProps } from '@mui/material/Typography' 
import { Wallet } from 'mdi-material-ui'
import { useQuery } from "@apollo/client";
import { gql } from "@apollo/client";
import  React from 'react'

// import MonetizationOnIcon from '@mui/icons-material/MonetizationOn'
// import  EuroSymbol   from '@mui/icons-material/EuroSymbol'  

import Currency from 'react-currency-icons'

const Typography = dynamic(
  () => import('@mui/material/Typography'),
  { ssr: false }
) as React.ComponentType<TypographyProps> 
const Menu = styled(MuiMenu)<MenuProps>(({ theme }) => ({
  '& .MuiMenu-paper': {
    width: 200,
    overflow: 'hidden',
    marginTop: theme.spacing(4),
    [theme.breakpoints.down('sm')]: {
      width: '100%'
    }
  },
  '& .MuiMenu-list': {
    padding: 0
  }
}))
 
const MenuItem = styled(MuiMenuItem)<MenuItemProps>(({ theme }) => ({
  paddingTop: theme.spacing(3),
  paddingBottom: theme.spacing(3),
  borderBottom: `1px solid ${theme.palette.divider}`
}))

const MenuItemTitle = styled(Typography)<TypographyProps>(({ theme }) => ({
  fontWeight: 600,
  flex: '1 1 100%',
  overflow: 'hidden',
  fontSize: '0.875rem',
  whiteSpace: 'nowrap',
  textOverflow: 'ellipsis',
  marginBottom: theme.spacing(0.75),
 '& .MuiSvgIcon-root':{
     fontSize:'12px'
  }
}))

const WALLET_QUERY = gql`
  query Walletamount {
    walletamount {
      id 
      amount 
      icon
    }
  }
`;
interface Wallet {
  id: string;
  amount : number;
  icon: string;
}

interface WalletData {
  walletamount: Wallet[];
}

// const getCurrencyIcon = (icon: string) => {
//   switch (icon) {
//     case 'MonetizationOnIcon':
//       return <MonetizationOnIcon fontSize="small" />;
//     case 'CurrencyRupeeIcon':
//       return <CurrencyRupeeIcon fontSize="small" />;
//     case 'EuroSymbol':
//       return <EuroSymbol fontSize="small" />;
//     default:
//         return null;
//   }
// }

const WalletDropdown = () => { 
  const [anchorEl, setAnchorEl] = useState<(EventTarget & Element) | null>(null)

  // const hidden = useMediaQuery((theme: Theme) => theme.breakpoints.down('lg'))

  const handleDropdownOpen = (event: SyntheticEvent) => {
    setAnchorEl(event.currentTarget)
  } 
  const handleDropdownClose = () => {
    setAnchorEl(null)
  } 

  const hiddenSm = useMediaQuery((theme: Theme) => theme.breakpoints.down('sm')) 
  const { loading, error, data } = useQuery<WalletData>(WALLET_QUERY);
  if (loading) return <p>Loading...</p>;
  if (error || !data) return <p>Error :</p>;
  
  return (
    <Fragment>
      
     
      {data.walletamount?.map((item) => {
        
        return(

          <React.Fragment key={item.id} >
             <IconButton className="currencyIcon" disableRipple  color='inherit' aria-haspopup='true' onClick={handleDropdownOpen} aria-controls='customized-menu'>
          <Box sx={{ width: '100%', display: 'flex', alignItems: 'center' }}>
          <Typography variant='caption' sx={{
            '& .MuiSvgIcon-root': { 
                fontSize:21,
                position:'relative',
                top:1
              },
          }}>
          <Wallet />
          </Typography>
          {!hiddenSm && (
          <Box sx={{ mx: 4, marginLeft:'0.2rem', marginRight:'0rem', flex: '1 1', display: 'flex', overflow: 'hidden', flexDirection: 'column' }}>
            <MenuItemTitle>
            <Currency code={item.icon}  size="small" /> 
            {item.amount}</MenuItemTitle>
          </Box> 
          )}
        </Box>
        </IconButton>

      {hiddenSm && (
      <Menu
      className="currencyIcon"
        anchorEl={anchorEl}
        open={Boolean(anchorEl)}
        onClose={handleDropdownClose}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
        transformOrigin={{ vertical: 'top', horizontal: 'right' }}
      > 
          <MenuItem onClick={handleDropdownClose}>
            <Box sx={{ width: '100%', display: 'flex', alignItems: 'center' }}>
            <Typography variant='caption'  sx={{
                '& .MuiSvgIcon-root': { 
                    fontSize:21,
                    position:'relative',
                    top:1
                  },
              }}>
              <Wallet />
              </Typography>
              <Box sx={{ mx: 1, flex: '1 1', display: 'flex', overflow: 'hidden', flexDirection: 'column' }}>
                <MenuItemTitle>
                <Currency code={item.icon}  size="small" />
                {item.amount}
                </MenuItemTitle>
              </Box>
            </Box>
          </MenuItem> 
      </Menu>

      
      )}
        </React.Fragment>
        )
      }
   
            )
              }
     
    </Fragment>
  )
}

export default WalletDropdown
