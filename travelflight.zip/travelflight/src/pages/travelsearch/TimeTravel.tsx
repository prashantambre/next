import * as React from 'react'

import Card from '@mui/material/Card'

import FlightIcon from '@mui/icons-material/Flight'

import Select from '@mui/material/Select'
import MenuItem from '@mui/material/MenuItem'
import { SelectChangeEvent } from '@mui/material/Select'
import FormControl from '@mui/material/FormControl'
import InputLabel from '@mui/material/InputLabel'
import AddIcon from '@mui/icons-material/Add';
import { Tabs, Tab, Box, Stack, Grid, TextField, Button } from '@mui/material'
import { useTheme, useMediaQuery } from '@mui/material'
import moment, { Moment } from 'moment'
import 'react-dates/initialize'
import 'react-dates/lib/css/_datepicker.css'
import { DateRangePicker, FocusedInputShape } from 'react-dates'
import { SingleDatePicker } from 'react-dates';

import { Paper } from '@mui/material'

import { useQuery } from '@apollo/client'
import { gql } from '@apollo/client'
import { Autocomplete } from '@mui/material'

// import { HTMLAttributes } from '@mui/types';


import ListItem from '@mui/material/ListItem'

import ListItemText from '@mui/material/ListItemText'

import TravellerClass from './TravellerClass'
import SelectTraveler from './SelectTraveler' 
import { TravelExplore } from '@mui/icons-material'
import { useRouter } from 'next/router'
import PersonalTab from './PersonalTab'
import { Close } from '@mui/icons-material';
import Image from 'next/image';

import { useId } from 'react';

interface CardNavigationState {
  startDate: Moment | null
  endDate: Moment | null
  focusedInput: FocusedInputShape | null
}

interface TabPanelProps {
  children?: React.ReactNode
  index: number
  value: number
}

interface DateRangePicker {
  small: boolean
  required: boolean
  showClearDates: boolean
  reopenPickerOnClearDates: boolean
}

const TabPanel = (props: TabPanelProps) => {
  const { children, value, index, ...other } = props

  return (
    <div
      role='tabpanel'
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && <Box sx={{ p: 3 }}>{children}</Box>}
    </div>
  )
}

const a11yProps = (index: number) => {
  return {
    id: `simple-tab-${index}`,
    'aria-controls': `simple-tabpanel-${index}`
  }
}

const AIRPORT_QUERY = gql`
  query Top100Films {
    top100Films {
      cityName
      airportName
      country
      countryCode
    }
  }
`
interface Top100Film {
  cityName: string
  airportName: string
  country: string
  countryCode: string
}

interface AirtportsData {
  top100Films: Top100Film[]
}

const TimeTravel = () => {
  const [value, setValue] = React.useState(0)
  const [nestedValue, setNestedValue] = React.useState(0)
  const [selectedOption, setSelectedOption] = React.useState('One Way')
  const router = useRouter();

  // const [secondary, setSecondary] = React.useState(false)
  
  const {  data } = useQuery<AirtportsData>(AIRPORT_QUERY) 
  const top100Films = data?.top100Films || [] 
  const [dateRange, setDateRange] = React.useState<CardNavigationState>({
    startDate: null,
    endDate: null,
    focusedInput: null
  })
  const [dateRangeSingle, setDateRangeSingle] = React.useState<CardNavigationState>({
    startDate: null,
    endDate: null,
    focusedInput: null
  })

  
  const passwordHintId = useId();

  // const [cities, setCities] = React.useState([{ from: null, to: null, departure: null }]);

  // const [cities, setCities] = React.useState([
  //   { from: null, to: null, departure: { startDate: null, endDate: null } }
  // ]);


  const [cities, setCities] = React.useState([
    {
      from: null,
      to: null,
      departure: { startDate: null, endDate: null },
      dateRangeFocusedInput: null, // Add the missing property here
    },
  ]);

  React.useEffect(() => {
    // Check if a previously selected option exists in localStorage
    const storedOption = localStorage.getItem('selectedOption');

    if (storedOption) {
      setSelectedOption(storedOption);
    } else {
      // If no stored option, default to 'One Way'
      setSelectedOption('OneWay');
    }
  }, []);

  // const handleAddCity = () => {
  //   setCities([...cities, { from: null, to: null, departure: null }]);
  // };

  const handleAddCity = () => {

    // setCities([...cities, { from: null, to: null, departure: { startDate: null, endDate: null } }]);

    setCities([...cities, { from: null, to: null, departure: { startDate: null, endDate: null }, dateRangeFocusedInput: null }]);
  };
  

   // Function to remove the last city field
  //  const handleRemoveCity = () => {
  //   // if (cities.length > 1) {
  //   //   // const updatedCities = [...cities];
  //   //   // updatedCities.pop();
  //   //   const updatedCities = [cities[0]];
  //   //   setCities(updatedCities);
  //   // }
  //   if (cities.length > 1) {
  //     // const updatedCities = [...cities];
  //     // updatedCities.pop();
  //     // setCities(updatedCities);
  //     setCities([cities[i]]);
  //   } else {
  //     // Set an empty array to remove the TimeTravel component from the parent
  //     setCities([]);
  //   }
  // };

  const handleRemoveCity = (indexToRemove) => {

    // const updatedCities = cities.filter((city, index) => index !== indexToRemove);
    // setCities(updatedCities);

    if (cities.length > 1) {
      const updatedCities = cities.filter((city, index) => index !== indexToRemove);
      setCities(updatedCities);
    }
  };


  // Function to update city fields when changed
  // const handleCityChange = (index: number, field: string, value: any) => {
  //   const updatedCities = [...cities];
  //   updatedCities[index][field] = value;
  //   setCities(updatedCities);
  // };

  // const handleCityChange = (index: number, field: string, value: any) => {
  //   const updatedCities = [...cities];
  //   if (field === 'departure') {
  //     updatedCities[index][field] = value;
  //   } else {
  //     updatedCities[index][field] = value || null;
  //   }
  //   setCities(updatedCities);
  // };

  // const handleCityChange = (index: number, field: string, value: any) => {
  //   const updatedCities = [...cities];
    
  //   // Update the field in the city object
  //   if (field === 'departure') {
  //     updatedCities[index][field] = value;
  //   } else {
  //     updatedCities[index][field] = value || null;
  //   }
  
  //   // Ensure departure is an object with startDate and endDate properties
  //   if (!updatedCities[index].departure) {
  //     updatedCities[index].departure = { startDate: null, endDate: null };
  //   }
  
  //   setCities(updatedCities);
  // };


  const handleCityChange = (index: number, field: string, value: any) => {
    const updatedCities = [...cities];
    
    // Update the field in the city object

    if (field === 'departure') {
      updatedCities[index][field] = value;
    } else {
      updatedCities[index][field] = value || null;
    }
  
    // Ensure departure is an object with startDate and endDate properties

    if (field === 'departure' && !updatedCities[index].departure) {
      updatedCities[index].departure = { startDate: null, endDate: null };
    }
  
    setCities(updatedCities);
  };




  const handleSearchFlight = async () => {
    await router.push('/travelsearchinner');
    if (router.asPath === '/travelsearch/') { 
      const travelSearch = document.querySelector('.navList-Box [href="/travelsearch/"] span'); 
      travelSearch?.classList.add('active');
    }
  }; 

  React.useEffect(() => {
    const handleNavClick = (item) => {  
      if(item.pathname != '/travelsearch/'){  
        const travelMenu = document.querySelector('.navList-Box [href="/travelsearch/"] span');
        travelMenu?.classList.remove('active');
      }
    };

    document.querySelectorAll('.navList-Box .nav-link a').forEach((item) => {
      item.addEventListener('click', handleNavClick);
    }); 
  }, [router]);
  


  const handleChange = (event: React.SyntheticEvent, newValue: number) => {
    setValue(newValue)
  } 
  const handleNestedChange = (event: React.SyntheticEvent, newValue: number) => {
    setNestedValue(newValue)
  } 
  const handleOptionChange = (event: SelectChangeEvent<string>) => {

    // setSelectedOption(event.target.value)

    const newOption = event.target.value;
    setSelectedOption(newOption);

    // Store the selected option in localStorage

    localStorage.setItem('selectedOption', newOption);
  }

  const theme = useTheme()

  const isMobileLandscape = useMediaQuery(theme.breakpoints.down('md'))

  const handleDateChange = ({ startDate, endDate }: { startDate: Moment | null; endDate: Moment | null }) => {
    const currentDate = moment()
    if (startDate && startDate.isBefore(currentDate)) {
      startDate = currentDate
    }
    setDateRange(prevState => ({
      ...prevState,
      startDate,
      endDate
    }))

    if (startDate) {
      localStorage.setItem('startDate', startDate.format());
    } else {
      localStorage.removeItem('startDate');
    }
    if (endDate) {
      localStorage.setItem('endDate', endDate.format());
    } else {
      localStorage.removeItem('endDate');
    }

  }

  const handleDateChangeSingle = ({ startDate, endDate }: { startDate: Moment | null; endDate: Moment | null }) => {
    const currentDate = moment();
    if (startDate && startDate.isBefore(currentDate)) {
      startDate = currentDate;
    }
    setDateRangeSingle(prevState => ({
      ...prevState,
      startDate,
      endDate
    }));
  
    if (startDate) {
      localStorage.setItem('startDate', startDate.format());
    } else {
      localStorage.removeItem('startDate');
    }
    if (endDate) {
      localStorage.setItem('endDate', endDate.format());
    } else {
      localStorage.removeItem('endDate');
    }
  };
  

  React.useEffect(() => {

    // Retrieve start date and end date from localStorage

    const storedStartDate = localStorage.getItem('startDate');
    const storedEndDate = localStorage.getItem('endDate');
  
    // Parse the stored date strings into Moment objects
    
    const startDate = storedStartDate ? moment(storedStartDate) : null;
    const endDate = storedEndDate ? moment(storedEndDate) : null;
  
    // Set the retrieved start date and end date in the DateRangePicker

    setDateRange(prevState => ({
      ...prevState,
      startDate,
      endDate,
    }));
  }, []);

  
  
  
  const isOutsideRanges = (date: Moment) => {
    return date.isBefore(moment(), 'day')
  }

  const isDesktop = useMediaQuery('(min-width: 1024px)')
  const numberOfMonths = isDesktop ? 2 : 1

  return (
    <>
    {isDesktop && (
       <Box sx={{position:'absolute', width:'35rem', right:'0rem', top:'-1rem'}}>
       <img
       style={{  width: '100%', height: 'auto' }}
        src='/images/plane.png'
        alt=''
        />
      </Box>
    )} 
      <Tabs
        value={value}
        onChange={handleChange}
        aria-label='basic tabs example'
        sx={{
          backgroundColor: '#fff',
          width: 'fit-content',
          borderRadius: '30px',
          marginBottom: '2rem',
          '& .MuiTabs-indicator': { display: 'none' },
          '& .Mui-selected': { backgroundColor: theme.palette.common.black, borderRadius: '30px', margin: '4px' }
        }}
      >
        
        <Tab
          label='Business'
          {...a11yProps(0)}
          sx={{
            minHeight: 'auto',
            paddingTop: '11px',
            paddingBottom: '11px',
            textTransform:'capitalize',
            '&.Mui-selected': { color: theme.palette.common.white }
          }}
        />
        <Tab
          label='Personal'
          {...a11yProps(1)}
          sx={{
            minHeight: 'auto',
            paddingTop: '11px',
            paddingBottom: '11px',
            textTransform:'capitalize',
            '&.Mui-selected': { color: theme.palette.common.white }
          }}
        />
      </Tabs>
      <Card sx={{ overflow: 'visible', borderRadius: 3 }} className='mainSearchBox '>
        <Box sx={{ display: 'flex', width: '100%' }}>
       
          <TabPanel value={value} index={0}>
            <Stack direction={isMobileLandscape ? 'column' : 'row'} spacing={2}>
              <Tabs
                value={nestedValue}
                onChange={handleNestedChange}
                aria-label='nested tabs example'
                orientation={isMobileLandscape ? 'horizontal' : 'vertical'}
                variant={isMobileLandscape ? 'standard' : 'scrollable'}
                sx={{
                  '& .MuiButtonBase-root.Mui-selected':{
                    color:`${theme.palette.secondary.light} !important` ,
                    textTransform:'capitalize'
                  },
                  '& .MuiButtonBase-root':{
                    textTransform:'capitalize'
                  },
                  '& .MuiTabs-indicator':{
                    background:theme.palette.secondary.light
                  }
                  
                }}
              >
                <Tab label='Flight' {...a11yProps(0)} icon={<FlightIcon sx={{ rotate: '45deg' }} />} />
                
                {/* <Tab label='' {...a11yProps(1)} icon={<HotelIcon />} /> */}

              </Tabs>
              <TabPanel  value={nestedValue} index={0}>
                <Select
                  value={selectedOption}
                  onChange={handleOptionChange}
                  sx={{
                    '& .MuiOutlinedInput-notchedOutline': {
                      borderColor: 'transparent !important',
                      boxShadow: 'none',
                      
                    },
                    '& .MuiSelect-select':{
                       paddingLeft:0, 
                    },
                    '&.MuiInputBase-root:hover .MuiOutlinedInput-notchedOutline': {
                      borderColor: 'transparent'
                    }
                  }}
                  MenuProps={{
                    anchorOrigin: {
                      vertical: 'bottom',
                      horizontal: 'right'
                    },
                    transformOrigin: {
                      vertical: 'top',
                      horizontal: 'right'
                    },

                    sx: {
                      overflow: 'hidden',
                      marginTop: theme.spacing(4),
                      '& .MuiMenu-list': {
                        padding: 0,
                        minWidth: 200
                      },
                      '& .MuiMenuItem-root': {
                        paddingTop: '0.5rem',
                        paddingBottom: '0.5rem'
                      },
                      [theme.breakpoints.down('sm')]: {
                        '& .MuiMenu-paper': {
                          width: '100%'
                        }
                      }
                    }
                  }}
                >
                  <MenuItem  value='OneWay'>One Way</MenuItem>
                  <MenuItem value='RoundTrip'>Round Trip</MenuItem>
                  <MenuItem value='MultiCity'>Multi City</MenuItem>
                </Select>

                <Grid container  spacing={{ xs: 0, sm: 2, md: 2 }} sx={{display:selectedOption === 'OneWay'? 'flex' : 'none'}}>
                  <Grid item> 
                    <FormControl >
                      <InputLabel
                        htmlFor='from-input'
                        sx={{
                          transform: 'none',
                          position: 'static',
                          '&.Mui-focused': {
                            color: 'inherit'
                          },
                          marginBottom: '5px'
                        }}
                        disableAnimation
                      >
                        From
                      </InputLabel>
                      <Autocomplete
                        disablePortal
                        disableClearable  
                        className='boxShadowBox'
                        options={top100Films}
                        getOptionLabel={(option: Top100Film) => `${option.cityName},${option.country} `}

                        // renderOption={(props, option: Top100Film, state: AutocompleteRenderOptionState) => (

                        renderOption={(props, option: Top100Film) => (

                          <ListItem {...props}>
                            <FlightIcon sx={{color:'#687591',marginRight:'10px', fontSize:'1.25rem', rotate:'45deg'}}/>
                            <ListItemText
                              primary={`${option.cityName},${option.country} `}
                              secondary={option.airportName}
                            />
                           <span style={{fontWeight:'500', fontSize:'0.875rem', marginLeft:'10px'}}>{option.countryCode}</span>
                          </ListItem>
                        )}
                        
                        sx={{
                           width: { xs: '100%', sm:270, md:290 },
                          '.MuiOutlinedInput-root': {
                            padding: '2px'
                          },
                          '& .MuiAutocomplete-popupIndicator': {
                            display: 'none', // Hide the dropdown icon
                          }
                        }}
                        PaperComponent={({ children }) => (
                          <Paper
                            sx={{ width: '19rem', marginTop: 4, paddingBottom: 3, paddingTop: 3,
                            '& .MuiAutocomplete-listbox': {
                              // Customize the styles of the dropdown list

                              maxHeight: '20rem', // Set the maximum height
                              overflowY: 'auto', // Add vertical scroll when needed

                              // '&::-webkit-scrollbar': {
                              //   width: '5px',
                              //   height:'5px'
                              // },
                              // '&::-webkit-scrollbar-thumb': {
                              //   backgroundColor: theme.palette.common.black,
                              //   borderRadius: '8px',
                              // },
                              // '&::-webkit-scrollbar-thumb:hover': {
                              //   backgroundColor: theme.palette.common.black,
                              // },
                            },
                          }}
                            className='boxShadowBox  '
                          >
                            {children}
                          </Paper>
                        )}
                        renderInput={params => (
                          <TextField 
                            {...params}
                            sx={{
                              '& .MuiOutlinedInput-notchedOutline': {
                                borderColor: 'rgba(58, 53, 65, 0.32)',
                                borderWidth: '1px',
                                boxShadow: 'none',
                                border: 'none'
                              },
                              '&:hover .MuiOutlinedInput-notchedOutline': {
                                borderColor: 'rgba(58, 53, 65, 0.32)',
                                borderWidth: '1px'
                              },
                              '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                                borderColor: 'rgba(58, 53, 65, 0.32)',
                                borderWidth: '1px'
                              },
                              '& .MuiAutocomplete-input':{
                                width:'100% !important'
                              }
                            }}
                          />
                        )}
                      />
                    </FormControl>
                </Grid>
                <Grid item sx={{margin:{xs:'0.5rem auto 0rem'}}}>
                    <FlightIcon
                      sx={{
                        rotate:{xs:'180deg', sm:'90deg'},
                        marginTop: { xs: '0.5rem', sm:'1.675rem' },
                        position: 'relative',
                        left: '4px',
                        top: '0px',
                        fontSize: '1.25rem'
                      }}
                    />
                    {/* <FlightIcon
                      sx={{
                        rotate: {xs:'0deg', sm:'-90deg'},
                        marginTop: { xs: '0.5rem', sm:'1.675rem' },
                        position: 'relative',
                        right: '4px',
                        top: '7px',
                        fontSize: '1.25rem'
                      }}
                    /> */}
                </Grid>
                <Grid item>
                    <FormControl >
                      <InputLabel
                        htmlFor='from-input'
                        sx={{
                          transform: 'none',
                          position: 'static',
                          '&.Mui-focused': {
                            color: 'inherit'
                          },
                          marginBottom: '5px'
                        }}
                        disableAnimation
                      >
                        To
                      </InputLabel>
                      <Autocomplete
                        disablePortal
                        className='boxShadowBox'
                        options={top100Films}
                        getOptionLabel={(option: Top100Film) => `${option.cityName},${option.country} `}

                        // renderOption={(props, option: Top100Film, state: AutocompleteRenderOptionState) => (

                        renderOption={(props, option: Top100Film) => (

                          <ListItem {...props}>
                            <FlightIcon sx={{color:'#687591',marginRight:'10px', fontSize:'1.25rem', rotate:'45deg'}}/>
                            <ListItemText
                              primary={`${option.cityName},${option.country} `}
                              secondary={option.airportName}
                            />
                            <span style={{fontWeight:'500', fontSize:'0.875rem', marginLeft:'10px'}}> {option.countryCode}</span>
                           
                          </ListItem>
                        )}
                       
                        fullWidth
                        sx={{

                          // width: 290,

                          width: { xs: '100%',sm:270,md:290 },
                          '.MuiOutlinedInput-root': {
                            padding: '2px'
                          },
                          '& .MuiAutocomplete-popupIndicator': {
                            display: 'none', 
                          }
                        }}
                        PaperComponent={({ children }) => (
                          <Paper
                            sx={{ width: '19rem', marginTop: 4, paddingBottom: 3, paddingTop: 3 }}
                            className='boxShadowBox'
                          >
                            {children}
                          </Paper>
                        )}
                        renderInput={params => (
                          <TextField
                            {...params}
                            sx={{
                              '& .MuiOutlinedInput-notchedOutline': {
                                borderColor: 'rgba(58, 53, 65, 0.32)',
                                borderWidth: '1px',
                                boxShadow: 'none',
                                border: 'none'
                              },
                              '&:hover .MuiOutlinedInput-notchedOutline': {
                                borderColor: 'rgba(58, 53, 65, 0.32)',
                                borderWidth: '1px'
                              },
                              '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                                borderColor: 'rgba(58, 53, 65, 0.32)',
                                borderWidth: '1px'
                              },
                              '& .MuiAutocomplete-input':{
                                width:'100% !important'
                              }
                            }}
                          />
                        )}
                      />
                    </FormControl>
                  </Grid>
                  <Grid item sx={{ marginTop:{xs:'1.5rem', md:'0rem'}}}>
                    <Box sx={{ position: 'relative', zIndex: 1,
                   
                        '& .SingleDatePicker .DateInput':{
                          minWidth:'12.5rem'
                        }
                      
                  }} className='calenderBox'>
                      <FormControl>
                        <InputLabel
                          htmlFor='from-input'
                          sx={{
                            transform: 'none',
                            position: 'static',
                            '&.Mui-focused': {
                              color: 'inherit'
                            },
                            marginBottom: '5px'
                          }}
                          disableAnimation
                        >
                          Departure  
                        </InputLabel>

                        {/* <DateRangePicker
                          id={passwordHintId}
                          startDate={dateRange.startDate}
                          endDate={dateRange.endDate}
                          onDatesChange={handleDateChange}
                          focusedInput={dateRange.focusedInput}
                          onFocusChange={focusedInput => setDateRange(prevState => ({ ...prevState, focusedInput }))}
                          small={true}
                          showDefaultInputIcon={true}
                          // required={true}
                          showClearDates={true}
                          reopenPickerOnClearDates={true}
                          isOutsideRange={isOutsideRanges}
                          // portal={document.getElementById('portal')!}
                          disableScroll
                          hideKeyboardShortcutsPanel // Hide keyboard shortcuts panel
                          displayFormat='ddd DD MMM'
                          numberOfMonths={numberOfMonths}
                          withPortal={!isDesktop}
                          anchorDirection='right'
                        /> */}


<SingleDatePicker
              date={dateRangeSingle.startDate} 
              onDateChange={date => handleDateChangeSingle({ startDate: date, endDate: null })}
              focused={dateRangeSingle.focusedInput === 'startDate'}
              onFocusChange={({ focused }) =>
                setDateRangeSingle(prevState => ({ ...prevState, focusedInput: focused ? 'startDate' : null }))
              }
              displayFormat='ddd DD MMM'
              numberOfMonths={1}
              withPortal={!isDesktop}
              anchorDirection='right'
              isOutsideRange={isOutsideRanges}
              showDefaultInputIcon={true}
              showClearDate={true}
              reopenPickerOnClearDate={true}
              hideKeyboardShortcutsPanel
              small
              disableScroll
              width="100%"
             
            />

                      </FormControl>
                    </Box>
                  </Grid>
                  <Grid container item xs={12} sm={6} md={6} lg={4}>
                      <TravellerClass />
                  </Grid>
                  <Grid container item xs={12} sm={6} md={6} lg={8} sx={{marginTop:{xs:'1rem',md:'0rem'}}}>
                  <SelectTraveler />
                  </Grid>
                  <Grid item xs={12}  sx={{justifyContent:'center',display:'flex'}}> 
                    <Button variant="contained" 
                    onClick={handleSearchFlight} 
                     className="borderRadiusButton"  
                     sx={{backgroundColor:theme.palette.secondary.main,
                           marginTop:'1.5rem', 
                           '&:hover':{
                            background:theme.palette.primary.light
                           }
                      }}>
                    <TravelExplore /> Search Flight
                   </Button> 
                  </Grid>
                  
                </Grid>

                {/*  */}
                {/* roundtrip */}

                <Grid container spacing={{ xs: 0, sm: 2, md: 2 }} sx={{display:selectedOption === 'RoundTrip'? 'flex' : 'none'}}>
                  <Grid item> 
                    <FormControl >
                      <InputLabel
                        htmlFor='from-input'
                        sx={{
                          transform: 'none',
                          position: 'static',
                          '&.Mui-focused': {
                            color: 'inherit'
                          },
                          marginBottom: '5px'
                        }}
                        disableAnimation
                      >
                        From
                      </InputLabel>
                      <Autocomplete
                        disablePortal
                        disableClearable  
                        className='boxShadowBox'
                        options={top100Films}
                        getOptionLabel={(option: Top100Film) => `${option.cityName},${option.country} `}
                        
                        // renderOption={(props, option: Top100Film, state: AutocompleteRenderOptionState) => (

                        renderOption={(props, option: Top100Film) => (

                          <ListItem {...props}>
                            <FlightIcon sx={{color:'#687591',marginRight:'10px', fontSize:'1.25rem', rotate:'45deg'}}/>
                            <ListItemText
                              primary={`${option.cityName},${option.country} `}
                              secondary={option.airportName}
                            />
                           <span style={{fontWeight:'500', fontSize:'0.875rem', marginLeft:'10px'}}>{option.countryCode}</span>
                          </ListItem>
                        )}
                      
                        
                        sx={{
                           width: { xs: '100%', sm:270, md:290 },
                          '.MuiOutlinedInput-root': {
                            padding: '2px'
                          },
                          '& .MuiAutocomplete-popupIndicator': {
                            display: 'none', 
                          }
                        }}
                        PaperComponent={({ children }) => (
                          <Paper
                            sx={{ width: '19rem', marginTop: 4, paddingBottom: 3, paddingTop: 3 }}
                            className='boxShadowBox'
                          >
                            {children}
                          </Paper>
                        )}
                        renderInput={params => (
                          <TextField 
                            {...params}
                            sx={{
                              '& .MuiOutlinedInput-notchedOutline': {
                                borderColor: 'rgba(58, 53, 65, 0.32)',
                                borderWidth: '1px',
                                boxShadow: 'none',
                                border: 'none'
                              },
                              '&:hover .MuiOutlinedInput-notchedOutline': {
                                borderColor: 'rgba(58, 53, 65, 0.32)',
                                borderWidth: '1px'
                              },
                              '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                                borderColor: 'rgba(58, 53, 65, 0.32)',
                                borderWidth: '1px'
                              },
                              '& .MuiAutocomplete-input':{
                                width:'100% !important'
                              }
                            }}
                          />
                        )}
                      />
                    </FormControl>
                </Grid>
                <Grid item sx={{margin:{xs:'0.5rem auto 0rem'}}}>
                    <FlightIcon
                      sx={{
                        rotate:{xs:'180deg', sm:'90deg'},
                        marginTop: { xs: '0.5rem', sm:'1.675rem' },
                        position: 'relative',
                        left: '4px',
                        top: '0px',
                        fontSize: '1.25rem'
                      }}
                    />
                    <FlightIcon
                      sx={{
                        rotate: {xs:'0deg', sm:'-90deg'},
                        marginTop: { xs: '0.5rem', sm:'1.675rem' },
                        position: 'relative',
                        right: '4px',
                        top: '7px',
                        fontSize: '1.25rem'
                      }}
                    />
                </Grid>
                <Grid item>
                    <FormControl >
                      <InputLabel
                        htmlFor='from-input'
                        sx={{
                          transform: 'none',
                          position: 'static',
                          '&.Mui-focused': {
                            color: 'inherit'
                          },
                          marginBottom: '5px'
                        }}
                        disableAnimation
                      >
                        To
                      </InputLabel>
                      <Autocomplete
                        disablePortal
                        className='boxShadowBox'
                        options={top100Films}
                        getOptionLabel={(option: Top100Film) => `${option.cityName},${option.country} `}

                        // renderOption={(props, option: Top100Film, state: AutocompleteRenderOptionState) => (

                        renderOption={(props, option: Top100Film) => (
                          <ListItem {...props}>
                            <FlightIcon sx={{color:'#687591',marginRight:'10px', fontSize:'1.25rem', rotate:'45deg'}}/>
                            <ListItemText
                              primary={`${option.cityName},${option.country} `}
                              secondary={option.airportName}
                            />
                            <span style={{fontWeight:'500', fontSize:'0.875rem', marginLeft:'10px'}}> {option.countryCode}</span>
                           
                          </ListItem>
                        )}
                       
                        fullWidth
                        sx={{

                          // width: 290,

                          width: { xs: '100%',sm:270,md:290 },
                          '.MuiOutlinedInput-root': {
                            padding: '2px'
                          },
                          '& .MuiAutocomplete-popupIndicator': {
                            display: 'none', 
                          }
                        }}
                        PaperComponent={({ children }) => (
                          <Paper
                            sx={{ width: '19rem', marginTop: 4, paddingBottom: 3, paddingTop: 3 }}
                            className='boxShadowBox'
                          >
                            {children}
                          </Paper>
                        )}
                        renderInput={params => (
                          <TextField
                            {...params}
                            sx={{
                              '& .MuiOutlinedInput-notchedOutline': {
                                borderColor: 'rgba(58, 53, 65, 0.32)',
                                borderWidth: '1px',
                                boxShadow: 'none',
                                border: 'none'
                              },
                              '&:hover .MuiOutlinedInput-notchedOutline': {
                                borderColor: 'rgba(58, 53, 65, 0.32)',
                                borderWidth: '1px'
                              },
                              '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                                borderColor: 'rgba(58, 53, 65, 0.32)',
                                borderWidth: '1px'
                              },
                              '& .MuiAutocomplete-input':{
                                width:'100% !important'
                              }
                            }}
                          />
                        )}
                      />
                    </FormControl>
                  </Grid>
                  <Grid item sx={{ marginTop:{xs:'1.5rem', md:'0rem'}}}>
                    <Box sx={{ position: 'relative', zIndex: 1 }} className='calenderBox'>
                      <FormControl>
                        <InputLabel
                          htmlFor='from-input'
                          sx={{
                            transform: 'none',
                            position: 'static',
                            '&.Mui-focused': {
                              color: 'inherit'
                            },
                            marginBottom: '5px'
                          }}
                          disableAnimation
                        >
                          Departure-Return  
                        </InputLabel>
                        <DateRangePicker
                          id={passwordHintId}
                          startDate={dateRange.startDate}
                          endDate={dateRange.endDate}
                          onDatesChange={handleDateChange}
                          focusedInput={dateRange.focusedInput}
                          onFocusChange={focusedInput => setDateRange(prevState => ({ ...prevState, focusedInput }))}
                          small={true}
                          showDefaultInputIcon={true}

                          // required={true}

                          showClearDates={true}
                          reopenPickerOnClearDates={true}
                          isOutsideRange={isOutsideRanges}

                          // portal={document.getElementById('portal')!}

                          disableScroll
                          hideKeyboardShortcutsPanel 
                          displayFormat='ddd DD MMM'
                          numberOfMonths={numberOfMonths}
                          withPortal={!isDesktop}
                          anchorDirection='right'
                        />
                      </FormControl>
                    </Box>
                  </Grid>
                  <Grid container item xs={12} sm={6} md={6} lg={4}>
                      <TravellerClass />
                  </Grid>
                  <Grid container item xs={12} sm={6} md={6} lg={8} sx={{marginTop:{xs:'1rem',md:'0rem'}}}>
                  <SelectTraveler />
                  </Grid>
                  <Grid item xs={12}  sx={{justifyContent:'center',display:'flex'}}> 
                    <Button variant="contained" 
                    onClick={handleSearchFlight} 
                     className="borderRadiusButton"  
                     sx={{backgroundColor:theme.palette.secondary.main,
                           marginTop:'1.5rem', 
                           '&:hover':{
                            background:theme.palette.primary.light
                           }
                      }}>
                    <TravelExplore /> Search Flight
                   </Button> 
                  </Grid>
                  
                </Grid>

                {/*multicity  */}

                <Grid container spacing={2} sx={{display:selectedOption === 'MultiCity'? 'flex' : 'none'}}>
                {cities.map((city, index) => (
                  <React.Fragment key={city.departure?.startDate}>
                <Grid  container item xs={12} spacing={2}>
                  <Grid item sx={{marginBottom:'1rem'}}>
                    <FormControl>
                      <InputLabel
                        htmlFor='from-input'
                        sx={{
                          transform: 'none',
                          position: 'static',
                          '&.Mui-focused': {
                            color: 'inherit'
                          },
                          marginBottom: '5px'
                        }}
                        disableAnimation
                      >
                        From
                      </InputLabel>
                      <Autocomplete
                        value={cities[index]?.from || null}
                        onChange={(event, value) => handleCityChange(index, 'from', value)}
                        disablePortal
                        className='boxShadowBox'
                        options={top100Films}
                        getOptionLabel={(option: Top100Film) => `${option.cityName},${option.country} `}

                        // renderOption={(props, option: Top100Film, state: AutocompleteRenderOptionState) => (

                        renderOption={(props, option: Top100Film) => (
                          <ListItem {...props}>
                            <FlightIcon sx={{color:'#687591',marginRight:'10px', fontSize:'1.25rem', rotate:'45deg'}}/>
                            <ListItemText
                              primary={`${option.cityName},${option.country} `}
                              secondary={option.airportName}
                            />
                           <span style={{fontWeight:'500', fontSize:'0.875rem', marginLeft:'10px'}}>{option.countryCode}</span>
                          </ListItem>
                        )}
                      
                        fullWidth
                        sx={{
                          width: 274,
                          '.MuiOutlinedInput-root': {
                            padding: '2px'
                          },
                          '& .MuiAutocomplete-popupIndicator': {
                            display: 'none', 
                          }
                        }}
                        PaperComponent={({ children }) => (
                          <Paper
                            sx={{ width: '19rem', marginTop: 4, paddingBottom: 3, paddingTop: 3 }}
                            className='boxShadowBox'
                          >
                            {children}
                          </Paper>
                        )}
                        renderInput={params => (
                          <TextField
                            {...params}
                            sx={{
                              '& .MuiOutlinedInput-notchedOutline': {
                                borderColor: 'rgba(58, 53, 65, 0.32)',
                                borderWidth: '1px',
                                boxShadow: 'none',
                                border: 'none'
                              },
                              '&:hover .MuiOutlinedInput-notchedOutline': {
                                borderColor: 'rgba(58, 53, 65, 0.32)',
                                borderWidth: '1px'
                              },
                              '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                                borderColor: 'rgba(58, 53, 65, 0.32)',
                                borderWidth: '1px'
                              }
                            }}
                          />
                        )}
                      />
                    </FormControl>
                    <FlightIcon
                      sx={{
                        rotate: '90deg',
                        marginTop: '2.25rem',
                        position: 'relative',
                        left: '4px',
                        top: '0px',
                        fontSize: '1.25rem'
                      }}
                    />
                    <FlightIcon
                      sx={{
                        rotate: '-90deg',
                        marginTop: '2.25rem',
                        position: 'relative',
                        right: '4px',
                        top: '7px',
                        fontSize: '1.25rem'
                      }}
                    />
                    <FormControl>
                      <InputLabel
                        htmlFor='from-input'
                        sx={{
                          transform: 'none',
                          position: 'static',
                          '&.Mui-focused': {
                            color: 'inherit'
                          },
                          marginBottom: '5px'
                        }}
                        disableAnimation
                      >
                        To
                      </InputLabel>
                      <Autocomplete
                      value={cities[index]?.to || null}
                      onChange={(event, value) => handleCityChange(index, 'to', value)}
                        disablePortal
                        className='boxShadowBox'
                        options={top100Films}
                        getOptionLabel={(option: Top100Film) => `${option.cityName},${option.country} `}

                        // renderOption={(props, option: Top100Film, state: AutocompleteRenderOptionState) => (

                        renderOption={(props, option: Top100Film) => (
                          <ListItem {...props}>
                            <FlightIcon sx={{color:'#687591',marginRight:'10px', fontSize:'1.25rem', rotate:'45deg'}}/>
                            <ListItemText
                              primary={`${option.cityName},${option.country} `}
                              secondary={option.airportName}
                            />
                            <span style={{fontWeight:'500', fontSize:'0.875rem', marginLeft:'10px'}}> {option.countryCode}</span>
                           
                          </ListItem>
                        )}
                       
                        fullWidth
                        sx={{
                          width: 274,
                          '.MuiOutlinedInput-root': {
                            padding: '2px'
                          },
                          '& .MuiAutocomplete-popupIndicator': {
                            display: 'none', 
                          }
                        }}
                        PaperComponent={({ children }) => (
                          <Paper
                            sx={{ width: '19rem', marginTop: 4, paddingBottom: 3, paddingTop: 3 }}
                            className='boxShadowBox'
                          >
                            {children}
                          </Paper>
                        )}
                        renderInput={params => (
                          <TextField
                            {...params}
                            sx={{
                              '& .MuiOutlinedInput-notchedOutline': {
                                borderColor: 'rgba(58, 53, 65, 0.32)',
                                borderWidth: '1px',
                                boxShadow: 'none',
                                border: 'none'
                              },
                              '&:hover .MuiOutlinedInput-notchedOutline': {
                                borderColor: 'rgba(58, 53, 65, 0.32)',
                                borderWidth: '1px'
                              },
                              '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                                borderColor: 'rgba(58, 53, 65, 0.32)',
                                borderWidth: '1px'
                              }
                            }}
                          />
                        )}
                      />
                    </FormControl>
                  </Grid>
                  <Grid item sx={{marginBottom:'1rem'}}>
                    <Box className='calenderBox'>
                      <FormControl fullWidth>
                        <InputLabel
                          htmlFor='from-input'
                          sx={{
                            transform: 'none',
                            position: 'static',
                            zIndex:'inherit',
                            '&.Mui-focused': {
                              color: 'inherit'
                            },
                            marginBottom: '5px'
                          }}
                          disableAnimation
                        >
                          Departure-Return  
                        </InputLabel>
                        <DateRangePicker

                          // startDate={dateRange.startDate}
                          // endDate={dateRange.endDate}
                          // startDate={city.departure.startDate}
                          // endDate={city.departure.endDate}
                          // // onDatesChange={handleDateChange}
                          // onDatesChange={({ startDate, endDate }) => handleCityChange(index, 'departure', { startDate, endDate })}
                          // startDate={city.departure?.startDate}
                          // endDate={city.departure?.endDate}
                          // onDatesChange={({ startDate, endDate }) => handleCityChange(index, 'departure', { startDate, endDate })}
                          // focusedInput={dateRange.focusedInput}
                          // onFocusChange={focusedInput => setDateRange(prevState => ({ ...prevState, focusedInput }))}
                          // small={true}

                          startDate={city.departure?.startDate}
                          endDate={city.departure?.endDate}
                          onDatesChange={({ startDate, endDate }) => handleCityChange(index, 'departure', { startDate, endDate })}
                          focusedInput={city.dateRangeFocusedInput} // Use a city-specific focusedInput
                          onFocusChange={(focusedInput) => {
                            const updatedCities = [...cities];
                            updatedCities[index].dateRangeFocusedInput = focusedInput;
                            setCities(updatedCities);
                          }}
                          small={true}
                          
                          showDefaultInputIcon={true}

                          // required={true}

                          showClearDates={true}
                          reopenPickerOnClearDates={true}
                          isOutsideRange={isOutsideRanges}

                          // portal={document.getElementById('portal')!}

                          disableScroll
                          hideKeyboardShortcutsPanel 
                          displayFormat='ddd DD MMM'
                          numberOfMonths={numberOfMonths}
                          withPortal={!isDesktop}
                          anchorDirection='right'
                        />
                      </FormControl>
                    </Box>
                  </Grid>
                   <Grid item> 
              {cities.length > 1 && (
            <Button
              variant="text"
              onClick={() => handleRemoveCity(index)}
              sx={{
                margin: '0px',
                background: theme.palette.common.white,
                color: theme.palette.common.black,
                textTransform: 'capitalize',
                padding: 0,
                borderRadius: '100%',
                lineHeight: 'auto',
                width: '2.5rem',
                height: '2.5rem',
                minWidth: 'auto',
                marginTop:'1.725rem',
                '&.MuiButton-root:hover': {

                  // border: `1px solid ${theme.palette.common.black}`,
                  // boxShadow: '0 0 5px rgba(0, 0, 0, 0.3)', // Add the box shadow on hover

                  background:'#F5F5F5'
                },
              }}
            >
                <Close />
            </Button>
          )}
                   </Grid>
                 
                  </Grid>

                  </React.Fragment>
                ))}
         

         <Grid item xs={12}>
         <Button variant="text" onClick={handleAddCity} 
           sx={{ margin: '0px',
           background:theme.palette.common.white,
           color:theme.palette.secondary.light,
           border:`1px solid ${theme.palette.secondary.light}`,
           textTransform:'capitalize',
           padding: '0.26875rem 0.75rem'
          }}
          >
            <AddIcon /> Add City
          </Button>
        
         
        </Grid>

                  <Grid container item xs={4}>
                      <TravellerClass />
                  </Grid> 
                  <Grid item xs={12}  sx={{justifyContent:'center',display:'flex'}}> 
                    <Button variant="contained" 
                    onClick={handleSearchFlight} 
                     className="borderRadiusButton"  
                     sx={{backgroundColor:theme.palette.secondary.main,
                           marginTop:'1.5rem', 
                           '&:hover':{
                            background:theme.palette.primary.light
                           }
                      }}>
                    <TravelExplore /> Search Flight
                   </Button> 
                  </Grid>
                  
                </Grid>
                
              </TabPanel>
              <TabPanel value={nestedValue} index={1}>
                Nested Tab 2 Content
              </TabPanel>
            </Stack>
          </TabPanel>
          <TabPanel value={value} index={1}>
            <PersonalTab/>
          </TabPanel>
        </Box>
      </Card>
    </>
  )
}

export default TimeTravel
