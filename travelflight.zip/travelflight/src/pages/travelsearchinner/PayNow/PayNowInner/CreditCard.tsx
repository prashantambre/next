import * as React from 'react';  
import moment from 'moment';
import { Grid,FormControl,InputLabel,TextField,InputAdornment } from "@mui/material"
import DatePicker from 'react-datepicker';

// import { useTheme } from '@mui/material/styles'

const CreditCard = () => {

    const [selectedMonth, setSelectedMonth] = React.useState<moment.Moment | null>(null);

    // const theme = useTheme()
  
    
    const handleMonthChange = (date: Date) => {
      setSelectedMonth(moment(date));
    };

    
   return(
    <>
       <Grid container spacing={2} sx={{gap:'1rem 0rem'}}>
              <Grid item xs={12}>
                <FormControl fullWidth>
                  <InputLabel
                    htmlFor='from-input'
                    sx={{
                      transform: 'none',
                      position: 'static',
                      '&.Mui-focused': {
                        color: 'inherit'
                      },
                      marginBottom: '5px'
                    }}
                    disableAnimation
                  >
                    Card Number
                  </InputLabel>
                  <TextField
                   placeholder='Enter your card number here'
                    sx={{
                      '& .MuiOutlinedInput-notchedOutline': {
                        borderColor: 'rgba(58, 53, 65, 0.32)',
                        borderWidth: '1px',
                        boxShadow: 'none'
                        
                      },
                      '&:hover .MuiOutlinedInput-notchedOutline': {
                        borderColor: 'rgba(58, 53, 65, 0.32)',
                        borderWidth: '1px'
                      },
                      '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                        borderColor: 'rgba(58, 53, 65, 0.32)',
                        borderWidth: '1px'
                      }
                    }}
                  />
                </FormControl>
              </Grid>
              <Grid item xs={12}>
                <FormControl fullWidth>
                  <InputLabel
                    htmlFor='from-input'
                    sx={{
                      transform: 'none',
                      position: 'static',
                      '&.Mui-focused': {
                        color: 'inherit'
                      },
                      marginBottom: '5px'
                    }}
                    disableAnimation
                  >
                     Card Name
                  </InputLabel>
                  <TextField
                   placeholder='Enter your name on card'
                    sx={{
                      '& .MuiOutlinedInput-notchedOutline': {
                        borderColor: 'rgba(58, 53, 65, 0.32)',
                        borderWidth: '1px',
                        boxShadow: 'none'
                        
                      },
                      '&:hover .MuiOutlinedInput-notchedOutline': {
                        borderColor: 'rgba(58, 53, 65, 0.32)',
                        borderWidth: '1px'
                      },
                      '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                        borderColor: 'rgba(58, 53, 65, 0.32)',
                        borderWidth: '1px'
                      }
                    }}
                  />
                </FormControl>
              </Grid>
              <Grid item xs={8}>
                <FormControl fullWidth>
                  <InputLabel
                    htmlFor='from-input'
                    sx={{
                      transform: 'none',
                      position: 'static',
                      '&.Mui-focused': {
                        color: 'inherit'
                      },
                      marginBottom: '5px'
                    }}
                    disableAnimation
                  >
                     Valid Thru
                  </InputLabel>
               
                 <DatePicker
                  id="valid-thru-input"
                  selected={selectedMonth?.toDate()}
                  onChange={handleMonthChange}
                  showMonthYearPicker
                  dateFormat="MMMM yyyy"
                  customInput={<TextField fullWidth variant="outlined" />}
                />
                
                </FormControl>
              </Grid>
              <Grid item xs={4}>
                <FormControl fullWidth>
                  <InputLabel
                    htmlFor='from-input'
                    sx={{
                     visibility:'hidden',
                      transform: 'none',
                      position: 'static',
                      '&.Mui-focused': {
                        color: 'inherit'
                      },
                      marginBottom: '5px'
                    }}
                    disableAnimation
                  >
                     Cvv
                  </InputLabel>
                  <TextField
                    sx={{
                      '& .MuiOutlinedInput-notchedOutline': {
                        borderColor: 'rgba(58, 53, 65, 0.32)',
                        borderWidth: '1px',
                        boxShadow: 'none'
                        
                      },
                      '&:hover .MuiOutlinedInput-notchedOutline': {
                        borderColor: 'rgba(58, 53, 65, 0.32)',
                        borderWidth: '1px'
                      },
                      '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                        borderColor: 'rgba(58, 53, 65, 0.32)',
                        borderWidth: '1px'
                      }
                    }}
                    InputProps={{
                        endAdornment: (
                          <InputAdornment position="end" 
                          
                        //   sx={{'& .MuiTypography-root':{
                        //     fontWeight:'500',
                        //     color:theme.palette.common.black
                        //   }
                        // }}
                        
                        >
                           CVV
                          </InputAdornment>
                        ),
                      }}
                  />
                </FormControl>
              </Grid>
              </Grid>
    </>
   )
}

export default CreditCard