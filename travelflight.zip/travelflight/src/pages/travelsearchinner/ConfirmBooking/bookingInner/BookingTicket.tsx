
import { Grid,Card,Avatar, Typography } from "@mui/material"
import {CurrencyRupee} from '@mui/icons-material';
import { useTheme } from '@mui/material/styles';
import Image from 'next/image'; 

const BookingTicket = () =>  {
  
    const theme = useTheme()

    const black = theme.palette.common.black

    return (
        <>
              <Card className='dataResultBox' sx={{marginTop:'0rem',border:'none',padding:'1rem 2rem'}}>
        <Grid container spacing={2} alignItems='center' sx={{ justifyContent: 'space-between' }}>
          <Grid item sx={{ display: 'flex', justifyContent: 'center', flexDirection: 'column' }}>
            <Avatar>Air</Avatar>
            <Typography
              variant='subtitle1'
              display='block'
              gutterBottom
              sx={{ textTransform: 'capitalize', color:black }}
            >
             {/* {item.name} */}
             Air India  
            </Typography>
          </Grid>
          <Grid item>
          <Typography variant="body2" gutterBottom>
            Chhatrapati Shivaji International Airport
           </Typography>
            <Typography variant='subtitle2' display='block' gutterBottom sx={{ marginBottom: '0rem', color: black }}>
              {/* {item.arrivalTime} */}
               MUM
            </Typography>

            
            <Typography sx={{marginTop:'2rem'}} variant="body2" gutterBottom>
           Depart
           </Typography>
            <Typography variant='subtitle2' display='block' gutterBottom sx={{ color: black }}>
              {/* {item.arrivalPlace} */}
              00.45 AM
            </Typography>
          </Grid>
          <Grid item>
            <Typography
              variant='subtitle2'
              gutterBottom
              sx={{ marginBottom: '0rem', justifyContent: 'center', display: 'flex', color: black }}
            >
            {/* {item.timeDuration} */}
            2HRS
            </Typography>
            <div className='dividerBox' />
            <Typography
              variant='subtitle2'
              gutterBottom
              sx={{ justifyContent: 'center', display: 'flex', color: black }}
            >
              {/* {item.stopDuration} */}
              1-stop
            </Typography>
          </Grid>
          <Grid item>
            <Typography variant="body2" gutterBottom>
            Pune International Airport
            </Typography>
            <Typography variant='subtitle2' display='block' gutterBottom sx={{ marginBottom: '0rem', color: black }}>
            {/* {item.departureTime} */}
             MUM
            </Typography>
            <Typography   sx={{marginTop:'2rem'}} variant="body2" gutterBottom>
            Arrive
            </Typography>
            <Typography variant='subtitle2' display='block' gutterBottom sx={{ color: black }}>
            {/* {item.departurePlace} */}
            01.45 AM
            </Typography>
          </Grid>
         
         
          <Grid item>
            <Typography
              variant='subtitle2'
              display='block'
              gutterBottom
              sx={{ marginBottom: '0rem', color: theme.palette.success.dark }}
            >
              <CurrencyRupee sx={{ fontSize: '12px' }} />
              {/* {item.amount} */}
              5,777
            </Typography>
            <Typography variant='subtitle2' display='block' gutterBottom sx={{}}>
              Trip fare
            </Typography>
          </Grid>

          {/* <Grid item>
           <Image 
            src="/images/logos/barcode.png"
            alt="Freecharge Logo" 
           
            />
          </Grid> */}
            {/* <Grid item sx={{ position: 'relative', width: '100%', height: 0, paddingTop: '100%' }}>
            <Image
              src="/images/logos/barcode.png"
              alt="Freecharge Logo"
            
            />
          </Grid> */}
            <Grid item>
            <Image
              src="/images/logos/barcode.png"
              alt="Freecharge Logo"
              width={59}
              height={169}
            />
          </Grid>
          
        </Grid>
      </Card>  
        </>
    )
}
export default BookingTicket