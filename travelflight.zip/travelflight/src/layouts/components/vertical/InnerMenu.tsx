import React, { useState,useEffect } from 'react'; 
import { useRouter } from 'next/router';
import { Box } from '@mui/material';
import { useTheme } from '@mui/material/styles'

const InnerMenu = () => {
  const router = useRouter();
  const theme = useTheme();

  // State to keep track of the active menu item

  const [activeMenuItem, setActiveMenuItem] = useState('');

  // Function to handle the menu item click
  const handleMenuItemClick = (menuItem) => {
    setActiveMenuItem(menuItem);
  };


  useEffect(() => { 
    const currentPath = router.pathname.replace(/\/$/, '');
    if (currentPath === '/travelsearch'
     || currentPath === '/travelsearchinner'
     || router.pathname === '/travelsearchinner/flightlisting'
     || router.pathname === '/travelsearchinner/PayNow'
     || router.pathname === '/travelsearchinner/ConfirmBooking'
     
     ) {
      setActiveMenuItem('book');
    } else if (currentPath === '/trip'
      || currentPath === '/trip/'
      || currentPath === '/triplisting'
      ) {
      setActiveMenuItem('trips');
    } else if (currentPath === '/requests') {
      setActiveMenuItem('requests');
    }
  }, [router.pathname]);


  return (
    <>
     {(router.pathname === '/travelsearch' 
     || router.pathname === '/travelsearchinner' 
     || router.pathname === '/travelsearchinner/flightlisting'
     || router.pathname === '/travelsearchinner/PayNow'
     || router.pathname === '/travelsearchinner/ConfirmBooking'
     || router.pathname === '/trip'
     || router.pathname === '/triplisting'
     || router.pathname === '/trip/'
     || router.pathname === '/requests'
     || router.pathname === '/requestlisting'
     )  && (
    <Box display="flex" alignItems="center">

      <Box
        component="span"

        // sx={{
        //   padding: '0.5rem 1rem',
        //   color: activeMenuItem === 'book' ? theme.palette.common.black : theme.palette.common.black,
        //   fontWeight: activeMenuItem === 'book' ? 'bold' : 'normal',
        //   cursor: 'pointer',
        //   '&:hover': {
        //     color: 'primary.main',
        //     fontWeight: 'bold',
        //   },
        // }} 

        sx={{
          padding: '0.5rem 0rem',
          marginRight:'1rem',

          position: 'relative',

          color: activeMenuItem === 'book' ? theme.palette.common.black : theme.palette.common.black,
          fontWeight: activeMenuItem === 'book' ? 'bold' : 'normal',
          cursor: 'pointer',
          marginLeft:{xs:'0rem', md:'6.5rem'},

          // borderBottom: activeMenuItem === 'book' ? `2px solid ${theme.palette.common.black}` : 'none',
          // '&:hover': {
          //   color: theme.palette.primary.main,
          //   fontWeight: 'bold',
          // },

          '&::before': {
            content: '""',
            position: 'absolute',
            left: 0,
            bottom: '-8px',
            width: '100%',
            height: activeMenuItem === 'book' ? '3px' : 0,
            backgroundColor: theme.palette.common.black,
          },
          '&:hover': {
            color: theme.palette.primary.main,
            fontWeight: 'bold',
          },
        }} 
        onClick={() => handleMenuItemClick('book')}
      >
        <span onClick={() => router.push('/travelsearch/')}>Book</span>
      </Box>
      <Box
        component="span"
        sx={{
          padding: '0.5rem 0rem',
          marginLeft:'1rem',
          marginRight:'1rem',
          color: activeMenuItem === 'trips' ? theme.palette.common.black : theme.palette.common.black,
          fontWeight: activeMenuItem === 'trips' ? 'bold' : 'normal',
          cursor: 'pointer',
          position: 'relative',
          '&::before': {
            content: '""',
            position: 'absolute',
            left: 0,
            bottom: '-8px',
            width: '100%',
            height: activeMenuItem === 'trips' ? '3px' : 0,
            backgroundColor: theme.palette.common.black,
          },
          '&:hover': {
            color: 'primary.main',
            fontWeight: 'bold',
          },
        }}

        // onClick={() => handleMenuItemClick('trips')}

        onClick={() => {
          handleMenuItemClick('trips');
          router.push('/trip');
        }}
      >

        {/* <span onClick={() => router.push('/trip')}>Trips</span> */}

        <span>Trips</span>
      </Box>
      <Box
        component="span"
        sx={{
          padding: '0.5rem 0rem',
          marginLeft:'1rem',
          marginRight:'1rem',
          color: activeMenuItem === 'requests' ? theme.palette.common.black : theme.palette.common.black,
          fontWeight: activeMenuItem === 'requests' ? 'bold' : 'normal',
          cursor: 'pointer',
          position: 'relative',
          '&::before': {
            content: '""',
            position: 'absolute',
            left: 0,
            bottom: '-8px',
            width: '100%',
            height: activeMenuItem === 'requests' ? '3px' : 0,
            backgroundColor: theme.palette.common.black,
          },
          '&:hover': {
            color: 'primary.main',
            fontWeight: 'bold',
          },
        }}

        // onClick={() => handleMenuItemClick('requests')}
        
        onClick={() => {
          handleMenuItemClick('requests');
          router.push('/requests');
        }}
      >
        <span>Requests</span>
      </Box>
    </Box>
    )}
    </>
  );
};

export default InnerMenu;