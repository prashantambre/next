
// import * as React from 'react';
// import { Button, Slider, IconButton, Popover, Card, Typography, Box, FormControl, FormLabel, RadioGroup, FormControlLabel, Radio } from '@mui/material';
// import { useState, useEffect } from "react";
// import { useQuery, gql } from "@apollo/client";

// const PRICE_QUERY = gql`
//   query Prices {
//     prices {
//       type
//     }
//   }
// `;

// interface Price {
//   type: string;
// }

// interface PriceData {
//     prices: Price[];
// }
// interface PricesProps {
//   onPriceSelectedChange: (selectedValue: string) => void;
// }

// const Prices = ({ onPriceSelectedChange }: PricesProps) => {
//   const [prices, setPriceTypes] = useState<PriceData["prices"]>([]);
//   const [defaultValue, setDefaultValue] = useState(5000);
//   const { loading, error, data } = useQuery<PriceData>(PRICE_QUERY);

//   // useEffect(() => {
//   //   console.log('Durations:', data?.prices);
//   //   if (data) {
//   //     setPriceTypes(data.prices);
//   //   }
   
//   // }, [data]);

//   // useEffect(() => {
//   //   const selectedPriceValue = `Rs ${defaultValue}`;
//   //   onPriceSelectedChange(selectedPriceValue);
//   // }, [defaultValue, onPriceSelectedChange]);

//   useEffect(() => {
//     if (data) {
//       setPriceTypes(data.prices);
//     }
//   }, [data]);

//   const selectedPrice = prices.length > 0 ? prices[0] : null;

//   const handleClearClick = () => {
//     setDefaultValue(5000);
//     onPriceSelectedChange(''); 
//   };

//   const formatValue = (value: number) => `Rs ${value}`;

//   const selectedPriceValue = defaultValue > 5000 ? `up to Rs ${defaultValue}` : '';

//   useEffect(() => {
//     onPriceSelectedChange(selectedPriceValue);
//   }, [defaultValue, onPriceSelectedChange]);




//   // const selectedPrice = prices.length > 0 ? prices[0] : null;

//   // const handleClearClick = () => {
//   //   // setDefaultValue(20000);
//   //   setDefaultValue(20000);
//   //   onPriceSelectedChange(''); 
//   // };

//   // const formatValue = (value: number) => `Rs ${value}`;
//   // const selectedPriceValue = `Rs ${defaultValue}`;

//   // const selectedPriceValue = defaultValue > 5000 ? `Rs ${defaultValue}` : '';
//   // useEffect(() => {
//   //   onPriceSelectedChange(selectedPriceValue);
//   // }, [defaultValue, onPriceSelectedChange]);


//   return (
//       <>
//       <Box  sx={{ display: "flex", flexDirection: "column" }} className="filterBox">
//         <Button variant="text" className="clearButton" onClick={handleClearClick}>
//           Clear
//           {/* {selectedPriceValue} */}
//         </Button>
//         {selectedPrice && (
//           <>
//             <Typography component="h2" mt={4} mb={7}>
//               {selectedPrice.type}
//             </Typography>
//             <Slider value={defaultValue} 
//             sx={{width:'95%',color:'#F0971A !important'}}
//             // onChange={(event, newValue) => setDefaultValue(newValue as number)} 
//             onChange={(event, newValue) => setDefaultValue(newValue as number)}
//             aria-label="Default" 
//             valueLabelDisplay="on" 
//             valueLabelFormat={formatValue}    
//             max={20000} 
            
//             />
//           </>
//         )}
//       </Box>
//     </>
//   )
// }

// export default Prices;


import * as React from 'react';
import { Button, Slider, Box, Typography } from '@mui/material';
import { useState, useEffect } from "react";
import { useQuery, gql } from "@apollo/client";

const PRICE_QUERY = gql`
  query Prices {
    prices {
      type
    }
  }
`;

interface Price {
  type: string;
}

interface PriceData {
    prices: Price[];
}

interface PricesProps {
  onPriceClear: (event) => void;
  onPriceSelectedChange: (selectedValue: string) => void;
}

const Prices = ({ onPriceClear, onPriceSelectedChange }: PricesProps) => {
  const [prices, setPriceTypes] = useState<PriceData["prices"]>([]);
  const [defaultValue, setDefaultValue] = useState<number>(5000);
  const {  data } = useQuery<PriceData>(PRICE_QUERY);

  useEffect(() => {
    if (data) {
      setPriceTypes(data.prices);
    }
  }, [data]);

  // Load selected price from localStorage on component mount
  useEffect(() => {
    const storedSelectedPrice = localStorage.getItem('selectedPrice');
    if (storedSelectedPrice) {
      const parsedPrice = JSON.parse(storedSelectedPrice);
      setDefaultValue(parsedPrice);
    }
  }, []);

  // Save selected price to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem('selectedPrice', JSON.stringify(defaultValue));
  }, [defaultValue]);

  const selectedPriceValue = defaultValue > 5000 ? `up to Rs ${defaultValue}` : '';

  useEffect(() => {
    onPriceSelectedChange(selectedPriceValue);
  }, [defaultValue, onPriceSelectedChange]);

  const handleClearClick = () => {
    setDefaultValue(5000);
    onPriceSelectedChange('');
    onPriceClear(event);
  };

  const formatValue = (value: number) => `Rs ${value}`;

  return (
    <>
      <Box sx={{ display: "flex", flexDirection: "column" }} className="filterBox">
        <Button variant="text" className="clearButton" onClick={handleClearClick}>
          Clear
        </Button>
        {prices.length > 0 && (
          <>
            <Typography component="h2" mt={4} mb={7}>
              {prices[0].type}
            </Typography>
            <Slider
              value={defaultValue}
              sx={{ width: '95%', color: '#F0971A !important' }}
              onChange={(event, newValue) => setDefaultValue(newValue as number)}
              aria-label="Default"
              valueLabelDisplay="on"
              valueLabelFormat={formatValue}
              max={20000}
            />
          </>
        )}
      </Box>
    </>
  )
}

export default Prices;


