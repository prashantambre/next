import React, { useState, useEffect } from 'react'
import {
  Grid,
  Typography,
  Divider,
  Button,
  useTheme,
  Box,
  FormControlLabel,
  Checkbox,
  Popover,
  Stack,
  Paper
} from '@mui/material'
import { CurrencyRupee, ArrowBackIos, ArrowForwardIos } from '@mui/icons-material'

import 'slick-carousel/slick/slick.css'
import 'slick-carousel/slick/slick-theme.css'
import Slider from 'react-slick'
import Image from 'next/image'
import { styled } from '@mui/material/styles'
import { useQuery } from '@apollo/client'
import { gql } from '@apollo/client'

interface SelectBaggageProps {
  onDataUpdateBaggage: (data: any) => void;
}

interface Item {
  weight: string
  price: number
}

const Item = styled(Paper)(({ theme }) => ({
  backgroundColor: theme.palette.mode === 'dark' ? '#1A2027' : '#fff',
  ...theme.typography.body2,
  padding: theme.spacing(0),
  textAlign: 'center',
  color: theme.palette.text.secondary,
  boxShadow: 'none'
}))

const SELECTBAGGAGE_QUERY = gql`
  query SelectBaggage {
    selectBaggage {
      id
      weight
      price
    }
  }
`

interface SelectBaggage {
  weight: string
  price: number
  id: number
}

interface SelectBaggageData {
  selectBaggage: SelectBaggage[]
}



// const SelectBaggageInner = ({ onDataUpdateBaggage }) => {

  const SelectBaggageInner: React.FC<SelectBaggageProps> = ({ onDataUpdateBaggage }) => {

  const [anchorEl, setAnchorEl] = useState<HTMLElement | null>(null)

  const [selectedBaggage, setselectedBaggage] = React.useState<SelectBaggageData['selectBaggage']>([])

  const { loading, data } = useQuery<SelectBaggageData>(SELECTBAGGAGE_QUERY)

  const [selectedBaggageIndexId, setselectedBaggageIndexId] = useState<number>(-1)

  const [selectedBaggageIndex, setselectedBaggageIndex] = useState<number>(-1)

  

  const [isActiveClass, setIsActiveClass] = useState<number[]>([]);

  const [selectedWeights, setSelectedWeights] = useState<string[]>([]);

  

  const theme = useTheme()
  const sliderSettings = {
    infinite: true,
    slidesToShow: 4,
    slidesToScroll: 1,
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 1,
          infinite: true
        }
      },
      {
        breakpoint: 600,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 1,
          initialSlide: 2
        }
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1
        }
      }
    ],
    prevArrow: <ArrowBackIos />, // Left arrow icon
    nextArrow: <ArrowForwardIos /> // Right arrow icon
  }

  const selectItem = [
    {
      id: 1,
      baggageId: 0,
      name: 'Shubham J'
    },
    {
      id: 2,
      baggageId: 0,
      name: 'Ashok P'
    },
    {
      id: 3,
      baggageId: 0,
      name: 'Rahul K'
    }
  ]

  const [baggageWeight, setbaggageWeight] = React.useState(selectItem)


  

  const handleSelectClick = (
    event: React.MouseEvent<HTMLButtonElement>,
    item: Item,
    index: number,
    id: number
  ): void => {
    setAnchorEl(event.currentTarget)
    setselectedBaggageIndex(index)
    setselectedBaggageIndexId(id) 


  }

  const handleClosePopover = () => {
    
    setAnchorEl(null)

    setselectedBaggageIndexId(-1)
    
  }

  const handleCheckboxChange =
    (baggageIndex: number, itemId: number, updateWeight:string) => (event: React.ChangeEvent<HTMLInputElement>) => { 

      const updatedBaggage = [...baggageWeight] 

      updatedBaggage[itemId].baggageId = event.target.checked ? baggageIndex : 0;
      
      console.log(updateWeight, 'baggageIndex');
    
    const selectedWeight = selectedBaggage.find(selected => selected.id === baggageIndex)?.weight;
  

const weightButtons = document.querySelectorAll('.item.MuiBox-root')
    
    //  let updateWeightCount = 0;
    //  console.log(updateWeightCount, 'seatButtons')
     weightButtons.forEach(button => {
      
      const buttonTextContent = button?.querySelector('.weightBox')?.textContent?.trim() || ''

      if (buttonTextContent === selectedWeight) {
        if (event.target.checked) {
           button.classList.add('active') 
        }
      }
      if (!event.target.checked && buttonTextContent === updateWeight) {
        // button.classList.remove('active')

        const popoverBox = document.querySelector('.popoverBox');
        const checkboxPop = popoverBox?.querySelectorAll('[type="checkbox"]');
    
        const checkboxesWithSameValue = Array.from(checkboxPop || []).filter(
          (item) => item instanceof HTMLInputElement && item.value === updateWeight
        );
    
        console.log(checkboxesWithSameValue, 'filter');
        
        checkboxesWithSameValue.forEach((item) => {
          if (!event.target.checked) {
            if (checkboxesWithSameValue.length === 1) {
              button.classList.remove('active')
            }
          }
        });

      
      }

      
    })

    

  
      
        
     

      const activeClassArray = updatedBaggage
     
      .filter(bag => selectedBaggageIndexId === bag.baggageId)
      .map(bag => bag.baggageId || 0); 
     
      setIsActiveClass([...activeClassArray]);

      setbaggageWeight(updatedBaggage)
     
      if (!event.target.checked) {
        
       setIsActiveClass(activeClassArray.filter(index => index !== itemId + 1));

      }


       


    }


  React.useEffect(() => {
    if (!loading && data) {

      setselectedBaggage(data.selectBaggage)
        
  
       if (data.selectBaggage.length > 0) {
      
        const baggageWeightSelect = selectedWeights.map((weight, index) => ( 
        <Typography variant="subtitle2" gutterBottom sx={{marginLeft:'10px'}}>
                 {weight}  ,  
        </Typography> 
        ));

        onDataUpdateBaggage(baggageWeightSelect);

      }
     
    }
  }, [loading, data, selectedWeights])


  return (
    <>
      <Grid container>
        <Grid item xs={12} sm={12} className='slickSliderBox vegNonVegBox' sx={{ marginTop: '2rem' }}>
          <Slider {...sliderSettings}>
            {selectedBaggage.map((item, index) =>{ 
              
// const isActive = isActiveClass.includes(index + 1);

// const isActive = isActiveClass.includes(index + 1) || previouslySelectedIndexes.includes(index );

const isActive = isActiveClass.includes(index + 1);


// const selectedWeight = selectedBaggage.find(selected => selected.id === item.id)?.weight;

// console.log(selectedWeight)
// const isActive = isActiveClass.includes(index + 1);
// const activeClassName = isActive ? `item_${index + 1} active` : `item_${index + 1}`;

// console.log(isActiveClass,)

return(
  <>
    <Box  
    // className={`item ${isActive ? 'active' : ''}`}
    //  className ={`item item_${index + 1}`}
    // className={activeClassName}
    className="item"
    key={index}>
      <Box>
        <Image
          style={{
            margin: 'auto',
            objectFit: 'cover', // Choose the appropriate value: cover, contain, fill, etc.
            width: '4rem',
            height: 'auto',
            marginLeft: '4.675rem',
            marginTop: '1rem'
          }}
          src='/images/suitcase-blue.png'
          width={100}
          height={100}
          alt=''
        />
      </Box>

      <Divider />
      <Box sx={{ padding: '10px' }}>
        <Typography
          variant='subtitle2'
          display='block'
          gutterBottom
          sx={{
            color: theme.palette.common.black,
            fontSize: '0.813rem',
            display: 'flex',
            justifyContent: 'space-between'
          }}
        >
          <Box className="weightBox">{item.weight}</Box>
          <Box>
            <CurrencyRupee sx={{ fontSize: '12px' }} />
            {item.price}
          </Box>
        </Typography>

        <Button
          variant='text'
          sx={{ textAlign: 'center', margin: '0 auto', display: 'table' }}
          onClick={event => handleSelectClick(event, item, index, item.id)}
        >
          Select
        </Button>
      </Box>
    </Box>
  </>
)
            } )}
          </Slider>

          {selectedBaggage !== null && anchorEl && selectedBaggageIndex >= 0 && (
            <Popover
              open={Boolean(anchorEl)}
              anchorEl={anchorEl}
              onClose={handleClosePopover}
              anchorOrigin={{
                vertical: 'bottom',
                horizontal: 'center'
              }}
              transformOrigin={{
                vertical: 'top',
                horizontal: 'center'
              }}
              className='popoverBox'
              id={`popover-${selectedBaggageIndexId}`}
            >
              <Box sx={{ padding: '1rem',minWidth:'14rem' }}>
                <Button
                  variant='contained'
                  sx={{
                    minWidth: 'auto',
                    width: '100%',
                    justifyContent: 'space-between',
                    background: theme.palette.common.black,
                    '&.MuiButton-root:hover': {
                      background: theme.palette.common.black
                    }
                  }}
                >
                  <Typography
                    variant='subtitle1'
                    gutterBottom
                    sx={{ color: theme.palette.common.white, marginBottom: '0rem' }}  
                  >
                    {selectedBaggage[selectedBaggageIndex].weight}
                  </Typography>
                  <Typography
                    variant='subtitle1'
                    gutterBottom
                    sx={{ color: theme.palette.common.white, marginBottom: '0rem' }}
                  >
                    <CurrencyRupee sx={{ fontSize: '12px' }} />
                    {selectedBaggage[selectedBaggageIndex].price}
                  </Typography>
                </Button>

                {/* {upcomingTrips.map((trip, index) => (   ))} */}

                {baggageWeight.map((item, index) => (
                  <Stack key={index} direction='row' spacing={1} sx={{ alignItems: 'center' }}>
                    <Item>
                      <FormControlLabel
                        sx={{
                          minWidth: '8rem',
                          '& .Mui-checked': {
                            color: `${theme.palette.secondary.light} !important`
                          }
                        }}
                        control={
                          <Checkbox
                            // checked={item.baggageId != 0 ? true:false}
                            checked={item.baggageId !== 0}
                            onChange={handleCheckboxChange(selectedBaggageIndexId, index, selectedBaggage.find(selected => selected.id === item.baggageId)?.weight || '')}
                            
                            value={selectedBaggage.find(selected => selected.id === item.baggageId)?.weight || ''}
                            name={item.name} // Use the item name as the checkbox name
                          />
                        }
                        label={
                          <Typography variant="body2" gutterBottom
                          sx={{
                            color: theme.palette.common.black, 
                          }}
                        >
                          {item.name}
                          
                        </Typography>
                        }
                      />
                    </Item>
                    <Item>
                    <Typography variant="body2" gutterBottom
                      sx={{
                        color: theme.palette.common.black, 
                      }}
                    >
                    {item.baggageId !== 0 &&
                     selectedBaggage.find(selected => selected.id === item.baggageId)?.weight}
                    </Typography>
                    </Item>
                  </Stack>
                ))}
              </Box>
            </Popover>
          )} 
        </Grid>
      </Grid>
    </>
  )
}

export default SelectBaggageInner
