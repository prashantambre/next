// ** MUI Imports
import React from 'react'
import Box from '@mui/material/Box'
import Card from '@mui/material/Card'

// import Typography from '@mui/material/Typography'

import {Clear} from '@mui/icons-material';

import {  Divider, Typography } from '@mui/material'

import { useTheme } from '@mui/material/styles'

// const Typography = dynamic(
//   () => import('@mui/material/Typography'),
//   { ssr: false }
// ) as React.ComponentType<TypographyPr

import CardHeader from '@mui/material/CardHeader'
import CardContent from '@mui/material/CardContent'

// ** Types
import { ThemeColor } from 'src/@core/layouts/types'
import { useRouter } from 'next/router'
import PromoCode from './PromoCode';



interface DataType {
  id: number
  title: string
  imgSrc: string
  include: string
  subtitle: string
  progress: number
  color: ThemeColor
  imgHeight: number 
  adultCount:number
  passenger:string
  
}

interface DataTypeMeal{
    id:number
    title:string,
    hiddenValue:number,
    count:number
}

const data: DataType[] = [
  {
    id: 1, 
    progress: 2150,
    imgHeight: 20,
    title: 'Richard Smith',
    color: 'primary',
    include: 'included',
    subtitle: 'max weight 7kg',
    imgSrc: '/images/cards/logo-zipcar.png',
    adultCount:5,
    passenger:'Adult'
  },
  {
    id: 2, 
    progress:1150,
    imgHeight: 20,
    title: '1 cabin bag',
    color: 'primary',
    include: 'included',
    subtitle: 'max weight 7kg',
    imgSrc: '/images/cards/logo-zipcar.png',
    adultCount:3,
    passenger:'Children'
  },

  {
    id: 3, 
    progress: 2150,
    imgHeight: 20,
    title: '1 cabin bag',
    color: 'primary',
    include: 'included',
    subtitle: 'max weight 7kg',
    imgSrc: '/images/cards/logo-zipcar.png',
    adultCount:4,
    passenger:'Infants'
  },
  {
    id: 4, 
    progress: 75,
    imgHeight: 20,
    title: '1 cabin bag',
    color: 'primary',
    include: 'included',
    subtitle: 'max weight 7kg',
    imgSrc: '/images/cards/logo-zipcar.png',
    adultCount:5,
    passenger:'Adult'
  },
 
]


const sectionData: DataTypeMeal[] = [
    {
       id:1,
       title:'Meal',
       hiddenValue: 1000,
       count:1
    },
    {
      id:2,
      title:'Baggage',
      hiddenValue: 2000,
      count:4
   }

 ]

 

const TotalFare = () => {
  const theme = useTheme() 
  const calculateTotal = (item:DataType):number => {
    return item.progress * item.adultCount;
  }
  const router = useRouter();

  // const handleSearchFlight = () => {
  //   router.push('/travelsearchinner/PayNow');
  // };
  
  const [dataFromChild, setDataFromChild] = React.useState('');

  
  const handleDataFromChild = (data) => {  
   
    setDataFromChild(data);
  };


  
  
  React.useEffect(() => {
    if (router.pathname === '/travelsearchinner/flightlisting') { 
      const travelSearch = document.querySelector('.navList-Box [href="/travelsearch/"] span');
      travelSearch?.classList.add('active');
    }
  }, [router.pathname]);

  

  const taxVal = 664;
  const calculateTotalFare = () => {
    let totalFare = 0;

    // Calculate total fare from the data array

    data.forEach((item) => {
      totalFare += calculateTotal(item);
    });

    // Calculate total fare from the sectionData array

    sectionData.forEach((item) => {
      totalFare += item.hiddenValue * item.count;
    });

    // Add taxes to the total fare

    const numericDataFromChild = parseFloat(dataFromChild); // or parseInt(dataFromChild, 10);
    
    //alert(numericDataFromChild)
    
    if(numericDataFromChild){
      totalFare -= numericDataFromChild;
    }
    totalFare += taxVal;

    return totalFare;
  };


   
  return (
    <>
    <Card>
      <CardHeader
        title='Price Breakup'
        titleTypographyProps={{ sx: { lineHeight: '1.6 !important',
         letterSpacing: '0.15px !important', 
         color:theme.palette.common.black
        }}}
        sx={{'&.MuiCardHeader-root':{
          paddingBottom:'0rem'
        }
      }}

        // action={
        //   <IconButton size='small' aria-label='settings' className='card-more-options' sx={{ color: 'text.secondary' }}>
        //     <DotsVertical />
        //   </IconButton>
        // }
        
      />
      <CardContent sx={{ pt: theme => `${theme.spacing(2.25)} !important`, '&.MuiCardContent-root':{
        paddingTop:'0rem !important',  
      } }}>
        {/* <Box sx={{ mb: 1.5, display: 'flex', alignItems: 'center' }}>
          <Typography variant='h4' sx={{ fontWeight: 600, fontSize: '2.125rem !important' }}>
            $24,895
          </Typography>
          <Box sx={{ display: 'flex', alignItems: 'center', color: 'success.main' }}>
            <MenuUp sx={{ fontSize: '1.875rem', verticalAlign: 'middle' }} />
            <Typography variant='body2' sx={{ fontWeight: 600, color: 'success.main' }}>
              10%
            </Typography>
          </Box>
        </Box> */}
        <Box sx={{marginTop:'1rem'}}>
        <Typography  variant='subtitle2'  sx={{ mb: 0.5, fontWeight: 600, color: 'text.primary' }}>
          Base Fare
        </Typography>
        </Box>

        {/* <Box>
        <Typography  variant='caption' sx={{ mb:0.5 }}>
          Flights
        </Typography>
        </Box> */}
        {/* <Divider/> */}

        {data.map((item: DataType, index: number) => { 
          return (
            <React.Fragment key={item.id}>
            <Box
              sx={{
                display: 'flex',
                alignItems: 'center',
                ...(index !== data.length - 1 ? { mb: 2.0 } : {}),
                marginTop:'0.5rem'
              }}
            >
              {/* <Avatar
                variant='rounded'
                sx={{
                  mr: 3,
                  width: 40,
                  height: 40,
                  backgroundColor: theme => `rgba(${theme.palette.customColors.main}, 0.04)`
                }}
              >
                <img src={item.imgSrc} alt={item.title} height={item.imgHeight} />
              </Avatar> */}
              <Box
                sx={{
                  width: '100%',
                  display: 'flex',
                  flexWrap: 'wrap',
                  alignItems: 'center',
                  justifyContent: 'space-between'
                }}
              >
                <Box sx={{ marginRight: 2, display: 'flex', flexDirection: 'column' }}>
               
                  <Typography variant='body2' sx={{ mb: 0.5, fontWeight:'inherit', color: 'text.primary' }}>
                    {item.progress} INR<Clear sx={{fontSize:'1rem', position:'relative', top:'3px'}}/>{item.adultCount} {item.passenger}

                  </Typography>
                  {/* <Typography variant='caption'>{item.subtitle}</Typography> */}
                </Box>

                <Box sx={{ minWidth: 85, display: 'flex', flexDirection: 'column' }}>
                  <Typography variant='body2' sx={{ mb: 2, fontWeight: 'inherit', color: 'text.primary', textAlign:'right' }}>
                    {calculateTotal(item)}.00 INR
                  </Typography>
                </Box>
               
              </Box>
            </Box>
            </React.Fragment>
          )
        })}

        {/* <Box sx={{marginTop:'1rem'}}>
        <Typography  variant='subtitle2'  sx={{ mb: 0.5, fontWeight: 600, color: 'text.primary' }}>
          Special services fare
        </Typography>
        </Box> */}
{/* 
        {sectionData.map((item: DataTypeMeal, index: number) => { 
          return (
            <React.Fragment key={item.id}>
            <Box
              sx={{
                display: 'flex',
                alignItems: 'center',
                marginTop:'0.5rem'
              }}
            >
             
              <Box
                sx={{
                  width: '100%',
                  display: 'flex',
                  flexWrap: 'wrap',
                  alignItems: 'center',
                  justifyContent: 'space-between'
                }}
              >
                <Box sx={{ marginRight: 2, display: 'flex', flexDirection: 'column' }}>
               
                  <Typography variant='body2' sx={{ mb: 0.5, fontWeight:'inherit', color: 'text.primary' }}>
                    {item.title} <Clear sx={{fontSize:'1rem', position:'relative', top:'3px'}}/> {item.count}

                  </Typography>
                   <Typography variant='caption'>{item.subtitle}</Typography>
                </Box>

                <Box sx={{ minWidth: 85, display: 'flex', flexDirection: 'column' }}>
                  <Typography variant='body2' sx={{ mb: 2, fontWeight: 'inherit', color: 'text.primary', textAlign:'right' }}>
                  {item.hiddenValue * item.count} .00 INR
                  </Typography>
                </Box>
               
              </Box>
            </Box>
            </React.Fragment>
          )
        })} */}

           


         <Box>
          <Divider sx={{marginTop:'1rem'}}/>

          <Box sx={{marginTop:'1rem'}}>
        <Typography  variant='subtitle2'  sx={{ mb: 0.5, fontWeight: 600, color: 'text.primary' }}>
          Fee & surcharges
        </Typography>
        </Box>

        <Box
              sx={{
                display: 'flex',
                alignItems: 'center',
                marginTop:'0.5rem'
              }}
            >
            
              <Box
                sx={{
                  width: '100%',
                  display: 'flex',
                  flexWrap: 'wrap',
                  alignItems: 'center',
                  justifyContent: 'space-between'
                }}
              >
                <Box sx={{ marginRight: 2, display: 'flex', flexDirection: 'column' }}>
               
                  <Typography variant='body2' sx={{ mb: 0.5, fontWeight:'inherit', color: 'text.primary' }}>
                    Taxes

                  </Typography>
                  {/* <Typography variant='caption'>{item.subtitle}</Typography> */}
                </Box>

                <Box sx={{ minWidth: 85, display: 'flex', flexDirection: 'column' }}>
                  <Typography variant='body2' sx={{ mb: 2, fontWeight: 'inherit', color: 'text.primary', textAlign:'right' }}>
                    {taxVal}.00 INR
                  </Typography>
                </Box>
               
              </Box>

            
            </Box>

            {/*  */}

            <Box
              sx={{
                display: 'flex',
                alignItems: 'center',
                marginTop:'0.5rem'
              }}
            >
              <Box
                sx={{
                  width: '100%',
                  display: 'flex',
                  flexWrap: 'wrap',
                  alignItems: 'center',
                  justifyContent: 'space-between'
                }}
              >
                <Box sx={{ marginRight: 2, display: 'flex', flexDirection: 'column' }}>
               
                  <Typography variant='body2' sx={{ mb: 0.5, fontWeight:'inherit', color: 'text.primary' }}>
                    Other Charges

                  </Typography>
                  {/* <Typography variant='caption'>{item.subtitle}</Typography> */}
                </Box>

                <Box sx={{ minWidth: 85, display: 'flex', flexDirection: 'column',  }}>
                  <Typography variant='body2' sx={{ mb: 2, fontWeight: 'inherit', color: 'text.primary', textAlign:'right' }}>
                    0.00 INR
                  </Typography>
                </Box>
               
              </Box>

            
            </Box>

           
            <Box
              sx={{
                display: 'flex',
                alignItems: 'center',
                marginTop:'1rem'
              }}
            >
              <Box
                sx={{
                  width: '100%',
                  display: 'flex',
                  flexWrap: 'wrap',
                  alignItems: 'center',
                  justifyContent: 'space-between'
                }}
              >
                <Box sx={{ marginRight: 2, display: 'flex', flexDirection: 'column' }}>
               
                  <Typography variant='body2' sx={{ mb: 0.5, fontWeight:'inherit', color: 'text.primary' }}>
                    Promo Offer
                  </Typography>
                  {/* <Typography variant='caption'>{item.subtitle}</Typography> */}
                </Box>

                <Box sx={{ minWidth: 85, display: 'flex', flexDirection: 'column',  }}>
                  <Typography variant='body2' sx={{ mb: 2, fontWeight: 'inherit', color: 'text.primary', textAlign:'right' }}>
                  {dataFromChild}.00 INR
                  </Typography>
                </Box>
               
              </Box>

            
            </Box>


            <Divider sx={{marginTop:'1rem'}}/>

            <Box
              sx={{
                display: 'flex',
                alignItems: 'center',
                marginTop:'1rem'
              }}
            >
              <Box
                sx={{
                  width: '100%',
                  display: 'flex',
                  flexWrap: 'wrap',
                  alignItems: 'center',
                  justifyContent: 'space-between'
                }}
              >
                <Box sx={{ marginRight: 2, display: 'flex', flexDirection: 'column' }}>
               
                  <Typography variant='body2' sx={{ mb: 0.5, fontWeight:'inherit', color: 'text.primary' }}>
                    Total Paid
                  </Typography>
                  {/* <Typography variant='caption'>{item.subtitle}</Typography> */}
                </Box>

                <Box sx={{ minWidth: 85, display: 'flex', flexDirection: 'column',  }}>
                  <Typography variant='body2' sx={{ mb: 2, fontWeight: 'inherit', color: 'text.primary', textAlign:'right' }}>
                  {calculateTotalFare()} .00 INR
                  </Typography>
                </Box>
               
              </Box>

            
            </Box>

        
                    {/* <Button variant="contained" 
                    onClick = {handleSearchFlight}
                    //  className="borderRadiusButton"  
                     sx={{backgroundColor:theme.palette.secondary.main,
                           py:3,fontWeight:'500',
                           textTransform:'Capitalize',width:'100%',
                           marginTop:'1.5rem', 
                           '&:hover':{
                            background:theme.palette.primary.light
                           }
                      }}>
                     Continue 
                   </Button> */}
             
                </Box>
      </CardContent>
    </Card>
     
    <Box  sx={{display:'none'}}>
     <PromoCode  onDataUpdate={handleDataFromChild}  /> 
   </Box>

    
    </>
  )
}

export default TotalFare;
