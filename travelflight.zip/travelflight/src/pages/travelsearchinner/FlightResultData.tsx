import React, { useEffect, useState } from 'react'
import {
  Avatar,
  Grid,
 
  Typography,
  Card,
  Divider,
  Button,
 
  useTheme,
  Chip,
  Box,
  Accordion,
  AccordionSummary,
  AccordionDetails,
  
} from '@mui/material'
import { CurrencyRupee, ArrowUpward, ArrowDownward, ExpandMore,ArrowBackIos,ArrowForwardIos,Flight  } from '@mui/icons-material' 

import IncludeBaggage from './ResultData/IncludedBaggage'
import { useQuery } from '@apollo/client'
import { gql } from '@apollo/client'
import { useRouter } from 'next/router'

import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import Slider from 'react-slick';

import { MenuItem, Menu} from '@mui/material';

const FLIGHTDETAILS_QUERY = gql`
  query FlightDetails {
    flightDetails {
      name
      arrivalTime
      arrivalPlace
      timeDuration
      stopDuration
      departureTime
      departurePlace
      weight
      amount
    }
  }
`

// const OwlCarousel = ReactOwlCarousel;

interface FlightDetails {
  name: string
  arrivalTime: string
  arrivalPlace: string
  timeDuration: string
  stopDuration: string
  departureTime: string
  departurePlace: string
  weight: string
  amount: string
}

interface FlightDetailsData {
  flightDetails: FlightDetails[]
}

const FlightResultData = () => {

  // Sample flight data

  const [flightDetails, setFlightDetails] = useState<FlightDetailsData["flightDetails"]>([]);
  const theme = useTheme()
  const black = theme.palette.common.black
  const [expandedItem, setExpandedItem] = useState<number | null>(null); // Track the expanded item index
  const [anchorEl, setAnchorEl] = useState<Element | null>(null)

 
  
  // const [isDetailsExpanded, setIsDetailsExpanded] = useState(false)
  // const handleDetailsToggle = () => {
  //   setIsDetailsExpanded(!isDetailsExpanded)
  // }

  const handleAccordionChange = (index: number) => {
    setExpandedItem(prevExpandedItem => (prevExpandedItem === index ? null : index));
  };

const { loading, data } = useQuery<FlightDetailsData>(FLIGHTDETAILS_QUERY);
useEffect(() =>{
  if(!loading && data){
    setFlightDetails(data.flightDetails)
  }
}, [loading, data])


const router = useRouter();


const handleSearchFlight = () => {
  router.push('/travelsearchinner/flightlisting');
};

React.useEffect(() => {
  if (router.pathname === '/travelsearchinner') { 
    const travelSearch = document.querySelector('.navList-Box [href="/travelsearch/"] span');
    travelSearch?.classList.add('active');
  }
}, [router.pathname]);

const sliderSettings = {
  infinite: true,
  slidesToShow: 8,
  slidesToScroll: 1,
  responsive: [
    {
      breakpoint: 1024,
      settings: {
        slidesToShow: 3,
        slidesToScroll: 1,
        infinite: true,
      },
    },
    {
      breakpoint: 600,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 1,
        initialSlide: 2,
      },
    },
    {
      breakpoint: 480,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1,
      },
    },
  ],
  prevArrow: <ArrowBackIos />, // Left arrow icon
  nextArrow: <ArrowForwardIos  />, // Right arrow icon
};


// const [sortOption, setSortOption] = useState<string>('best'); // Track the selected sorting option ('best', 'price', 'duration')

// const sortFlightResults = (option: string) => {
//   // You need to implement the sorting logic here based on the selected option
//   // For now, let's just sort by name for demonstration purposes
//   const sortedData = [...flightDetails].sort((a, b) => {
//     alert()
//     if (option === 'best') {
//       // You can add your own sorting logic for the 'best' option
//       // For example, sorting by rating or some other criteria
//       // For now, we are just sorting by the flight name as an example
//       return a.name.localeCompare(b.name);
//     } else if (option === 'price') {
//       // Sorting by price (amount)
//       return parseFloat(a.amount) - parseFloat(b.amount);
//     } else if (option === 'duration') {
//       // Sorting by duration (timeDuration)
//       // You might need to implement a custom time parsing function based on your data
//       return parseInt(a.timeDuration) - parseInt(b.timeDuration);
//     } else {
//       return 0;
//     }
//   });

//   setFlightDetails(sortedData);
// }

// const handleSortChange = (event: React.ChangeEvent<{ value: unknown }>) => {
//   const selectedOption = event.target.value as string;

//   // setSortOption(selectedOption);
//   // sortFlightResults(selectedOption);
  
// };

const handleDropdownClose = (url?: string) => {
  if (url) {
    router.push(url)
  }
  setAnchorEl(null)
}


const handleDropdownOpen = (event) => {
  setAnchorEl(event.currentTarget)
}

const styles = {
  py: 2,
  px: 4,
  width: '100%',
  display: 'flex',
  alignItems: 'center',
  color: 'text.primary',
  textDecoration: 'none',
  '& svg': {
    fontSize: '1.375rem',
    color: 'text.secondary'
  }
}



  return (
    <>
    {/* <Card className='boxShadow' sx={{padding:'2rem', 
      // '& .slick-slider':{
      //   padding:'2rem',
      //   background:'red'
      // },
      '& .slick-arrow':{
        color:'green',
        fill:'inherit'
      }
     }}> */}
      <Grid container sx={{marginTop:'2rem'}}>
       
        {/* <Grid item xs={12} sm={1} sx={{marginTop:'2rem'}}>
        <CalendarMonthIcon sx={{
          '&.MuiSvgIcon-root ':{
            color:theme.palette.primary.light, 
          },
          padding:'10px',
          border:'1px solid #E4E6E8',
          width:'3.5625rem', 
          height:'3.5625rem',
          borderRadius:'10px'
        }}/>
        </Grid> */}

         <Grid item xs={12}  >
         <Divider sx={{background:theme.palette.secondary.light}}/>
         </Grid>
        
        <Card sx={{marginTop:'0.5rem', paddingTop:'0.5rem',paddingLeft:'0.5rem'}}>
        <Grid item xs={12} >
        
        <Button variant="contained"
         sx={{
          '&.MuiButton-root':{
            background:theme.palette.common.black,
            padding:'5px 10px',
          },
          '&.MuiButton-root :hover':{
            background:'transparent'
          }
        }}
         
         >
          MUM 
               <Flight
                  sx={{
                    rotate: '90deg',
                    marginRight:'10px',
                    position: 'relative',
                    left: '4px',
                    top: '0px',
                    fontSize: '1.25rem'
                  }}
                /> DEL</Button>
        <Button variant="text" sx={{color:'#6D6B6B'}}>DEL 
        <Flight
                  sx={{
                    rotate: '90deg',
                    marginRight:'10px',
                    position: 'relative',
                    left: '4px',
                    top: '0px',
                    fontSize: '1.25rem'
                  }}
                />
        MUM</Button>
      
              </Grid>
        <Grid item xs={12} sm={12} className='slickSliderBox' >
           
      <Slider {...sliderSettings} >
     <Box className='item'> 
          <Typography variant='subtitle2' display='block' gutterBottom sx={{}}>
          Mon <br /> 20 march
            </Typography>
           <Typography
              variant='subtitle2'
              display='block'
              gutterBottom
              sx={{ marginBottom: '0rem', color: theme.palette.common.black }}
            >
              <CurrencyRupee sx={{ fontSize: '12px' }} />
               4,577
          </Typography>  
      </Box>
      {/*  */}

      <Box className='item'> 
          <Typography variant='subtitle2' display='block' gutterBottom sx={{}}>
          Tue<br /> 20 march
            </Typography>
           <Typography
              variant='subtitle2'
              display='block'
              gutterBottom
              sx={{ marginBottom: '0rem', color: theme.palette.common.black }}
            >
              <CurrencyRupee sx={{ fontSize: '12px' }} />
               4,577
          </Typography>  
      </Box>
      {/*  */}

      <Box className='item'> 
          <Typography variant='subtitle2' display='block' gutterBottom sx={{}}>
          Wed <br /> 20 march
            </Typography>
           <Typography
              variant='subtitle2'
              display='block'
              gutterBottom
              sx={{ marginBottom: '0rem', color: theme.palette.common.black }}
            >
              <CurrencyRupee sx={{ fontSize: '12px' }} />
               4,577
          </Typography>  
      </Box>
      {/*  */}
      <Box className='item' sx={{
           position:'relative',
           borderBottom:'2px solid',
           borderColor:theme.palette.secondary.light,
          '&:after':{
            content:'""',
            position:'absolute',
            border:'2px solid',
            borderColor:theme.palette.secondary.light,
            bottom:'-8px',
            left:'45%', 
            height:'15px',
            width:'15px',
            rotate:'-135deg',
            borderTop:'none',
            borderLeft:'none',
            background:theme.palette.common.white
          }
      }}> 
          <Typography variant='subtitle2' display='block' gutterBottom sx={{color: theme.palette.secondary.main}}>
          Thus <br /> 20 march
            </Typography>
           <Typography
              variant='subtitle2'
              display='block'
              gutterBottom
              sx={{ marginBottom: '0rem', color: theme.palette.secondary.main }}
            >
              <CurrencyRupee sx={{ fontSize: '12px' }} />
               4,577
          </Typography>  
      </Box>
      {/*  */}

      <Box className='item'> 
          <Typography variant='subtitle2' display='block' gutterBottom sx={{}}>
          Fri<br /> 20 march
            </Typography>
           <Typography
              variant='subtitle2'
              display='block'
              gutterBottom
              sx={{ marginBottom: '0rem', color: theme.palette.success.dark }}
            >
              <CurrencyRupee sx={{ fontSize: '12px' }} />
               4,577
          </Typography>  
      </Box>
      {/*  */}

      <Box className='item'> 
          <Typography variant='subtitle2' display='block' gutterBottom sx={{}}>
          Sat <br /> 20 march
            </Typography>
           <Typography
              variant='subtitle2'
              display='block'
              gutterBottom
              sx={{ marginBottom: '0rem', color: theme.palette.common.black }}
            >
              <CurrencyRupee sx={{ fontSize: '12px' }} />
               4,577
          </Typography>  
      </Box>
      {/*  */}

      <Box className='item'> 
          <Typography variant='subtitle2' display='block' gutterBottom sx={{}}>
          Sun  <br /> 20 march
            </Typography>
           <Typography
              variant='subtitle2'
              display='block'
              gutterBottom
              sx={{ marginBottom: '0rem', color: theme.palette.error.dark }}
            >
              <CurrencyRupee sx={{ fontSize: '12px' }} />
               4,577
          </Typography>  
      </Box>
      {/*  */}

      <Box className='item'> 
          <Typography variant='subtitle2' display='block' gutterBottom sx={{}}>
          Mon <br /> 20 march
            </Typography>
           <Typography
              variant='subtitle2'
              display='block'
              gutterBottom
              sx={{ marginBottom: '0rem', color: theme.palette.error.dark }}
            >
              <CurrencyRupee sx={{ fontSize: '12px' }} />
               4,577
          </Typography>  
      </Box>

      {/*  */}

      <Box className='item'> 
          <Typography variant='subtitle2' display='block' gutterBottom sx={{}}>
          Tue <br /> 20 march
            </Typography>
           <Typography
              variant='subtitle2'
              display='block'
              gutterBottom
              sx={{ marginBottom: '0rem', color: theme.palette.common.black }}
            >
              <CurrencyRupee sx={{ fontSize: '12px' }} />
               4,577
          </Typography>  
      </Box>

     {/* Add more items as needed */}

   </Slider>
    
        </Grid>

        </Card>
      </Grid>

     
    
{/* 
    </Card>
     */}
 


       {/* <Grid container spacing={2} alignItems='center' sx={{ justifyContent: 'flex-end', marginTop:'2rem' }}>
          <Grid item>
             <Typography component={'h3'} sx={{ fontWeight: '600' }}>
                 Sort by: <ArrowUpward sx={{ '&.MuiSvgIcon-root':{
                    position:'relative',
                    left:'-5px',
                    top:'0px',
                    fontSize:'16px'  
                  }
                  }}/> 
                  <ArrowDownward  sx={{
                  '&.MuiSvgIcon-root':{
                    position:'relative',
                    left:'-11px',
                    top:'9px',
                    fontSize:'16px'  
                  }
                 }}/>
              </Typography>       
          </Grid>

       </Grid> */}

       {/* <Grid container spacing={2} alignItems='center' sx={{ justifyContent: 'flex-end', marginTop: '2rem' }}>
        <Grid item>
          <Typography component={'h3'} sx={{ fontWeight: '600' }}>
            Sort by:{' '}
            <Select
              value={sortOption}
              onChange={handleSortChange}
              sx={{
                '& .MuiSelect-select': {
                  paddingLeft: '0.5rem',
                  paddingRight: '2.5rem', // To make space for the select icon
                },
              }}
            >
              <MenuItem value='best'>Best Flights</MenuItem>
              <MenuItem value='price'>Price</MenuItem>
              <MenuItem value='duration'>Duration</MenuItem>
            </Select>
          </Typography>
        </Grid>
      </Grid> */}

<Grid container spacing={2} alignItems='center' sx={{ justifyContent: 'flex-end', marginTop:'1rem' }}>
          <Grid item>
          <Box onClick={handleDropdownOpen}>

          {/* <Box sx={{ display: 'flex', alignItems: 'center', cursor:'pointer' }}>
           
           
            <Box sx={{ display: 'flex', marginLeft: 3, alignItems: 'flex-start', flexDirection: 'column' }}>
              <Typography sx={{ fontWeight: 600 }}>John Doe</Typography>
              <Typography variant='body2' sx={{ fontSize: '0.8rem', color: 'text.disabled' }}>
                Admin
              </Typography>
            </Box>
          
            <ModeToggler settings={settings} saveSettings={saveSettings} /> 
          </Box> */}

<Typography component={'h3'} sx={{ fontWeight: '600',cursor:'pointer' }}>
                 Sort by: <ArrowUpward sx={{ '&.MuiSvgIcon-root':{
                    position:'relative',
                    left:'-5px',
                    top:'0px',
                    fontSize:'16px'  ,
                    
                  }
                  }}/> 
                  <ArrowDownward  sx={{
                  '&.MuiSvgIcon-root':{
                    position:'relative',
                    left:'-11px',
                    top:'9px',
                    fontSize:'16px'  
                  }
                 }}/>
              </Typography>     
        </Box>

      <Menu
        anchorEl={anchorEl}
        open={Boolean(anchorEl)}
        onClose={() => handleDropdownClose()}
        sx={{ '& .MuiMenu-paper': { width: 230, marginTop: 4 } }}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
        transformOrigin={{ vertical: 'top', horizontal: 'right' }}
      >

       
        
        {/* <Divider sx={{ mt: 0, mb: 1 }} /> */}

        <MenuItem sx={{ p: 0 }} onClick={() => handleDropdownClose()}>
          <Box sx={styles}>

            {/* <AccountOutline sx={{ marginRight: 2 }} /> */}

            Best Flights
          </Box>
        </MenuItem>
      
{/*        
        <Divider />
        */}
       
        <MenuItem sx={{ p: 0 }} onClick={() => handleDropdownClose()}>
          <Box sx={styles}>

            {/* <HelpCircleOutline sx={{ marginRight: 2 }} /> */}

            Price
          </Box>
        </MenuItem>

        {/* <Divider /> */}

        <MenuItem sx={{ p: 0 }} onClick={() => handleDropdownClose()}>
          <Box sx={styles}>

            {/* <CogOutline sx={{ marginRight: 2 }} /> */}

             Duration
          </Box>
        </MenuItem>

        {/* <Divider /> */}

        <MenuItem sx={{ py: 2 }} onClick={() => handleDropdownClose('/pages/login')}>

          {/* <LogoutVariant sx={{ marginRight: 2, fontSize: '1.375rem', color: 'text.secondary' }} /> */}

           Departure Time
        </MenuItem>

        {/* <Divider /> */}

        <MenuItem sx={{ py: 2 }} onClick={() => handleDropdownClose('/pages/login')}>

          {/* <LogoutVariant sx={{ marginRight: 2, fontSize: '1.375rem', color: 'text.secondary' }} /> */}

          Arrival Time
        </MenuItem>
        <MenuItem sx={{ py: 2 }} onClick={() => handleDropdownClose('/pages/login')}>

          {/* <LogoutVariant sx={{ marginRight: 2, fontSize: '1.375rem', color: 'text.secondary' }} /> */}

          CO2 emissions
        </MenuItem>
      </Menu>

          </Grid>
  </Grid>



     


     {flightDetails?.map((item, index)=>(
      <React.Fragment key={index}>
        <Card className='dataResultBox'>
        <Grid container spacing={2} alignItems='center' sx={{ justifyContent: 'space-between' }}>
          <Grid item sx={{ display: 'flex', justifyContent: 'center', flexDirection: 'column' }}>
            <Avatar>Air</Avatar>
            <Typography
              variant='subtitle1'
              display='block'
              gutterBottom
              sx={{ textTransform: 'capitalize', color: black }}
            >
             {item.name}
            </Typography>
          </Grid>
          <Grid item>
            <Typography variant='subtitle2' display='block' gutterBottom sx={{ marginBottom: '0rem', color: black }}>
              {item.arrivalTime}
            </Typography>
            <Typography variant='subtitle2' display='block' gutterBottom sx={{ color: black }}>
              {item.arrivalPlace}
            </Typography>
          </Grid>
          <Grid item>
            <Typography
              variant='subtitle2'
              gutterBottom
              sx={{ marginBottom: '0rem', justifyContent: 'center', display: 'flex', color: black }}
            >
            {item.timeDuration}
            </Typography>
            <div className='dividerBox' />
            <Typography
              variant='subtitle2'
              gutterBottom
              sx={{ justifyContent: 'center', display: 'flex', color: black }}
            >
              {item.stopDuration}
            </Typography>
          </Grid>
          <Grid item>
            <Typography variant='subtitle2' display='block' gutterBottom sx={{ marginBottom: '0rem', color: black }}>
            {item.departureTime}
            </Typography>
            <Typography variant='subtitle2' display='block' gutterBottom sx={{ color: black }}>
            {item.departurePlace}
            </Typography>
          </Grid>
          <Grid item>
            <Typography
              variant='subtitle2'
              display='block'
              gutterBottom
              sx={{ marginBottom: '0rem', cursor: 'pointer' }}

              // onClick={handleDetailsToggle}

              onClick={() => handleAccordionChange(index)}
            >
              Flight Details  
              <ExpandMore />
            </Typography>
          </Grid>
          <Grid item>
            <Typography variant='subtitle2' display='block' gutterBottom sx={{ marginBottom: '0rem', color: black }}>
               {item.weight}
            </Typography>
            <Typography variant='subtitle2' display='block' gutterBottom sx={{}}>
              Avg emissions
            </Typography>
          </Grid>
          <Grid item>
            <Typography
              variant='subtitle2'
              display='block'
              gutterBottom
              sx={{ marginBottom: '0rem', color: theme.palette.success.dark }}
            >
              <CurrencyRupee sx={{ fontSize: '12px' }} />
              {item.amount}
            </Typography>
            <Typography variant='subtitle2' display='block' gutterBottom sx={{}}>
              Trip fare
            </Typography>
          </Grid>
          <Grid item>
            <Chip
              label='Out of Policy'
              sx={{
                float: 'right'
              }}
            />
            <Box sx={{ display: 'block' }}>
              <Button
                variant='contained'
                className='borderRadiusButton'

                // onClick = {()=> router.push('/travelsearchinner/flightlisting') }

                onClick={handleSearchFlight} 
                sx={{
                  backgroundColor: 'transparent',
                  marginTop: '0.5rem',
                  border: '1px solid black',
                  '&:hover': {
                    background: theme.palette.secondary.main,
                    color: '#fff'
                  },
                  color: theme.palette.secondary.main
                }}
              >  
                Search Flight  
              </Button>
            </Box>
          </Grid>
          <Grid
            item
            xs={12}
            sx={{
              '&.MuiGrid-item': {
                paddingTop: '0rem'
              }
            }}
          >
            <Accordion

              // expanded={isDetailsExpanded}

              expanded={expandedItem === index}
              sx={{
                boxShadow: 'none',
                '&.Mui-expanded': {
                  boxShadow: 'none'
                }
              }}
            >
              <AccordionSummary
                sx={{
                  minHeight: '0px',
                  height: '0rem',
                  '&.Mui-expanded': {
                    minHeight: 0,
                    height: '1rem'
                  }
                }}
              >

                {/* <Typography variant='body2'>Additional content</Typography> */}

              </AccordionSummary>
              <AccordionDetails>
                <Grid container spacing={2} alignItems='center'>
                  <Grid item xs={6}>
                    <IncludeBaggage />
                  </Grid>
                  <Grid item xs={6}>
                    <IncludeBaggage />
                  </Grid>
                </Grid>
              </AccordionDetails>
            </Accordion>
          </Grid>
        </Grid>
      </Card>  
      </React.Fragment>
     ))} 
    </>
  )
}

export default FlightResultData
