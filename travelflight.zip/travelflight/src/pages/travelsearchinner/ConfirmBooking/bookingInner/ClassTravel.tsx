import React from 'react'
import {  Box, Card, CardContent, Typography, CardHeader,  } from '@mui/material'
import { useTheme } from '@mui/material/styles'


const travelerData = [
  { travelerName: 'Nill Johnson', seatNumber: '32A' },
  { travelerName: 'John Doe', seatNumber: '15B' },
  { travelerName: 'Jane Smith', seatNumber: '20C' },
  { travelerName: 'Tom Richards', seatNumber:'34B'},
  { travelerName: 'Anita Letterback', seatNumber:'36A'},
  { travelerName: 'Ron Smith', seatNumber:'36C'},
  { travelerName: 'Rost Smiths', seatNumber:'39C'}
]

const ClassTravel = () => {

  const theme = useTheme()

  return (
    <>
      <Card sx={{
        borderTopLeftRadius:'0px',
        borderBottomLeftRadius:'0px',
        marginTop:'1px'
      }}>
      <Typography variant="h6" gutterBottom
       sx={{background:theme.palette.secondary.main,
        color:theme.palette.common.white,
        padding:' 0.5rem 2rem',
       
       }}>
        ECONOMY CLASS
      </Typography>
        <CardHeader
          title='Traveler Info'
          titleTypographyProps={{
            sx: { lineHeight: '1.6 !important', letterSpacing: '0.15px !important', color: theme.palette.common.black }
          }}
          sx={{
            '&.MuiCardHeader-root': {
              paddingBottom: '0rem',
            },
            padding:'1rem 2rem'
          }}
        />
        <CardContent
          sx={{
            pt: theme => `${theme.spacing(2.25)} !important`,
            '&.MuiCardContent-root': {
              paddingTop: '0rem !important'
            },
            padding:'0rem 2rem'
          }}
        >

          <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
            <Typography variant='subtitle1' sx={{color:'#D9D9D9',fontSize:'0.75rem',mb: 1 }}>
              Name
            </Typography>
            <Typography variant='subtitle1' sx={{color:'#D9D9D9',fontSize:'0.75rem',mb: 1 }}>
              Seat
            </Typography>
          </Box>

          {travelerData.map((data) => ( 
            <React.Fragment key={data.seatNumber}>
              <Box
                sx={{
                  width: '100%',
                  display: 'flex',
                  flexWrap: 'wrap',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                 
                }}
              >
                <Box sx={{ marginRight: 2, display: 'flex', flexDirection: 'column' }}>
                  <Typography variant='body2' sx={{ mb: 0.5, fontWeight: 'inherit', color: 'text.primary' }}>
                    {data.travelerName}
                  </Typography>
                </Box>

                <Box sx={{ minWidth: 85, display: 'flex', flexDirection: 'column' }}>
                  <Typography
                    variant='body2'
                    sx={{ mb: 2, fontWeight: 'inherit', color: 'text.primary', textAlign: 'right' }}
                  >
                    {data.seatNumber}
                  </Typography>
                </Box>
              </Box>
            </React.Fragment>
          ))}
        </CardContent>
      </Card>
    </>
  )
}

export default ClassTravel
