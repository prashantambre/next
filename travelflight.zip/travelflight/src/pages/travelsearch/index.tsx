

// ** MUI Imports

import Grid from '@mui/material/Grid'

// import Typography from '@mui/material/Typography'


import dynamic from 'next/dynamic' // import the dynamic function from next/dynamic

// Dynamically import the Typography component  

const Typography = dynamic(() => import('@mui/material/Typography'), {
  ssr: false // Set `ssr` option to `false` to prevent hydration errors
})

// ** Demo Components Imports

import TimeTravel from 'src/pages/travelsearch/TimeTravel'

const Travel = () => {
  return (
    <>
    <Grid container spacing={{ xs: 6, sm: 6, md: 12 }} justifyContent="center"> 
      <Grid item xs={12} sx={{ pb: 4, pt: theme => `${theme.spacing(17.5)} !important` }}>
      <Typography variant='h6' sx={{ textAlign: 'center' }}>Hey John</Typography>
        <Typography variant='h4' sx={{ textAlign: 'center' }}>Time to Travel</Typography>
      </Grid>
      <Grid item xs={12} md={9} sx={{position:'relative'}} >
        <TimeTravel />
      </Grid> 
    </Grid>
    </>
  )
}

export default Travel
