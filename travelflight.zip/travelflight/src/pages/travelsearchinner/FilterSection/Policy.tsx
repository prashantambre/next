// import * as React from "react";
// import {
//   Box,
//   FormControlLabel,
//   Checkbox,
//   Button,
//   Tooltip,
//   IconButton,
// } from "@mui/material";
// import { useQuery, gql } from "@apollo/client";

// const POLICY_QUERY = gql`
//   query Policies {
//     policies {
//       type
//     }
//   }
// `;

// interface Policy {
//   type: string;
//   checked: boolean;
// }

// interface PolicyData {
//   policies: Policy[];
// }

// interface PolicyFilterProps {
//   onPolicySelectedChange: (selectedValue: string[]) => void;
// }

// const Policy = ({ onPolicySelectedChange }: PolicyFilterProps) => {
//   const [policies, setPolicies] = React.useState<PolicyData["policies"]>([]);
//   const [policySelectedValue, setPolicySelectedValue] = React.useState<string[]>(
//     []
//   );
//   const { loading, error, data } = useQuery<PolicyData>(POLICY_QUERY);

//   React.useEffect(() => {
//     if (!loading && data) {
//       const policyTypesWithChecked = data.policies.map((policy) => ({
//         ...policy,
//         checked: policySelectedValue.indexOf(policy.type) > -1,
//       }));
//       setPolicies(policyTypesWithChecked);
//     }
//   }, [loading, data, policySelectedValue]);

//   const handleTogglePolicy = (index: number) => {
//     const updatedPolicies = [...policies];
//     updatedPolicies[index].checked = !updatedPolicies[index].checked;
//     setPolicies(updatedPolicies);

//     const selectedPolicies = updatedPolicies
//       .filter((policy) => policy.checked)
//       .map((policy) => policy.type);
//     setPolicySelectedValue(selectedPolicies);
//     onPolicySelectedChange(selectedPolicies);
//   };

//   const handleClearAll = () => {
//     const updatedPolicies = policies.map((policy) => ({
//       ...policy,
//       checked: false,
//     }));
//     setPolicies(updatedPolicies);
//   };

//   const handleSelectAll = () => {
//     const allChecked = policies.every((policy) => policy.checked);
//     const updatedPolicies = policies.map((policy) => ({
//       ...policy,
//       checked: !allChecked,
//     }));
//     setPolicies(updatedPolicies);
//   };

//   if (loading) return <p>Loading...</p>;
//   if (error || !data) return <p>Error :</p>;

//   return (
//     <>
//       <Box sx={{ display: "flex", flexDirection: "column" }} className="filterBox">
//         <Button
//           variant="text"
//           onClick={handleClearAll}
//           className="clearButton"
//         >
//           Clear
//         </Button>
//         <FormControlLabel
//           control={
//             <Checkbox
//               checked={policies.every((policy) => policy.checked)}
//               indeterminate={
//                 policies.some((policy) => policy.checked) &&
//                 !policies.every((policy) => policy.checked)
//               }
//               onChange={handleSelectAll}
//             />
//           }
//           label={
//             policies.every((policy) => policy.checked) ? "All Policies" : "All Policies"
//           }
//           sx={{
//             "& .Mui-checked": {
//               color: "#F0971A !important",
//             },
//             textTransform: "capitalize",
//             "& .MuiCheckbox-indeterminate": {
//               color: "#F0971A !important",
//             },
//           }}
//         />
//         {policies.map((policy, index) => (
//           <Tooltip
//             key={policy.type}
//             title={
//               policy.checked ? (
//                 <IconButton
//                   onClick={() => {
//                     handleTogglePolicy(index);
//                   }}
//                 >
//                   Only
//                 </IconButton>
//               ) : (
//                 ""
//               )
//             }
//             placement="right"
//             classes={{ tooltip: "tooltipBox" }}
//           >
//             <FormControlLabel
//               key={policy.type}
//               control={
//                 <Checkbox
//                   checked={policy.checked}
//                   onChange={() => handleTogglePolicy(index)}
//                   sx={{
//                     "& .Mui-checked": {
//                       color: "#F0971A !important",
//                     },
//                   }}
//                 />
//               }
//               label={policy.type}
//               sx={{
//                 "& .Mui-checked": {
//                   color: "#F0971A !important",
//                 },
//                 textTransform: "capitalize",
//                 "& .MuiCheckbox-indeterminate": {
//                   color: "#F0971A !important",
//                 },
//               }}
//             />
//           </Tooltip>
//         ))}
//       </Box>
//     </>
//   );
// };

// export default Policy;


import * as React from "react";
import {
  Box,
  FormControlLabel,
  Checkbox,
  Button,
  Tooltip,
  IconButton,
} from "@mui/material";
import { useQuery, gql } from "@apollo/client";

const POLICY_QUERY = gql`
  query Policies {
    policies {
      type
    }
  }
`;

interface Policy {
  type: string;
  checked: boolean;
}

interface PolicyData {
  policies: Policy[];
}

interface PolicyFilterProps {
  onPolicyClear: (event) => void;
  onPolicySelectedChange: (selectedValue: string[]) => void;
}

const Policy = ({ onPolicyClear, onPolicySelectedChange }: PolicyFilterProps) => {
  const [policies, setPolicies] = React.useState<PolicyData["policies"]>([]);
  const [policySelectedValue, setPolicySelectedValue] = React.useState<string[]>(
    []
  );
  const { loading, error, data } = useQuery<PolicyData>(POLICY_QUERY);

  React.useEffect(() => {
    if (!loading && data) {
      const policyTypesWithChecked = data.policies.map((policy) => ({
        ...policy,
        checked: policySelectedValue.indexOf(policy.type) > -1,
      }));
      setPolicies(policyTypesWithChecked);
    }
  }, [loading, data, policySelectedValue]);

  React.useEffect(() => {
    const storedSelectedPolicies = localStorage.getItem('selectedPolicies');
    if (storedSelectedPolicies) {
      const parsedPolicies = JSON.parse(storedSelectedPolicies);
      setPolicySelectedValue(parsedPolicies);
    }
  }, []);

  React.useEffect(() => {
    localStorage.setItem('selectedPolicies', JSON.stringify(policySelectedValue));
  }, [policySelectedValue]);

  const handleTogglePolicy = (index: number) => {
    const updatedPolicies = [...policies];
    updatedPolicies[index].checked = !updatedPolicies[index].checked;
    setPolicies(updatedPolicies);

    const selectedPolicies = updatedPolicies
      .filter((policy) => policy.checked)
      .map((policy) => policy.type);
    setPolicySelectedValue(selectedPolicies);
    onPolicySelectedChange(selectedPolicies);
  };

  const handleDeslectAll = (index: number) => {
    const updatedPolicies = policies.map((policy, i) => ({
      ...policy,
      checked: i === index,
    }));
    setPolicies(updatedPolicies);
    const selectedPolicies = updatedPolicies
    .filter((policy) => policy.checked)
    .map((policy) => policy.type);
  setPolicySelectedValue(selectedPolicies);
  onPolicySelectedChange(selectedPolicies);
  };

  const handleClearAll = () => {
    const updatedPolicies = policies.map((policy) => ({
      ...policy,
      checked: false,
    }));
    setPolicies(updatedPolicies);
    setPolicySelectedValue([]);
    onPolicyClear(event);
  };

  const handleSelectAll = () => {
    const allChecked = policies.every((policy) => policy.checked);
    const updatedPolicies = policies.map((policy) => ({
      ...policy,
      checked: !allChecked,
    }));
    setPolicies(updatedPolicies);
    const selectedPolicies = updatedPolicies
    .filter((policy) => policy.checked)
    .map((policy) => policy.type);
    setPolicySelectedValue(selectedPolicies);
    onPolicySelectedChange(selectedPolicies);
  };

  if (loading) return <p>Loading...</p>;
  if (error || !data) return <p>Error :</p>;

  return (
    <>
      <Box sx={{ display: "flex", flexDirection: "column" }} className="filterBox">
        <Button
          variant="text"
          onClick={handleClearAll}
          className="clearButton"
        >
          Clear
        </Button>
        <FormControlLabel
          control={
            <Checkbox
              checked={policies.every((policy) => policy.checked)}
              indeterminate={
                policies.some((policy) => policy.checked) &&
                !policies.every((policy) => policy.checked)
              }
              onChange={handleSelectAll}
            />
          }
          label={
            policies.every((policy) => policy.checked) ? "All Policies" : "All Policies"
          }
          sx={{
            "& .Mui-checked": {
              color: "#F0971A !important",
            },
            textTransform: "capitalize",
            "& .MuiCheckbox-indeterminate": {
              color: "#F0971A !important",
            },
          }}
        />
        {policies.map((policy, index) => (
          <Tooltip
            key={policy.type}
            title={
              policy.checked ? (
                <IconButton
                  onClick={() => {
                    handleDeslectAll(index);
                  }}
                >
                  Only
                </IconButton>
              ) : (
                ""
              )
            }
            placement="right"
            classes={{ tooltip: "tooltipBox" }}
          >
            <FormControlLabel
              key={policy.type}
              control={
                <Checkbox
                  checked={policy.checked}
                  onChange={() => handleTogglePolicy(index)}
                  sx={{
                    "& .Mui-checked": {
                      color: "#F0971A !important",
                    },
                  }}
                />
              }
              label={policy.type}
              sx={{
                "& .Mui-checked": {
                  color: "#F0971A !important",
                },
                textTransform: "capitalize",
                "& .MuiCheckbox-indeterminate": {
                  color: "#F0971A !important",
                },
              }}
            />
          </Tooltip>
        ))}
      </Box>
    </>
  );
};

export default Policy;

