// import * as React from "react";
// import {
//   Box,
//   FormControlLabel,
//   Checkbox,
//   Button,
//   Tooltip,
//   IconButton,
// } from "@mui/material";
// import { useQuery, gql } from "@apollo/client";

// const EMISSION_QUERY = gql`
//   query Emissions {
//     emissions {
//       type
//     }
//   }
// `;

// interface Emission {
//   type: string;
//   checked: boolean;
// }

// interface EmissionData {
//   emissions: Emission[];
// }

// interface EmissionFilterProps {
//   onEmissionSelectedChange: (selectedValue: string[]) => void;
// }

// const Emissions = ({ onEmissionSelectedChange }: EmissionFilterProps) => {
//   const [emissions, setEmissions] = React.useState<EmissionData["emissions"]>([]);
//   const [emissionSelectedValue, setEmissionSelectedValue] = React.useState<string[]>(
//     []
//   );
//   const { loading, error, data } = useQuery<EmissionData>(EMISSION_QUERY);

//   React.useEffect(() => {
//     if (!loading && data) {
//       const emissionTypesWithChecked = data.emissions.map((emission) => ({
//         ...emission,
//         checked: emissionSelectedValue.indexOf(emission.type) > -1,
//       }));
//       setEmissions(emissionTypesWithChecked);
//     }
//   }, [loading, data, emissionSelectedValue]);

//   const handleToggleEmission = (index: number) => {
//     const updatedEmissions = [...emissions];
//     updatedEmissions[index].checked = !updatedEmissions[index].checked;
//     setEmissions(updatedEmissions);

//     const selectedEmissions = updatedEmissions
//       .filter((emission) => emission.checked)
//       .map((emission) => emission.type);
//     setEmissionSelectedValue(selectedEmissions);
//     onEmissionSelectedChange(selectedEmissions);
//   };

//   const handleClearAll = () => {
//     const updatedEmissions = emissions.map((emission) => ({
//       ...emission,
//       checked: false,
//     }));
//     setEmissions(updatedEmissions);
//   };

//   const handleSelectAll = () => {
//     const allChecked = emissions.every((emission) => emission.checked);
//     const updatedEmissions = emissions.map((emission) => ({
//       ...emission,
//       checked: !allChecked,
//     }));
//     setEmissions(updatedEmissions);
//   };

//   if (loading) return <p>Loading...</p>;
//   if (error || !data) return <p>Error :</p>;

//   return (
//     <>
//       <Box sx={{ display: "flex", flexDirection: "column" }} className="filterBox">
//         <Button
//           variant="text"
//           onClick={handleClearAll}
//           className="clearButton"
//         >
//           Clear
//         </Button>
//         <FormControlLabel
//           control={
//             <Checkbox
//               checked={emissions.every((emission) => emission.checked)}
//               indeterminate={
//                 emissions.some((emission) => emission.checked) &&
//                 !emissions.every((emission) => emission.checked)
//               }
//               onChange={handleSelectAll}
//             />
//           }
//           label={
//             emissions.every((emission) => emission.checked) ? "All Emissions" : "All Emissions"
//           }
//           sx={{
//             "& .Mui-checked": {
//               color: "#F0971A !important",
//             },
//             textTransform: "capitalize",
//             "& .MuiCheckbox-indeterminate": {
//               color: "#F0971A !important",
//             },
//           }}
//         />
//         {emissions.map((emission, index) => (
//           <Tooltip
//             key={emission.type}
//             title={
//               emission.checked ? (
//                 <IconButton
//                   onClick={() => {
//                     handleToggleEmission(index);
//                   }}
//                 >
//                   Only
//                 </IconButton>
//               ) : (
//                 ""
//               )
//             }
//             placement="right"
//             classes={{ tooltip: "tooltipBox" }}
//           >
//             <FormControlLabel
//               key={emission.type}
//               control={
//                 <Checkbox
//                   checked={emission.checked}
//                   onChange={() => handleToggleEmission(index)}
//                   sx={{
//                     "& .Mui-checked": {
//                       color: "#F0971A !important",
//                     },
//                   }}
//                 />
//               }
//               label={emission.type}
//               sx={{
//                 "& .Mui-checked": {
//                   color: "#F0971A !important",
//                 },
//                 textTransform: "capitalize",
//                 "& .MuiCheckbox-indeterminate": {
//                   color: "#F0971A !important",
//                 },
//               }}
//             />
//           </Tooltip>
//         ))}
//       </Box>
//     </>
//   );
// };

// export default Emissions;



import * as React from "react";
import {
  Box,
  FormControlLabel,
  Checkbox,
  Button,
  Tooltip,
  IconButton,
} from "@mui/material";
import { useQuery, gql } from "@apollo/client";

const EMISSION_QUERY = gql`
  query Emissions {
    emissions {
      type
    }
  }
`;

interface Emission {
  type: string;
  checked: boolean;
}

interface EmissionData {
  emissions: Emission[];
}

interface EmissionFilterProps {
  onEmissionClear: (event) => void;
  onEmissionSelectedChange: (selectedValue: string[]) => void;
}

const Emissions = ({ onEmissionClear, onEmissionSelectedChange }: EmissionFilterProps) => {
  const [emissions, setEmissions] = React.useState<EmissionData["emissions"]>([]);
  const [emissionSelectedValue, setEmissionSelectedValue] = React.useState<string[]>(
    []
  );
  const { loading, error, data } = useQuery<EmissionData>(EMISSION_QUERY);

  React.useEffect(() => {
    if (!loading && data) {
      const emissionTypesWithChecked = data.emissions.map((emission) => ({
        ...emission,
        checked: emissionSelectedValue.indexOf(emission.type) > -1,
      }));
      setEmissions(emissionTypesWithChecked);
    }
  }, [loading, data, emissionSelectedValue]);

  React.useEffect(() => {
    const storedSelectedEmissions = localStorage.getItem('selectedEmissions');
    if (storedSelectedEmissions) {
      const parsedEmissions = JSON.parse(storedSelectedEmissions);
      setEmissionSelectedValue(parsedEmissions);
    }
  }, []);

  React.useEffect(() => {
    localStorage.setItem('selectedEmissions', JSON.stringify(emissionSelectedValue));
  }, [emissionSelectedValue]);

  const handleToggleEmission = (index: number) => {
    const updatedEmissions = [...emissions];
    updatedEmissions[index].checked = !updatedEmissions[index].checked;
    setEmissions(updatedEmissions);

    const selectedEmissions = updatedEmissions
      .filter((emission) => emission.checked)
      .map((emission) => emission.type);
    setEmissionSelectedValue(selectedEmissions);
    onEmissionSelectedChange(selectedEmissions);
  };

  const handleDeslectAll = (index: number) => {
    const updatedEmissions = emissions.map((emission, i) => ({
      ...emission,
      checked: i === index,
    }));
    setEmissions(updatedEmissions);
    const selectedEmissions = updatedEmissions
    .filter((emission) => emission.checked)
    .map((emission) => emission.type);
  setEmissionSelectedValue(selectedEmissions);
  onEmissionSelectedChange(selectedEmissions);
  };

  const handleClearAll = () => {
    const updatedEmissions = emissions.map((emission) => ({
      ...emission,
      checked: false,
    }));
    setEmissions(updatedEmissions);
    setEmissionSelectedValue([]);
    onEmissionClear(event);
  };

  const handleSelectAll = () => {
    const allChecked = emissions.every((emission) => emission.checked);
    const updatedEmissions = emissions.map((emission) => ({
      ...emission,
      checked: !allChecked,
    }));
    setEmissions(updatedEmissions);
    const selectedEmissions = updatedEmissions
    .filter((emission) => emission.checked)
    .map((emission) => emission.type);
  setEmissionSelectedValue(selectedEmissions);
  onEmissionSelectedChange(selectedEmissions);
  };

  if (loading) return <p>Loading...</p>;
  if (error || !data) return <p>Error :</p>;

  return (
    <>
      <Box sx={{ display: "flex", flexDirection: "column" }} className="filterBox">
        <Button
          variant="text"
          onClick={handleClearAll}
          className="clearButton"
        >
          Clear
        </Button>
        <FormControlLabel
          control={
            <Checkbox
              checked={emissions.every((emission) => emission.checked)}
              indeterminate={
                emissions.some((emission) => emission.checked) &&
                !emissions.every((emission) => emission.checked)
              }
              onChange={handleSelectAll}
            />
          }
          label={
            emissions.every((emission) => emission.checked) ? "All Emissions" : "All Emissions"
          }
          sx={{
            "& .Mui-checked": {
              color: "#F0971A !important",
            },
            textTransform: "capitalize",
            "& .MuiCheckbox-indeterminate": {
              color: "#F0971A !important",
            },
          }}
        />
        {emissions.map((emission, index) => (
          <Tooltip
            key={emission.type}
            title={
              emission.checked ? (
                <IconButton
                  onClick={() => {
                    handleDeslectAll(index);
                  }}
                >
                  Only
                </IconButton>
              ) : (
                ""
              )
            }
            placement="right"
            classes={{ tooltip: "tooltipBox" }}
          >
            <FormControlLabel
              key={emission.type}
              control={
                <Checkbox
                  checked={emission.checked}
                  onChange={() => handleToggleEmission(index)}
                  sx={{
                    "& .Mui-checked": {
                      color: "#F0971A !important",
                    },
                  }}
                />
              }
              label={emission.type}
              sx={{
                "& .Mui-checked": {
                  color: "#F0971A !important",
                },
                textTransform: "capitalize",
                "& .MuiCheckbox-indeterminate": {
                  color: "#F0971A !important",
                },
              }}
            />
          </Tooltip>
        ))}
      </Box>
    </>
  );
};

export default Emissions;
