import React, { useEffect, useRef, useState } from 'react';
import {
  Box,
  Autocomplete,
 
  Paper,
  
  ListItem,
  ListItemText,
  TextField,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Avatar,
  Grid,
  Select,
  MenuItem
} from '@mui/material';
import { useQuery } from '@apollo/client';
import { gql } from '@apollo/client';
import { PersonSearch, Clear, Person } from '@mui/icons-material'; 
import FormControl from '@mui/material/FormControl';
import InputLabel from '@mui/material/InputLabel';
import { useTheme } from '@mui/material/styles'

import { Close } from '@mui/icons-material';



const AIRPORT_QUERY = gql`
  query UsersClient {
    usersClient {
      name
      emailId
    }
  }
`;


// interface Top100Film {
//   cityName: string;
//   airportName: string;
//   country: string;
//   countryCode: string;
// }

// interface AirportsData {
//   top100Films: Top100Film[];
// }

interface UserClient {
  name: string;
  emailId: string;
}

interface UsersClientData {
  usersClient: UserClient[];
}


const SelectTraveler = () => {
  const [openDialog, setOpenDialog] = useState(false);
  const [autocompleteOpen, setAutocompleteOpen] = useState(false);
  const theme = useTheme()
  const [gender, setGender] = useState('');

  
  // const { loading, error, data } = useQuery<AirportsData>(AIRPORT_QUERY);
  // const top100Films = data?.top100Films || [];
  // const [selectedValues, setSelectedValues] = React.useState<Top100Film[]>([]);


  const {  data } = useQuery<UsersClientData>(AIRPORT_QUERY);
const usersClient = data?.usersClient || [];
const [selectedValues, setSelectedValues] = useState(usersClient);


  // const [anchorEl, setAnchorEl] = useState(null);

  // const handleClick = (event) => {
  //   setAnchorEl(event.currentTarget);
  // };

  // const handleClose = () => {
  //   setAnchorEl(null);
  // };

  // const open = Boolean(anchorEl);
 
  // const popoverId = open ? 'popover' : undefined;

  // const handleAutocompleteChange = (event: React.ChangeEvent<{}>, value: Top100Film[]) => {
  //   setSelectedValues(value);
  // };

  const handleAutocompleteChange = (event: React.ChangeEvent<{}>, value: UserClient[]) => { 
    setSelectedValues(value);
  };

  // const handleClearSelection = (value: Top100Film) => {
  //   setSelectedValues((prevValues) => prevValues.filter((v) => v !== value));
  // };

  const handleClearSelection = (value: UserClient) => {
    setSelectedValues((prevValues) => prevValues.filter((v) => v !== value));
  };

  const autocompleteRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (autocompleteRef.current && !autocompleteRef.current.contains(event.target as Node)) {
        setAutocompleteOpen(false);
      }
    };

    document.addEventListener('click', handleClickOutside);

    return () => {
      document.removeEventListener('click', handleClickOutside);
    };
  }, []);


  return (
    <>
      <Grid item className="customAutocomplete" ref={autocompleteRef}>
        <Autocomplete
          open={autocompleteOpen}
          disablePortal
          multiple
          id="size-small-standard-multi"
          className="boxShadowBox"
          options={usersClient}
          getOptionLabel={(option: UserClient) => `${option.name} `}

          // renderOption={(props, option: UserClient, state: AutocompleteRenderOptionState) => (

          renderOption={(props, option: UserClient) => (

            <ListItem {...props} >
               <Avatar sx={{color:'#D6D6D6',background:'#D6D6D6', marginRight:'1rem'}}><Person sx={{color:'#ffffff'}}/></Avatar>
              <ListItemText primary={option.name} secondary={option.emailId} />
            </ListItem>
          )}
          fullWidth
          sx={{
            width: 290,
            background: '#fff',
            '.MuiOutlinedInput-root': {
              padding: '2px',
            },
            '& .MuiAutocomplete-popupIndicator': {
              display: 'none', // Hide the dropdown icon
            }
          }}
          PaperComponent={({ children }) => (
            <Paper  
             sx={{ width: '18rem', 
             marginTop: 0, 
             paddingBottom: 3,
             paddingTop: 0,
             boxShadow: 'none',
             background:'#F7F7F7',
             borderTopLeftRadius:'0px',
             borderTopRightRadius:'0px'
             }}>  
                {children}
             <Box sx={{width: '100%', textAlign: 'right' }}>
              <Button
                variant='text'
                sx={{ margin: '10px',
                 background:theme.palette.common.white,
                 color:theme.palette.secondary.light,
                 border:`1px solid ${theme.palette.secondary.light}`,
                 textTransform:'capitalize',
                 padding: '0.26875rem 0.75rem'
                }}
                onClick={() => { 
                 
                  setOpenDialog(false)
                  setAutocompleteOpen(false)
                  setOpenDialog(true)
                  
                }}
               
                
              >
                Add User
              </Button>
              <Button
                variant='text' 

                // onClick={(e) => { 
                //   setOpenDialog(false) 
                //   setOpenDialog(true) 
                // }}

                sx={{ margin: '10px',
                color:theme.palette.common.white,
                background:theme.palette.secondary.light, 
                textTransform:'capitalize',
                padding: '0.26875rem 0.75rem'
               }}
              >
                Guest
              </Button>
            </Box>

        

             
            </Paper>
          )}
          renderInput={(params) => (
            <Box 
             onClick={() => { 
              setAutocompleteOpen(true)
            }}
             sx={{ display: 'flex', alignItems: 'center' }}>
            <PersonSearch sx={{ marginRight: '0.5rem',marginLeft:'0.5rem' }} />
            <TextField
              {...params}
              sx={{
                '& .MuiOutlinedInput-notchedOutline': {
                  borderColor: 'rgba(58, 53, 65, 0.32)',
                  borderWidth: '1px',
                  boxShadow: 'none',
                  border: 'none',
                  paddingLeft: '1rem',
                  width: '100%',
                },
                '& .MuiAutocomplete-inputRoot': {
                  paddingRight: '0',
                },
                '& .MuiAutocomplete-endAdornment': {
                  position: 'absolute',
                  right: 10,
                },
              }}
              variant="outlined"
              placeholder="Select Traveler"
              
            />

          </Box>
            
          )}
          onChange={handleAutocompleteChange}
         
        />
      </Grid>
      <Grid item>
        <Box sx={{ marginTop: '1rem', marginLeft: '1rem' }}>
          {selectedValues.length > 0 ? (
            <>
              {selectedValues.map((value) => (
                <React.Fragment key={value.name}>
                  <span key={value.name}>{`${value.name}`}</span>
                  <Clear sx={{color:'#FF1616',marginRight:'0.5rem',cursor:'pointer', position:'relative', top:'3px', fontSize:'1rem'}} onClick={() => handleClearSelection(value)} />
                </React.Fragment>
              ))}
            </>
          ) : (
            <span></span>
          )}
        </Box>
      </Grid>

      {/* Popover */}
      {/* <Popover
        id={popoverId} 
        anchorEl={anchorEl}
        onClose={handleClose}
        anchorOrigin={{
          vertical: 'bottom',
          horizontal: 'center',
        }}
        transformOrigin={{
          vertical: 'top',
          horizontal: 'center',
        }}
      >
        <List dense sx={{ width: '200px' }}>
          {selectedValues.map((value) => (
            <ListItem key={value.name}>
              <ListItemText primary={`${value.name}`} secondary={value.emailId} />  
            </ListItem>
          ))}
        </List>
      </Popover> */}



<Dialog open={openDialog} onClose={() => setOpenDialog(false)}
PaperProps={{ sx: { maxWidth:{xs:'42vw',sm:'58vw',md:'42vw'},overflow:'visible' } }}
>                
            <Close 
              sx={{
                '&.MuiSvgIcon-root':{
                  background:theme.palette.common.white,
                  width:'2.5rem', height:'2.5rem', position:'absolute',
                  borderRadius:'100%',
                  top:'-1rem',
                  right:'-1rem',
                  padding:'10px',
                  cursor:'pointer'

                }
              }}
            
             onClick={() => setOpenDialog(false)} />
         
              <DialogTitle>Add New User 
              </DialogTitle>
              <DialogContent>
                <Grid container spacing={6}>
                  <Grid item xs={12} md={6}>
                    <FormControl fullWidth>
                      <InputLabel
                        htmlFor='from-input'
                        sx={{
                          transform: 'none',
                          position: 'static',
                          '&.Mui-focused': {
                            color: 'inherit'
                          },
                          marginBottom: '5px'
                        }}
                        disableAnimation
                      >
                        Given Names
                        <span style={{ color: 'red' }}>*</span>
                      </InputLabel>
                      <TextField
                        sx={{
                          '& .MuiOutlinedInput-notchedOutline': {
                            borderColor: 'rgba(58, 53, 65, 0.32)',
                            borderWidth: '1px',
                            boxShadow: 'none'
                            
                          },
                          '&:hover .MuiOutlinedInput-notchedOutline': {
                            borderColor: 'rgba(58, 53, 65, 0.32)',
                            borderWidth: '1px'
                          },
                          '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                            borderColor: 'rgba(58, 53, 65, 0.32)',
                            borderWidth: '1px'
                          },
                          '& .MuiOutlinedInput-input':{
                            padding:{xs:'10.5px 14px', md:'16.5px 14px'}
                          }
                         
                        }}  

                      />
                    </FormControl>
                  </Grid>
                  <Grid item xs={12} md={6}>
                    <FormControl fullWidth>
                      <InputLabel
                        htmlFor='from-input'
                        sx={{
                          transform: 'none',
                          position: 'static',
                          '&.Mui-focused': {
                            color: 'inherit'
                          },
                          marginBottom: '5px'
                        }}
                        disableAnimation
                      >
                        Surname
                        <span style={{ color: 'red' }}>*</span>
                      </InputLabel>
                      <TextField
                        sx={{
                          '& .MuiOutlinedInput-notchedOutline': {
                            borderColor: 'rgba(58, 53, 65, 0.32)',
                            borderWidth: '1px',
                            boxShadow: 'none'
                            
                          },
                          '&:hover .MuiOutlinedInput-notchedOutline': {
                            borderColor: 'rgba(58, 53, 65, 0.32)',
                            borderWidth: '1px'
                          },
                          '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                            borderColor: 'rgba(58, 53, 65, 0.32)',
                            borderWidth: '1px'
                          },
                          '& .MuiOutlinedInput-input':{
                            padding:{xs:'10.5px 14px', md:'16.5px 14px'}
                          }
                        }}
                      />
                    </FormControl>
                  </Grid>
                  <Grid item xs={12} md={4} sx={{marginTop:'0.5rem'}}>
                    <FormControl fullWidth>
                      <InputLabel
                        htmlFor='from-input'
                        sx={{
                          transform: 'none',
                          position: 'static',
                          '&.Mui-focused': {
                            color: 'inherit'
                          },
                          marginBottom: '5px'
                        }}
                        disableAnimation
                      >
                        Mobile No
                        <span style={{ color: 'red' }}>*</span>
                      </InputLabel>
                      <TextField
                        sx={{
                          '& .MuiOutlinedInput-notchedOutline': {
                            borderColor: 'rgba(58, 53, 65, 0.32)',
                            borderWidth: '1px',
                            boxShadow: 'none'
                          
                          },
                          '&:hover .MuiOutlinedInput-notchedOutline': {
                            borderColor: 'rgba(58, 53, 65, 0.32)',
                            borderWidth: '1px'
                          },
                          '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                            borderColor: 'rgba(58, 53, 65, 0.32)',
                            borderWidth: '1px'
                          },
                          '& .MuiOutlinedInput-input':{
                            padding:{xs:'10.5px 14px', md:'16.5px 14px'}
                          }
                        }}
                      />
                    </FormControl>
                  </Grid>
                
                  <Grid item xs={12} md={4} sx={{marginTop:'0.5rem'}}>
        <FormControl fullWidth>
          <InputLabel htmlFor='gender-select'
            sx={{
              transform: 'none',
              position: 'static',
              '&.Mui-focused': {
                color: 'inherit'
              },
              marginBottom: '5px'
            }}
            disableAnimation
          >Gender <span style={{ color: 'red' }}>*</span></InputLabel>
          <Select
            value={gender}
            onChange={(e) => setGender(e.target.value)}
            
            inputProps={{
              name: 'gender',
              id: 'gender-select',
            }}
            sx={{
              '& .MuiOutlinedInput-notchedOutline': {
                borderColor: 'rgba(58, 53, 65, 0.32)',
                borderWidth: '1px',
                boxShadow: 'none'
                
              },
              '&:hover .MuiOutlinedInput-notchedOutline': {
                borderColor: 'rgba(58, 53, 65, 0.32)',
                borderWidth: '1px'
              },
              '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                borderColor: 'rgba(58, 53, 65, 0.32)',
                borderWidth: '1px'
              },
              '& .MuiOutlinedInput-input':{
                padding:{xs:'10.5px 14px', md:'16.5px 14px'}
              }
            }} 
          >
            <MenuItem value=''>Select</MenuItem>
            <MenuItem value='male'>Male</MenuItem>
            <MenuItem value='female'>Female</MenuItem>
          </Select>
        </FormControl>
      </Grid>
                  <Grid item xs={12} md={4} sx={{marginTop:'0.5rem'}}>
                    <FormControl fullWidth>
                      <InputLabel
                        htmlFor='from-input'
                        sx={{
                          transform: 'none',
                          position: 'static',
                          '&.Mui-focused': {
                            color: 'inherit'
                          },
                          marginBottom: '5px'
                        }}
                        disableAnimation
                      >
                        Email Id
                        <span style={{ color: 'red' }}>*</span>
                      </InputLabel>
                      <TextField
                        sx={{
                          '& .MuiOutlinedInput-notchedOutline': {
                            borderColor: 'rgba(58, 53, 65, 0.32)',
                            borderWidth: '1px',
                            boxShadow: 'none'
                          
                          },
                          '&:hover .MuiOutlinedInput-notchedOutline': {
                            borderColor: 'rgba(58, 53, 65, 0.32)',
                            borderWidth: '1px'
                          },
                          '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                            borderColor: 'rgba(58, 53, 65, 0.32)',
                            borderWidth: '1px'
                          },
                          '& .MuiOutlinedInput-input':{
                            padding:{xs:'10.5px 14px', md:'16.5px 14px'}
                          }
                        }}
                      />
                    </FormControl>
                  </Grid>
                </Grid>
              </DialogContent>
              <DialogActions sx={{display:'flex',alignItem:'center',justifyContent:'center'}}>
                <Button
                    variant='contained' 
                   sx={{ margin: '10px',
                   color:theme.palette.common.white,
                   background:theme.palette.secondary.light, 
                   textTransform:'capitalize',
                   minWidth:'9.813rem',
                   padding: '0.6875rem 0.75rem',
                   borderRadius:'10px',
                   marginTop:'1rem',
                   '&:hover':{
                    background:theme.palette.secondary.light
                   }
                  
                  }}
                  onClick={() => {
                  
                    setOpenDialog(false)
                  }}
                  color='primary'
                >
                  Send Invite
                </Button>
              </DialogActions>
            </Dialog>

    </>
  );
};

export default SelectTraveler;
