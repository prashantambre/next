import {
  Box,
  Button,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  Popover,
  useTheme,
  Paper,
  Typography,
  FormControlLabel,
  Checkbox,
  Stack
} from '@mui/material'
import React, { useState, useEffect } from 'react'
import { Circle } from '@mui/icons-material'
import { styled } from '@mui/material/styles'
import Image from 'next/image'

interface Item {
  id: string
  price: number
}

const Item = styled(Paper)(({ theme }) => ({
  backgroundColor: theme.palette.mode === 'dark' ? '#1A2027' : '#fff',
  ...theme.typography.body2,
  padding: theme.spacing(0),
  textAlign: 'center',
  color: theme.palette.text.secondary,
  boxShadow: 'none'
}))

const SeatSelection = ({ onSeatUpdate }) => {
  const theme = useTheme()
  const seatLayout = [
    {
      Lowerdeck: [],
      Maindeck: {
        equipmentInfo: {
          fareType: 'Refundable',
          nft: 'Refundable',
          columns: 'A|B|C|BL1|D|E|F|',
          wingsStart: 16,
          wingsEnd: 24,
          cabinName: 'F',
          cabinType: 'Y',
          cabinStart: '1',
          cabinEnd: '30'
        },
        rowInfo: {
          '1': {
            rchar: '',
            rseats: [
              {
                id: 1,
                sn: '1A',
                ns: '',
                is_available: false,
                price: 3500,
                is_seat: 1,
                is_free: false,
                sc: ''
              },
              {
                id: 2,
                sn: '1B',
                ns: '',
                is_available: false,
                price: 0,
                is_seat: 1,
                is_free: true,
                sc: ''
              },
              {
                id: 3,
                sn: '1C',
                ns: '',
                is_available: false,
                price: 3500,
                is_seat: 1,
                is_free: false,
                sc: ''
              },

              {
                id: 4,
                sn: '1BL',
                ns: '',
                is_available: false,
                price: 0,
                is_seat: 0,
                is_free: false,
                sc: ''
              },

              {
                id: 5,
                sn: '1D',
                ns: '',
                is_available: false,
                price: 3500,
                is_seat: 1,
                is_free: false,
                sc: ''
              },
              {
                id: 6,
                sn: '1E',
                ns: '',
                is_available: false,
                price: 0,
                is_seat: 1,
                is_free: true,
                sc: ''
              },
              {
                id: 7,
                sn: '1F',
                ns: '',
                is_available: true,
                price: 3500,
                is_seat: 1,
                is_free: true,
                sc: ''
              }
            ]
          },
          '2': {
            rchar: '',
            rseats: [
              {
                id: 1,
                sn: '2A',
                ns: '',
                is_available: true,
                price: 500,
                is_seat: 1,
                is_free: false,
                sc: ''
              },
              {
                id: 2,
                sn: '2B',
                ns: '',
                is_available: false,
                price: 0,
                is_seat: 1,
                is_free: false,
                sc: ''
              },
              {
                id: 3,
                sn: '2C',
                ns: '',
                is_available: true,
                price: 450,
                is_seat: 1,
                is_free: false,
                sc: ''
              },
              {
                id: 4,
                sn: '1BL',
                ns: '',
                is_available: false,
                price: 0,
                is_seat: 0,
                is_free: false,
                sc: ''
              },
              {
                id: 5,
                sn: '2D',
                ns: '',
                is_available: true,
                price: 600,
                is_seat: 1,
                is_free: false,
                sc: ''
              },
              {
                id: 6,
                sn: '2E',
                ns: '',
                is_available: false,
                price: 0,
                is_seat: 1,
                is_free: false,
                sc: ''
              },
              {
                id: 7,
                sn: '2F',
                ns: '',
                is_available: true,
                price: 600,
                is_seat: 1,
                is_free: true,
                sc: ''
              }
            ]
          },
          '3': {
            rchar: '',
            rseats: [
              {
                id: 1,
                sn: '3A',
                ns: '',
                is_available: true,
                price: 550,
                is_seat: 1,
                sc: ''
              },
              {
                id: 2,
                sn: '3B',
                ns: '',
                is_available: false,
                price: 0,
                is_seat: 1,
                is_free: false,
                sc: ''
              },
              { id: 3, sn: '3C', ns: '', is_available: true, price: 500, is_seat: 1, is_free: false, sc: '' },
              {
                id: 4,
                sn: '1BL',
                ns: '',
                is_available: false,
                price: 0,
                is_seat: 0,
                is_free: false,
                sc: ''
              },
              {
                id: 5,
                sn: '3D',
                ns: '',
                is_available: true,
                price: 500,
                is_seat: 1,
                is_free: false,
                sc: ''
              },
              {
                id: 6,
                sn: '3E',
                ns: '',
                is_available: false,
                price: 0,
                is_seat: 1,
                is_free: false,
                sc: ''
              },
              {
                id: 7,
                sn: '3F',
                ns: '',
                is_available: true,
                price: 500,
                is_seat: 1,
                is_free: true,
                sc: ''
              }
            ]
          },
          '4': {
            rchar: '',
            rseats: [
              {
                id: 1,
                sn: '4A',
                ns: '',
                is_available: true,
                price: 550,
                is_seat: 1,
                is_free: false,
                sc: ''
              },
              {
                id: 2,
                sn: '4B',
                ns: '',
                is_available: true,
                price: 1500,
                is_seat: 1,
                is_free: true,
                sc: ''
              },
              {
                id: 3,
                sn: '4C',
                ns: '',
                is_available: true,
                price: 450,
                is_seat: 1,
                is_free: false,
                sc: ''
              },
              {
                id: 4,
                sn: '1BL',
                ns: '',
                is_available: false,
                price: 0,
                is_seat: 0,
                is_free: true,
                sc: ''
              },
              {
                id: 5,
                sn: '4D',
                ns: '',
                is_available: true,
                price: 600,
                is_seat: 1,
                is_free: false,
                sc: ''
              },
              {
                id: 6,
                sn: '4E',
                ns: '',
                is_available: true,
                price: 600,
                is_seat: 1,
                is_free: false,
                sc: ''
              },
              {
                id: 8,
                sn: '4F',
                ns: '',
                is_available: true,
                price: 600,
                is_seat: 1,
                is_free: true,
                sc: ''
              }
            ]
          },
          '5': {
            rchar: '',
            rseats: [
              {
                id: 1,
                sn: '5A',
                ns: '',
                is_available: false,
                price: 350,
                is_seat: 1,
                is_free: false,
                sc: ''
              },
              {
                id: 2,
                sn: '5B',
                ns: '',
                is_available: false,
                price: 250,
                is_seat: 1,
                is_free: false,
                sc: ''
              },
              {
                id: 3,
                sn: '5C',
                ns: '',
                is_available: false,
                price: 350,
                is_seat: 1,
                is_free: false,
                sc: ''
              },
              {
                id: 4,
                sn: '1BL',
                ns: '',
                is_available: false,
                price: 0,
                is_seat: 0,
                is_free: false,
                sc: ''
              },
              {
                id: 5,
                sn: '5D',
                ns: '',
                is_available: false,
                price: 350,
                is_seat: 1,
                is_free: false,
                sc: ''
              },
              {
                id: 6,
                sn: '5E',
                ns: '',
                is_available: true,
                price: 250,
                is_seat: 1,
                is_free: false,
                sc: ''
              },
              {
                id: 7,
                sn: '5F',
                ns: '',
                is_available: false,
                price: 350,
                is_seat: 1,
                is_free: false,
                sc: ''
              }
            ]
          },
          '6': {
            rchar: '',
            rseats: [
              {
                id: 1,
                sn: '6A',
                ns: '',
                is_available: true,
                price: 350,
                is_seat: 1,
                is_free: false,
                sc: ''
              },
              {
                id: 2,
                sn: '6B',
                ns: '',
                is_available: true,
                price: 250,
                is_seat: 1,
                is_free: false,
                sc: ''
              },
              {
                id: 3,
                sn: '6C',
                ns: '',
                is_available: false,
                price: 350,
                is_seat: 1,
                is_free: false,
                sc: ''
              },
              {
                id: 4,
                sn: '1BL',
                ns: '',
                is_available: false,
                price: 0,
                is_seat: 0,
                is_free: false,
                sc: ''
              },
              {
                id: 5,
                sn: '6D',
                ns: '',
                is_available: true,
                price: 350,
                is_seat: 1,
                is_free: false,
                sc: ''
              },
              {
                id: 6,
                sn: '6E',
                ns: '',
                is_available: true,
                price: 250,
                is_seat: 1,
                is_free: false,
                sc: ''
              },
              {
                id: 7,
                sn: '6F',
                ns: '',
                is_available: false,
                price: 350,
                is_seat: 1,
                is_free: false,
                sc: ''
              }
            ]
          },
          '7': {
            rchar: '',
            rseats: [
              {
                id: 1,
                sn: '7A',
                ns: '',
                is_available: false,
                price: 350,
                is_seat: 1,
                is_free: false,
                sc: ''
              },
              {
                id: 2,
                sn: '7B',
                ns: '',
                is_available: false,
                price: 250,
                is_seat: 1,
                is_free: false,
                sc: ''
              },
              {
                id: 3,
                sn: '7C',
                ns: '',
                is_available: false,
                price: 350,
                is_seat: 1,
                is_free: false,
                sc: ''
              },
              {
                id: 4,
                sn: '1BL',
                ns: '',
                is_available: false,
                price: 0,
                is_seat: 0,
                is_free: false,
                sc: ''
              },
              {
                id: 5,
                sn: '7D',
                ns: '',
                is_available: true,
                price: 350,
                is_seat: 1,
                is_free: false,
                sc: ''
              },
              {
                id: 6,
                sn: '7E',
                ns: '',
                is_available: true,
                price: 250,
                is_seat: 1,
                is_free: false,
                sc: ''
              },
              {
                id: 7,
                sn: '7F',
                ns: '',
                is_available: false,
                price: 350,
                is_seat: 1,
                is_free: false,
                sc: ''
              }
            ]
          },
          '8': {
            rchar: '',
            rseats: [
              {
                id: 1,
                sn: '8A',
                ns: '',
                is_available: true,
                price: 350,
                is_seat: 1,
                is_free: false,
                sc: ''
              },
              {
                id: 2,
                sn: '8B',
                ns: '',
                is_available: true,
                price: 250,
                is_seat: 1,
                is_free: false,
                sc: ''
              },
              {
                id: 3,
                sn: '8C',
                ns: '',
                is_available: true,
                price: 0,
                is_seat: 1,
                is_free: true,
                sc: ''
              },
              {
                id: 4,
                sn: '1BL',
                ns: '',
                is_available: false,
                price: 0,
                is_seat: 0,
                is_free: false,
                sc: ''
              },
              {
                id: 5,
                sn: '8D',
                ns: '',
                is_available: true,
                price: 350,
                is_seat: 1,
                is_free: false,
                sc: ''
              },
              {
                id: 6,
                sn: '8E',
                ns: '',
                is_available: true,
                price: 250,
                is_seat: 1,
                is_free: false,
                sc: ''
              },
              {
                id: 7,
                sn: '8F',
                ns: '',
                is_available: true,
                price: 350,
                is_seat: 1,
                is_free: false,
                sc: ''
              }
            ]
          },
          '9': {
            rchar: '',
            rseats: [
              {
                id: 1,
                sn: '9A',
                ns: '',
                is_available: true,
                price: 350,
                is_seat: 1,
                is_free: false,
                sc: ''
              },
              {
                id: 2,
                sn: '9B',
                ns: '',
                is_available: true,
                price: 250,
                is_seat: 1,
                is_free: false,
                sc: ''
              },
              {
                id: 3,
                sn: '9C',
                ns: '',
                is_available: true,
                price: 350,
                is_seat: 1,
                is_free: false,
                sc: ''
              },
              {
                id: 4,
                sn: '1BL',
                ns: '',
                is_available: false,
                price: 0,
                is_seat: 0,
                is_free: false,
                sc: ''
              },
              {
                id: 5,
                sn: '9D',
                ns: '',
                is_available: true,
                price: 350,
                is_seat: 1,
                is_free: false,
                sc: ''
              },
              {
                id: 6,
                sn: '9E',
                ns: '',
                is_available: true,
                price: 250,
                is_seat: 1,
                is_free: false,
                sc: ''
              },
              {
                id: 7,
                sn: '9F',
                ns: '',
                is_available: true,
                price: 350,
                is_seat: 1,
                is_free: false,
                sc: ''
              }
            ]
          },
          '10': {
            rchar: '',
            rseats: [
              {
                id: 1,
                sn: '10A',
                ns: '',
                is_available: true,
                price: 350,
                is_seat: 1,
                is_free: false,
                sc: ''
              },
              {
                id: 2,
                sn: '10B',
                ns: '',
                is_available: true,
                price: 250,
                is_seat: 1,
                is_free: false,
                sc: ''
              },
              {
                id: 3,
                sn: '10C',
                ns: '',
                is_available: true,
                price: 350,
                is_seat: 1,
                is_free: false,
                sc: ''
              },
              {
                id: 4,
                sn: '1BL',
                ns: '',
                is_available: false,
                price: 0,
                is_seat: 0,
                is_free: false,
                sc: ''
              },
              {
                id: 5,
                sn: '10D',
                ns: '',
                is_available: true,
                price: 350,
                is_seat: 1,
                is_free: false,
                sc: ''
              },
              {
                id: 6,
                sn: '10E',
                ns: '',
                is_available: true,
                price: 250,
                is_seat: 1,
                is_free: false,
                sc: ''
              },
              {
                id: 7,
                sn: '10F',
                ns: '',
                is_available: true,
                price: 350,
                is_seat: 1,
                is_free: false,
                sc: ''
              }
            ]
          },
          '11': {
            rchar: '',
            rseats: [
              {
                id: 1,
                sn: '11A',
                ns: '',
                is_available: true,
                price: 350,
                is_seat: 1,
                is_free: false,
                sc: ''
              },
              {
                id: 2,
                sn: '11B',
                ns: '',
                is_available: true,
                price: 250,
                is_seat: 1,
                is_free: false,
                sc: ''
              },
              {
                id: 3,
                sn: '11C',
                ns: '',
                is_available: true,
                price: 350,
                is_seat: 1,
                is_free: false,
                sc: ''
              },
              {
                id: 4,
                sn: '1BL',
                ns: '',
                is_available: false,
                price: 0,
                is_seat: 0,
                is_free: false,
                sc: ''
              },
              {
                id: 5,
                sn: '11D',
                ns: '',
                is_available: true,
                price: 350,
                is_seat: 1,
                is_free: false,
                sc: ''
              },
              {
                id: 6,
                sn: '11E',
                ns: '',
                is_available: true,
                price: 250,
                is_seat: 1,
                is_free: false,
                sc: ''
              },
              {
                id: 7,
                sn: '11F',
                ns: '',
                is_available: true,
                price: 350,
                is_seat: 1,
                is_free: false,
                sc: ''
              }
            ]
          },
          '12': {
            rchar: '',
            rseats: [
              {
                id: 1,
                sn: '12A',
                ns: '',
                is_available: true,
                price: 350,
                is_seat: 1,
                is_free: false,
                sc: ''
              },
              {
                id: 2,
                sn: '12B',
                ns: '',
                is_available: true,
                price: 250,
                is_seat: 1,
                is_free: false,
                sc: ''
              },
              {
                id: 3,
                sn: '12C',
                ns: '',
                is_available: true,
                price: 350,
                is_seat: 1,
                is_free: false,
                sc: ''
              },
              {
                id: 4,
                sn: '1BL',
                ns: '',
                is_available: false,
                price: 0,
                is_seat: 0,
                is_free: false,
                sc: ''
              },
              {
                id: 5,
                sn: '12D',
                ns: '',
                is_available: true,
                price: 350,
                is_seat: 1,
                is_free: false,
                sc: ''
              },
              {
                id: 6,
                sn: '12E',
                ns: '',
                is_available: true,
                price: 250,
                is_seat: 1,
                is_free: false,
                sc: ''
              },
              {
                id: 7,
                sn: '12F',
                ns: '',
                is_available: false,
                price: 350,
                is_seat: 1,
                is_free: false,
                sc: ''
              }
            ]
          },
          '13': {
            rchar: '',
            rseats: [
              {
                id: 1,
                sn: '13A',
                ns: '',
                is_available: false,
                price: 0,
                is_seat: 1,
                is_free: true,
                sc: ''
              },
              {
                id: 2,
                sn: '13B',
                ns: '',
                is_available: false,
                price: 0,
                is_seat: 1,
                is_free: false,
                sc: ''
              },
              {
                id: 3,
                sn: '13C',
                ns: '',
                is_available: false,
                price: 0,
                is_seat: 1,
                is_free: false,
                sc: ''
              },
              {
                id: 4,
                sn: '1BL',
                ns: '',
                is_available: false,
                price: 0,
                is_seat: 0,
                is_free: false,
                sc: ''
              },
              {
                id: 5,
                sn: '13D',
                ns: '',
                is_available: false,
                price: 0,
                is_seat: 1,
                is_free: false,
                sc: ''
              },
              {
                id: 6,
                sn: '13E',
                ns: '',
                is_available: false,
                price: 400,
                is_seat: 1,
                is_free: false,
                sc: ''
              },
              {
                id: 7,
                sn: '13F',
                ns: '',
                is_available: false,
                price: 800,
                is_seat: 1,
                is_free: false,
                sc: ''
              }
            ]
          },
          '14': {
            rchar: '',
            rseats: [
              {
                id: 1,
                sn: '14A',
                ns: '',
                is_available: false,
                price: 0,
                is_seat: 1,
                is_free: false,
                sc: ''
              },
              {
                id: 2,
                sn: '14B',
                ns: '',
                is_available: false,
                price: 0,
                is_seat: 1,
                is_free: false,
                sc: ''
              },
              {
                id: 3,
                sn: '14C',
                ns: '',
                is_available: false,
                price: 0,
                is_seat: 1,
                is_free: false,
                sc: ''
              },
              {
                id: 4,
                sn: '1BL',
                ns: '',
                is_available: false,
                price: 0,
                is_seat: 0,
                is_free: false,
                sc: ''
              },
              {
                id: 5,
                sn: '14D',
                ns: '',
                is_available: false,
                price: 0,
                is_seat: 1,
                is_free: false,
                sc: ''
              },
              {
                id: 6,
                sn: '14E',
                ns: '',
                is_available: false,
                price: 0,
                is_seat: 1,
                is_free: false,
                sc: ''
              },
              {
                id: 7,
                sn: '14F',
                ns: '',
                is_available: false,
                price: 0,
                is_seat: 1,
                is_free: false,
                sc: ''
              }
            ]
          },
          '15': {
            rchar: '',
            rseats: [
              {
                id: 1,
                sn: '15A',
                ns: '',
                is_available: true,
                price: 500,
                is_seat: 1,
                is_free: false,
                sc: ''
              },
              {
                id: 2,
                sn: '15B',
                ns: '',
                is_available: true,
                price: 600,
                is_seat: 1,
                is_free: false,
                sc: ''
              },
              {
                id: 3,
                sn: '15C',
                ns: '',
                is_available: true,
                price: 450,
                is_seat: 1,
                is_free: false,
                sc: ''
              },
              {
                id: 4,
                sn: '1BL',
                ns: '',
                is_available: false,
                price: 0,
                is_seat: 0,
                is_free: false,
                sc: ''
              },
              {
                id: 5,
                sn: '15D',
                ns: '',
                is_available: true,
                price: 650,
                is_seat: 1,
                is_free: false,
                sc: ''
              },
              {
                id: 6,
                sn: '15E',
                ns: '',
                is_available: true,
                price: 650,
                is_seat: 1,
                is_free: false,
                sc: ''
              },
              {
                id: 7,
                sn: '15F',
                ns: '',
                is_available: true,
                price: 550,
                is_seat: 1,
                is_free: false,
                sc: ''
              }
            ]
          },
          '16': {
            rchar: '',
            rseats: [
              {
                id: 1,
                sn: '16A',
                ns: '',
                is_available: true,
                price: 600,
                is_seat: 1,
                sc: ''
              },
              {
                id: 2,
                sn: '16B',
                ns: '',
                is_available: true,
                price: 450,
                is_seat: 1,
                sc: ''
              },
              {
                id: 3,
                sn: '16C',
                ns: '',
                is_available: true,
                price: 600,
                is_seat: 1,
                sc: ''
              },
              {
                id: 4,
                sn: '1BL',
                ns: '',
                is_available: false,
                price: 0,
                is_seat: 0,
                sc: ''
              },
              {
                id: 5,
                sn: '16D',
                ns: '',
                is_available: true,
                price: 450,
                is_seat: 1,
                sc: ''
              },
              {
                id: 6,
                sn: '16E',
                ns: '',
                is_available: true,
                price: 450,
                is_seat: 1,
                sc: ''
              },
              {
                id: 7,
                sn: '16F',
                ns: '',
                is_available: true,
                price: 600,
                is_seat: 1,
                sc: ''
              }
            ]
          },
          '17': {
            rchar: '',
            rseats: [
              {
                id: 1,
                sn: '17A',
                ns: '',
                is_available: false,
                price: 250,
                is_seat: 1,
                sc: ''
              },
              {
                id: 2,
                sn: '17B',
                ns: '',
                is_available: false,
                price: 150,
                is_seat: 1,
                sc: ''
              },
              {
                id: 3,
                sn: '17C',
                ns: '',
                is_available: true,
                price: 250,
                is_seat: 1,
                sc: ''
              },
              {
                id: 4,
                sn: '1BL',
                ns: '',
                is_available: false,
                price: 0,
                is_seat: 0,
                sc: ''
              },
              {
                id: 5,
                sn: '17D',
                ns: '',
                is_available: true,
                price: 250,
                is_seat: 1,
                sc: ''
              },
              {
                id: 6,
                sn: '17E',
                ns: '',
                is_available: true,
                price: 150,
                is_seat: 1,
                sc: ''
              },
              {
                id: 7,
                sn: '17F',
                ns: '',
                is_available: false,
                price: 250,
                is_seat: 1,
                sc: ''
              }
            ]
          },
          '18': {
            rchar: '',
            rseats: [
              {
                id: 1,
                sn: '18A',
                ns: '',
                is_available: false,
                price: 250,
                is_seat: 1,
                sc: ''
              },
              {
                id: 2,
                sn: '18B',
                ns: '',
                is_available: false,
                price: 150,
                is_seat: 1,
                sc: ''
              },
              {
                id: 3,
                sn: '18C',
                ns: '',
                is_available: false,
                price: 250,
                is_seat: 1,
                sc: ''
              },
              {
                id: 4,
                sn: '1BL',
                ns: '',
                is_available: false,
                price: 0,
                is_seat: 0,
                sc: ''
              },
              {
                id: 5,
                sn: '18D',
                ns: '',
                is_available: true,
                price: 250,
                is_seat: 1,
                sc: ''
              },
              {
                id: 6,
                sn: '18E',
                ns: '',
                is_available: true,
                price: 150,
                is_seat: 1,
                sc: ''
              },
              {
                id: 7,
                sn: '18F',
                ns: '',
                is_available: false,
                price: 250,
                is_seat: 1,
                sc: ''
              }
            ]
          },
          '19': {
            rchar: '',
            rseats: [
              {
                id: 1,
                sn: '19A',
                ns: '',
                is_available: false,
                price: 250,
                is_seat: 1,
                sc: ''
              },
              {
                id: 2,
                sn: '19B',
                ns: '',
                is_available: true,
                price: 150,
                is_seat: 1,
                sc: ''
              },
              {
                id: 3,
                sn: '19C',
                ns: '',
                is_available: true,
                price: 250,
                is_seat: 1,
                sc: ''
              },
              {
                id: 4,
                sn: '1BL',
                ns: '',
                is_available: false,
                price: 0,
                is_seat: 0,
                sc: ''
              },
              {
                id: 5,
                sn: '19D',
                ns: '',
                is_available: true,
                price: 250,
                is_seat: 1,
                sc: ''
              },
              {
                id: 6,
                sn: '19E',
                ns: '',
                is_available: true,
                price: 150,
                is_seat: 1,
                sc: ''
              },
              {
                id: 7,
                sn: '19F',
                ns: '',
                is_available: false,
                price: 250,
                is_seat: 1,
                sc: ''
              }
            ]
          },
          '20': {
            rchar: '',
            rseats: [
              {
                id: 1,
                sn: '20A',
                ns: '',
                is_available: false,
                price: 250,
                is_seat: 1,
                sc: ''
              },
              {
                id: 2,
                sn: '20B',
                ns: '',
                is_available: true,
                price: 150,
                is_seat: 1,
                sc: ''
              },
              {
                id: 3,
                sn: '20C',
                ns: '',
                is_available: true,
                price: 250,
                is_seat: 1,
                sc: ''
              },
              {
                id: 4,
                sn: '1BL',
                ns: '',
                is_available: false,
                price: 0,
                is_seat: 0,
                sc: ''
              },
              {
                id: 5,
                sn: '20D',
                ns: '',
                is_available: true,
                price: 250,
                is_seat: 1,
                sc: ''
              },
              {
                id: 6,
                sn: '20E',
                ns: '',
                is_available: true,
                price: 150,
                is_seat: 1,
                sc: ''
              },
              {
                id: 7,
                sn: '20F',
                ns: '',
                is_available: false,
                price: 250,
                is_seat: 1,
                sc: ''
              }
            ]
          },
          '21': {
            rchar: '',
            rseats: [
              {
                id: 1,
                sn: '21A',
                ns: '',
                is_available: false,
                price: 250,
                is_seat: 1,
                sc: ''
              },
              {
                id: 2,
                sn: '21B',
                ns: '',
                is_available: false,
                price: 150,
                is_seat: 1,
                sc: ''
              },
              {
                id: 3,
                sn: '21C',
                ns: '',
                is_available: true,
                price: 250,
                is_seat: 1,
                sc: ''
              },
              {
                id: 4,
                sn: '1BL',
                ns: '',
                is_available: false,
                price: 0,
                is_seat: 0,
                sc: ''
              },
              {
                id: 5,
                sn: '21D',
                ns: '',
                is_available: true,
                price: 250,
                is_seat: 1,
                sc: ''
              },
              {
                id: 6,
                sn: '21E',
                ns: '',
                is_available: true,
                price: 150,
                is_seat: 1,
                sc: ''
              },
              {
                id: 7,
                sn: '21F',
                ns: '',
                is_available: true,
                price: 250,
                is_seat: 1,
                sc: ''
              }
            ]
          },
          '22': {
            rchar: '',
            rseats: [
              {
                id: 1,
                sn: '22A',
                ns: '',
                is_available: true,
                price: 250,
                is_seat: 1,
                sc: ''
              },
              {
                id: 2,
                sn: '22B',
                ns: '',
                is_available: true,
                price: 150,
                is_seat: 1,
                sc: ''
              },
              {
                id: 3,
                sn: '22C',
                ns: '',
                is_available: true,
                price: 250,
                is_seat: 1,
                sc: ''
              },
              {
                id: 4,
                sn: '1BL',
                ns: '',
                is_available: false,
                price: 0,
                is_seat: 0,
                sc: ''
              },
              {
                id: 5,
                sn: '22D',
                ns: '',
                is_available: true,
                price: 250,
                is_seat: 1,
                sc: ''
              },
              {
                id: 6,
                sn: '22E',
                ns: '',
                is_available: true,
                price: 150,
                is_seat: 1,
                sc: ''
              },
              {
                id: 7,
                sn: '22F',
                ns: '',
                is_available: false,
                price: 250,
                is_seat: 1,
                sc: ''
              }
            ]
          },
          '23': {
            rchar: '',
            rseats: [
              {
                id: 1,
                sn: '23A',
                ns: '',
                is_available: true,
                price: 250,
                is_seat: 1,
                sc: ''
              },
              {
                id: 2,
                sn: '23B',
                ns: '',
                is_available: true,
                price: 150,
                is_seat: 1,
                sc: ''
              },
              {
                id: 3,
                sn: '23C',
                ns: '',
                is_available: true,
                price: 250,
                is_seat: 0,
                sc: ''
              },
              {
                id: 4,
                sn: '1BL',
                ns: '',
                is_available: false,
                price: 0,
                is_seat: 0,
                sc: ''
              },
              {
                id: 5,
                sn: '23D',
                ns: '',
                is_available: true,
                price: 250,
                is_seat: 1,
                sc: ''
              },
              {
                id: 6,
                sn: '23E',
                ns: '',
                is_available: true,
                price: 150,
                is_seat: 1,
                sc: ''
              },
              {
                id: 7,
                sn: '23F',
                ns: '',
                is_available: true,
                price: 250,
                is_seat: 1,
                sc: ''
              }
            ]
          },
          '24': {
            rchar: '',
            rseats: [
              {
                id: 1,
                sn: '24A',
                ns: '',
                is_available: false,
                price: 150,
                is_seat: 1,
                sc: ''
              },
              {
                id: 2,
                sn: '24B',
                ns: '',
                is_available: true,
                price: 150,
                is_seat: 1,
                sc: ''
              },
              {
                id: 3,
                sn: '24C',
                ns: '',
                is_available: true,
                price: 150,
                is_seat: 1,
                sc: ''
              },
              {
                id: 4,
                sn: '1BL',
                ns: '',
                is_available: false,
                price: 0,
                is_seat: 0,
                sc: ''
              },
              {
                id: 5,
                sn: '24D',
                ns: '',
                is_available: false,
                price: 150,
                is_seat: 1,
                sc: ''
              },
              {
                id: 6,
                sn: '24E',
                ns: '',
                is_available: true,
                price: 150,
                is_seat: 1,
                sc: ''
              },
              {
                id: 7,
                sn: '24F',
                ns: '',
                is_available: false,
                price: 150,
                is_seat: 1,
                sc: ''
              }
            ]
          },
          '25': {
            rchar: '',
            rseats: [
              {
                id: 1,
                sn: '25A',
                ns: '',
                is_available: false,
                price: 150,
                is_seat: 1,
                sc: ''
              },
              {
                id: 2,
                sn: '25B',
                ns: '',
                is_available: true,
                price: 150,
                is_seat: 1,
                sc: ''
              },
              {
                id: 3,
                sn: '25C',
                ns: '',
                is_available: false,
                price: 150,
                is_seat: 1,
                sc: ''
              },
              {
                id: 4,
                sn: '1BL',
                ns: '',
                is_available: false,
                price: 0,
                is_seat: 0,
                sc: ''
              },
              {
                id: 5,
                sn: '25D',
                ns: '',
                is_available: true,
                price: 150,
                is_seat: 1,
                sc: ''
              },
              {
                id: 6,
                sn: '25E',
                ns: '',
                is_available: true,
                price: 150,
                is_seat: 1,
                sc: ''
              },
              {
                id: 7,
                sn: '25F',
                ns: '',
                is_available: false,
                price: 150,
                is_seat: 1,
                sc: ''
              }
            ]
          },
          '26': {
            rchar: '',
            rseats: [
              {
                id: 1,
                sn: '26A',
                ns: '',
                is_available: false,
                price: 150,
                is_seat: 0,
                sc: ''
              },
              {
                id: 2,
                sn: '26B',
                ns: '',
                is_available: false,
                price: 0,
                is_seat: 1,
                sc: ''
              },
              {
                id: 3,
                sn: '26C',
                ns: '',
                is_available: false,
                price: 150,
                is_seat: 1,
                sc: ''
              },
              {
                id: 4,
                sn: '1BL',
                ns: '',
                is_available: false,
                price: 0,
                is_seat: 0,
                sc: ''
              },
              {
                id: 5,
                sn: '26D',
                ns: '',
                is_available: true,
                price: 150,
                is_seat: 1,
                sc: ''
              },
              {
                id: 6,
                sn: '26E',
                ns: '',
                is_available: false,
                price: 0,
                is_seat: 1,
                sc: ''
              },
              {
                id: 7,
                sn: '26F',
                ns: '',
                is_available: false,
                price: 150,
                is_seat: 1,
                sc: ''
              }
            ]
          },
          '27': {
            rchar: '',
            rseats: [
              {
                id: 1,
                sn: '27A',
                ns: '',
                is_available: false,
                price: 150,
                is_seat: 0,
                sc: ''
              },
              {
                id: 2,
                sn: '27B',
                ns: '',
                is_available: false,
                price: 0,
                is_seat: 0,
                sc: ''
              },
              {
                id: 3,
                sn: '27C',
                ns: '',
                is_available: true,
                price: 150,
                is_seat: 0,
                sc: ''
              },
              {
                id: 4,
                sn: '1BL',
                ns: '',
                is_available: false,
                price: 0,
                is_seat: 0,
                sc: ''
              },
              {
                id: 5,
                sn: '27D',
                ns: '',
                is_available: false,
                price: 150,
                is_seat: 1,
                sc: ''
              },
              {
                id: 6,
                sn: '27E',
                ns: '',
                is_available: false,
                price: 0,
                is_seat: 0,
                sc: ''
              },
              {
                id: 7,
                sn: '27F',
                ns: '',
                is_available: false,
                price: 150,
                is_seat: 0,
                sc: ''
              }
            ]
          },
          '28': {
            rchar: '',
            rseats: [
              {
                id: 1,
                sn: '28A',
                ns: '',
                is_available: false,
                price: 150,
                is_seat: 1,
                sc: ''
              },
              {
                id: 2,
                sn: '28B',
                ns: '',
                is_available: false,
                price: 0,
                is_seat: 1,
                sc: ''
              },
              {
                id: 3,
                sn: '28C',
                ns: '',
                is_available: true,
                price: 150,
                is_seat: 1,
                sc: ''
              },
              {
                id: 4,
                sn: '1BL',
                ns: '',
                is_available: false,
                price: 0,
                is_seat: 0,
                sc: ''
              },
              {
                id: 5,
                sn: '28D',
                ns: '',
                is_available: true,
                price: 150,
                is_seat: 1,
                sc: ''
              },
              {
                id: 6,
                sn: '28E',
                ns: '',
                is_available: false,
                price: 0,
                is_seat: 0,
                sc: ''
              },
              {
                id: 7,
                sn: '28F',
                ns: '',
                is_available: true,
                price: 150,
                is_seat: 0,
                sc: ''
              }
            ]
          },
          '29': {
            rchar: '',
            rseats: [
              {
                id: 1,
                sn: '29A',
                ns: '',
                is_available: true,
                price: 150,
                is_seat: 1,
                sc: ''
              },
              {
                id: 2,
                sn: '29B',
                ns: '',
                is_available: false,
                price: 0,
                is_seat: 1,
                sc: ''
              },
              {
                id: 3,
                sn: '29C',
                ns: '',
                is_available: true,
                price: 150,
                is_seat: 1,
                sc: ''
              },
              {
                id: 4,
                sn: '1BL',
                ns: '',
                is_available: false,
                price: 0,
                is_seat: 0,
                sc: ''
              },
              {
                id: 5,
                sn: '29D',
                ns: '',
                is_available: true,
                price: 150,
                is_seat: 1,
                sc: ''
              },
              {
                id: 6,
                sn: '29E',
                ns: '',
                is_available: false,
                price: 0,
                is_seat: 1,
                sc: ''
              },
              {
                id: 7,
                sn: '29F',
                ns: '',
                is_available: false,
                price: 150,
                is_seat: 1,
                sc: ''
              }
            ]
          },
          '30': {
            rchar: '',
            rseats: [
              {
                id: 1,
                sn: '30A',
                ns: '',
                is_available: true,
                price: 150,
                is_seat: 1,
                sc: ''
              },
              {
                id: 2,
                sn: '30B',
                ns: '',
                is_available: true,
                price: 450,
                is_seat: 1,
                sc: ''
              },
              {
                id: 3,
                sn: '30C',
                ns: '',
                is_available: true,
                price: 150,
                is_seat: 1,
                sc: ''
              },
              {
                id: 4,
                sn: '1BL',
                ns: '',
                is_available: false,
                price: 0,
                is_seat: 0,
                sc: ''
              },
              {
                id: 5,
                sn: '30D',
                ns: '',
                is_available: true,
                price: 150,
                is_seat: 1,
                sc: ''
              },
              {
                id: 6,
                sn: '30E',
                ns: '',
                is_available: false,
                price: 0,
                is_seat: 1,
                sc: ''
              },
              {
                id: 7,
                sn: '30F',
                ns: '',
                is_available: true,
                price: 150,
                is_seat: 1,
                sc: ''
              }
            ]
          }
        }
      },
      Upperdeck: []
    }
  ]

  const [seatSelect, setSeatSelectItem] = useState([
    {
      id: 1,
      seatId: '',
      seatIndex: '',
      name: 'Shubham'
    },
    {
      id: 2,
      seatId: '',
      seatIndex: '',
      name: 'Rupesh'
    },
    {
      id: 3,
      seatId: '',
      seatIndex: '',
      name: 'Prashant'
    }
  ])

  

  useEffect(() => {
    const firstSeatRowUl = document.querySelector('.seat-row')
    if (firstSeatRowUl) {
      firstSeatRowUl.querySelectorAll('h3').forEach(h3 => {
        h3.remove()
      })

      const liElements = firstSeatRowUl.querySelectorAll('li')
      let titleIndex = 70 // ASCII code for 'F'

      liElements.forEach(li => {
        if (li.textContent !== '1BL') {
          const rowTitle = String.fromCharCode(titleIndex)
          const h1Element = document.createElement('h3')
          h1Element.classList.add('rowTitle')
          h1Element.textContent = rowTitle
          li.appendChild(h1Element)
          titleIndex--
        }
      })
    }
  }, [])

  interface SeatItem {
    id: number
    price: number
  }

  const [anchorEl, setAnchorEl] = useState(null)
  const [selectedSeatId, setSelectedSeatId] = useState<string>('')
  const [selectedSeatPrice, setSelectedSeatPrice] = useState(null)
  const [selectedSeatIndexId, setselectedSeatIndexId] = useState<string>('')
  const [selectedSeatIds, setSelectedSeatIds] = useState<string[]>([]);

  

  
  const handlePopoverClick = (event, seatId, seatPrice, seatIndexId, seatArray) => {
    console.log(seatIndexId, 'seatIndexId')
    setAnchorEl(event.currentTarget)
    setSelectedSeatId(seatId)
    setSelectedSeatPrice(seatPrice)
    setselectedSeatIndexId(seatIndexId)
    // Update seatArraySet directly
    
  }

 
  const handleClosePopover = () => {
    setAnchorEl(null)
    setSelectedSeatId('')
    setselectedSeatIndexId('')
  }

  const handleCheckboxChange = (seatIndex, updateId) => event => {
    const updatedSeats = [...seatSelect]
    updatedSeats[seatIndex].seatId = event.target.checked ? selectedSeatId : ''
    updatedSeats[seatIndex].seatIndex = event.target.checked ? selectedSeatIndexId : ''

  let updatedSelectedSeatIds;

  if (event.target.checked) {
    updatedSelectedSeatIds = [...selectedSeatIds, selectedSeatId]; // Add the selected seat ID
  } else {
    updatedSelectedSeatIds = selectedSeatIds.filter(id => id !== updateId); // Remove the deselected seat ID
  }

  setSelectedSeatIds(updatedSelectedSeatIds);



    setSelectedSeatIds(updatedSelectedSeatIds);

    const seatButtons = document.querySelectorAll('.seat-grid .MuiButtonBase-root')
    seatButtons.forEach(button => {
      const buttonTextContent = button.textContent?.trim() || ''

      if (buttonTextContent === selectedSeatId) {
        if (event.target.checked) {
          button.classList.add('active')
          onSeatUpdate(updatedSelectedSeatIds);
        }
      }
      if (!event.target.checked && buttonTextContent === updateId) {
        button.classList.remove('active')
       
      }
    })
    
    setSeatSelectItem(updatedSeats)

    console.log(updateId, 'updateId');
    console.log(updatedSelectedSeatIds, 'updatedSelectedSeatIds');
  
    onSeatUpdate(updatedSelectedSeatIds);
   

    
  }

  

  return (
    <>
      {seatLayout.map((layout, index) => {
        const rowInfo = layout.Maindeck.rowInfo
        const wingBoxStart = layout.Maindeck.equipmentInfo.wingsStart
        const wingBoxEnd = layout.Maindeck.equipmentInfo.wingsEnd
        return (
          <React.Fragment key={index}>
            <Box className='seat-grid'>
              {Object.keys(rowInfo).map((rowKey, rowIndex) => {
                // console.log(rowIndex, 'rowInfo')
                const row = rowInfo[rowKey]
                const seats = row.rseats.reverse()
                const rowKeyNumeric = parseInt(rowKey)
                const isWingRow = rowKeyNumeric >= wingBoxStart && rowKeyNumeric <= wingBoxEnd

                return (
                  <Box key={rowKey} className={isWingRow ? 'wingBoxStart' : ''}>
                    <List className='seat-row'>
                      {seats.map((seat, seatIndex) => (
                        <ListItem key={seatIndex}>
                          {seat.is_seat === 0 ? (
                            <Button style={{ visibility: 'hidden' }}>
                              <Box>{seat.sn}</Box>
                            </Button>
                          ) : (
                            <>
                              {seat.is_free === true ? (
                                
                                <Button
                                  className='free-seat'
                                  onClick={event =>
                                    handlePopoverClick(event, seat.sn, seat.price, rowIndex + 1 + '|' + seat.id, seats)
                                  }
                                >
                                  <Image src='/images/icons/freeSeat.png' width={100} height={100} alt='' />  
                                  <Box sx={{ visibility: 'hidden' }}>{seat.sn}</Box>
                                </Button>
                              ) : (
                                <>
                                  {seat.price >= 150 && seat.price <= 350 ? (
                                    <Button
                                      className='priceRange150to350'
                                      onClick={event =>
                                        handlePopoverClick(
                                          event,
                                          seat.sn,
                                          seat.price,
                                          rowIndex + 1 + '|' + seat.id,
                                          seats
                                        )
                                      }
                                    >
                                      <Image src='/images/icons/rs150-350.png' width={100} height={100} alt='' />
                                      <Box sx={{ visibility: 'hidden' }}>{seat.sn}</Box>
                                    </Button>
                                  ) : (
                                    <>
                                      {seat.price >= 400 && seat.price <= 800 ? (
                                        <Button
                                          className='priceRange400to800'
                                          onClick={event =>
                                            handlePopoverClick(
                                              event,
                                              seat.sn,
                                              seat.price,
                                              rowIndex + 1 + '|' + seat.id,
                                              seats
                                            )
                                          }
                                        >
                                          <Image src='/images/icons/rs400-800.png' width={100} height={100} alt='' />
                                          <Box sx={{ visibility: 'hidden' }}>{seat.sn}</Box>
                                        </Button>
                                      ) : (
                                        <>
                                          {seat.is_available === false ? (
                                            <Button className='occupied-seat'>
                                              <Image src='/images/icons/occupied.png' width={100} height={100} alt='' />
                                              <Box sx={{ visibility: 'hidden' }}>{seat.sn}</Box>
                                            </Button>
                                          ) : (
                                            <Button
                                              onClick={event =>
                                                handlePopoverClick(
                                                  event,
                                                  seat.sn,
                                                  seat.price,
                                                  rowIndex + 1 + '|' + seat.id,
                                                  seats
                                                )
                                              }
                                            >
                                              <Box sx={{ visibility: 'hidden' }}>{seat.sn}</Box>
                                            </Button>
                                          )}
                                        </>
                                      )}
                                    </>
                                  )}
                                </>
                              )}
                            </>
                          )}
                        </ListItem>
                      ))}
                    </List>
                  </Box>
                )
              })}
            </Box>
          </React.Fragment>
        )
      })}

      <Box className='legendBox'>
        <List>
          <ListItem>
            <ListItemText>Legend:</ListItemText>
          </ListItem>

          <ListItem>
            <ListItemIcon>
              <Circle sx={{ color: '#24BA21' }} />
            </ListItemIcon>
            <ListItemText>Free Seats</ListItemText>
          </ListItem>

          <ListItem>
            <ListItemIcon>
              <Circle sx={{ color: '#70D8EF' }} />
            </ListItemIcon>
            <ListItemText>Rupees 150 - 350</ListItemText>
          </ListItem>

          <ListItem>
            <ListItemIcon>
              <Circle sx={{ color: '#3E93E1' }} />
            </ListItemIcon>
            <ListItemText>Rupees 400 - 800</ListItemText>
          </ListItem>

          <ListItem>
            <ListItemIcon>
              <Circle sx={{ color: '#999999' }} />
            </ListItemIcon>
            <ListItemText>Occupied</ListItemText>
          </ListItem>
        </List>
      </Box>

      <Popover
        open={Boolean(anchorEl)}
        anchorEl={anchorEl}
        onClose={handleClosePopover}
        anchorOrigin={{
          vertical: 'bottom',
          horizontal: 'center'
        }}
        transformOrigin={{
          vertical: 'top',
          horizontal: 'center'
        }}
      >
        <Box sx={{ padding: '1rem' }}>
          {/* <Typography>Seat Information: {selectedSeatId} {selectedSeatPrice}</Typography> */}
          <Box sx={{ padding: '1rem', minWidth: '14rem' }}>
            <Button
              variant='contained'
              sx={{
                minWidth: 'auto',
                width: '100%',
                justifyContent: 'space-between',
                background: theme.palette.common.black,
                '&.MuiButton-root:hover': {
                  background: theme.palette.common.black
                }
              }}
            >
              <Typography
                variant='subtitle1'
                gutterBottom
                sx={{ color: theme.palette.common.white, marginBottom: '0rem' }}
              >
                {selectedSeatId}
              </Typography>
              <Typography
                variant='subtitle1'
                gutterBottom
                sx={{ color: theme.palette.common.white, marginBottom: '0rem' }}
              >
                {selectedSeatPrice}
              </Typography>
            </Button>
            {seatSelect.map((item, index) => {
              const mapSeatIndex = item.seatIndex
              const updateArray = mapSeatIndex.split('|')
              let customrow = updateArray[0]
              let customcol = updateArray[1]
              let seatData: any = null
              if (seatLayout.length > 0) {
                const maindeck = seatLayout[0].Maindeck
                if (maindeck) {
                  const rowInfo = maindeck.rowInfo
                  if (rowInfo && rowInfo[customrow]) {
                    const rseats = rowInfo[customrow].rseats
                    if (rseats) {
                      seatData = rseats.find(seat => seat.id === parseInt(customcol))
                      // console.log(seatData.sn, 'seatData')
                      // onSeatUpdate(seatData.sn)
                    }
                  }
                }
              }
              // const isCurrentSeatSelected = item.seatId !== '';
              return (
                <>
                  <Stack key={index} direction='row' spacing={1} sx={{ alignItems: 'center' }}>
                    <Item>
                      <FormControlLabel
                        sx={{
                          minWidth: '8rem',
                          '& .Mui-checked': {
                            color: `${theme.palette.secondary.light} !important`
                          }
                        }}
                        control={
                          <Checkbox
                            checked={item.seatId !== ''}
                            disabled={seatSelect.some(otherItem => otherItem.seatId === selectedSeatId) && !item.seatId}
                            onChange={handleCheckboxChange(index, item.seatId)}
                            value={item.id}
                            name={item.name} // Use the item name as the checkbox name
                          />
                        }
                        label={
                          <Typography
                            variant='body2'
                            gutterBottom
                            sx={{
                              color: theme.palette.common.black
                            }}
                          > 
                            {item.name}
                          </Typography>
                        }
                      />
                    </Item>
                    <Item sx={{ display: 'flex' }}>
                      <Typography
                        variant='body2'
                        gutterBottom
                        sx={{
                          color: theme.palette.common.black,
                          marginRight: '10px'
                        }}
                      >
                        {item.seatId}
                      </Typography>
                      <Typography
                        variant='body2'
                        gutterBottom
                        sx={{
                          color: theme.palette.common.black
                        }}
                      >
                        {seatData ? seatData.price : ''}
                        {/* {isCurrentSeatSelected ? seatData ? seatData.price : '' : ''} */}
                      </Typography>
                    </Item>
                  </Stack>
                </>
              )
            })}
          </Box>
        </Box>
      </Popover>
    </>
  )
}

export default SeatSelection
