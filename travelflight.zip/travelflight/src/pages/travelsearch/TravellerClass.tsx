import * as React from 'react'
import Popover from '@mui/material/Popover'
import Button from '@mui/material/Button'
import Travelers from './Travelers'
import AirportClass from './AirportClass'
import Card from '@mui/material/Card'
import CardHeader from '@mui/material/CardHeader'
import CardContent from '@mui/material/CardContent'
import FormGroup from '@mui/material/FormGroup'
import FormControlLabel from '@mui/material/FormControlLabel'
import Checkbox from '@mui/material/Checkbox'
import Box from '@mui/material/Box'
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import Typography from '@mui/material/Typography'
import { Grid } from '@mui/material'
import AddIcon from '@mui/icons-material/Add';

const TravellerClass = () => {
  const [anchorEl, setAnchorEl] = React.useState<HTMLButtonElement | null>(null) 
  const [alignment, setAlignment] = React.useState('')

  // const [savedAlignment, setSavedAlignment] = React.useState('')

  const [counts, setCounts] = React.useState({ adult: 0, child: 0, infant: 0 })

  // const [savedCounts, setSavedCounts] = React.useState({ adult: 0, child: 0, infant: 0 })

  const [totalpassenger, setTotalPassenger] = React.useState(0)
  const [includeMe, setIncludeMe] = React.useState(false)


  const storedAdultsCount = Number(localStorage.getItem('adultsCount')) || 0;
  const storedChildrenCount = Number(localStorage.getItem('childrenCount')) || 0;
  const storedInfantsCount = Number(localStorage.getItem('infantsCount')) || 0;
  const [savedCounts, setSavedCounts] = React.useState({
    adult: storedAdultsCount,
    child: storedChildrenCount,
    infant: storedInfantsCount,
  });

  // const storedSavedAlignment = localStorage.getItem('alignment') || '';
  // const [savedAlignment, setSavedAlignment] = React.useState(storedSavedAlignment);

const storedSavedAlignment = localStorage.getItem('alignment') || '';

// Parse the storedSavedAlignment back to its original type (string or array)

const parsedAlignment = storedSavedAlignment ? JSON.parse(storedSavedAlignment) : '';
const [savedAlignment, setSavedAlignment] = React.useState(parsedAlignment);




  const handleClick = (event: React.MouseEvent<HTMLButtonElement>) => {
    setAnchorEl(event.currentTarget)
  }

  const handleClose = () => {
    setAnchorEl(null) 
  }

  const handleCancel = () => {

    // setCounts(savedCounts); // Reset counts to saved values

    setAlignment(savedAlignment); // Reset alignment to saved value

    // calculateTotalPassenger(); // Recalculate total passenger count

    handleClose(); // Close the popover
  }

  // const handleAlignmentChange = (newAlignment: string) => {
  //   setAlignment(newAlignment)
  // }

  const handleAlignmentChange = (newAlignment: string | string[]) => {

    // If newAlignment is an array, extract the first element as the savedAlignment value 
 
    const alignmentValue = Array.isArray(newAlignment) ? newAlignment[0] : newAlignment;
    setAlignment(alignmentValue);
  };

  const handleIncludeMeChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setIncludeMe(event.target.checked)
  }

  const handleCountsUpdated = (newCounts: { adult: number; child: number; infant: number }) => {
    setCounts(newCounts)
  }

  const handleSave = () => {

  //   const alignmentString = JSON.stringify(alignment);
  //  localStorage.setItem('alignment', alignmentString);

    setSavedCounts(counts)
    setSavedAlignment(alignment)
    calculateTotalPassenger()
    handleClose() 
  }

  const calculateTotalPassenger = () => {
    const total = savedCounts.adult + savedCounts.child + savedCounts.infant
    if (includeMe) {
      setTotalPassenger(total + 1)
    } else {
      setTotalPassenger(total)
    }
  }

  React.useEffect(() => {
    calculateTotalPassenger()
  }, [savedCounts, setIncludeMe])

  const open = Boolean(anchorEl)
  const id = open ? 'simple-popover' : undefined

  return (
    <>
     <Grid item  xs={12} sx={{ display:'flex', justifyContent: { xs: 'flex-start',sm:'center', md: 'flex-start' }, alignItems: 'center' }}>
      <Button aria-describedby={id} variant='text' onClick={handleClick} sx={{ marginTop: '1rem',textTransform:'Capitalize',paddingLeft:0, color:'inherit',
        '&:hover':{
          background:'none'
        }
      }}>
        Travelers & Class <ExpandMoreIcon/>
      </Button>
      </Grid>
      
      <Grid item xs={12}  sx={{ display:'flex', justifyContent: { xs: 'flex-start',sm:'center', md: 'flex-start' }, alignItems: 'center' }}>
      <CardContent  sx={{border:'1px solid transparent',padding:'0rem !important',borderRadius:'6px',marginTop:{xs:'0rem', md:'0.5rem'},borderColor:'transparent'}}>
        <Button  onClick={handleClick}  sx={{ mb: 7, padding:'0rem', display: 'block', textTransform:'capitalize', alignItems: 'center',marginBottom:0, justifyContent:'center' , width:'100%' }}>
          <Box sx={{display:'flex',alignItems:'center'}}>
          <Typography  sx={{ 
          fontSize:'1.5rem', 
          color:theme => theme.palette.secondary.light}}>
            {totalpassenger}
          </Typography>


          <Typography variant='h6'  sx={{ 
          color:theme => theme.palette.secondary.light, fontSize:'1rem !important',
              marginLeft:'5px'
           }}
          >Travelers</Typography>
           </Box>  
          {/* <Box>
          {Array.isArray(savedAlignment) ? (
         <Typography
          component="ul"
           sx={{ fontSize: '0.75rem', position: 'relative', top: '3px', textAlign: 'left', paddingLeft: '1rem' }}
           >
          {savedAlignment.map((item, index) => (
          <li key={index}>{item}</li>
          ))}
          </Typography>
          ) : (
         <Typography sx={{ fontSize: '0.75rem', position: 'relative', top: '3px', textAlign: 'left' }}>{savedAlignment}</Typography>
          )}
        </Box> */}
        <Box>
  <Typography
    component="ul"
    className="travelerClass"
    sx={{ fontSize: '0.75rem', position: 'relative', top: '3px', textAlign: 'left',}}
  >
    {Array.isArray(savedAlignment)
      ? savedAlignment.map((item, index) => <li key={index} >{item} <AddIcon/></li>)
      : (
        savedAlignment && savedAlignment.split(' ').map((item, index) => <li key={index}>{item} <AddIcon/></li>)
      )}
  </Typography>
  </Box>
        
         
        </Button>
      
      </CardContent>

      {/* <CardContent>
        {savedAlignment}
        <p>Total Adults: {savedCounts.adult}</p>
        <p>Total Children: {savedCounts.child}</p>
        <p>Total Infants: {savedCounts.infant}</p>
        <p>Total {totalpassenger}</p>
      </CardContent> */}
      <Popover
        id={id}
        open={open}
        anchorEl={anchorEl}
        onClose={handleClose}
        anchorOrigin={{
          vertical: 'bottom',
          horizontal: 'center'
        }}
        transformOrigin={{
          vertical: 'top',
          horizontal: 'center'
        }}
       
      >
        <Card sx={{ p: 2, maxWidth: { xs: '100%', sm: '34rem' }}}  className='travellerBox'>
          <CardHeader
            title='Travelers'
            sx={{paddingBottom:2,textTransform:'uppercase'}}
            subheader={
              <Box component='span' sx={{ fontWeight: 600, color: 'text.primary' }}>
                <FormGroup>
                  <FormControlLabel
                    control={<Checkbox checked={includeMe} onChange={handleIncludeMeChange}  />}
                    label='Include me'
                    sx={{'& .Mui-checked':{
                           color:'#F0971A !important'
                    },
                    textTransform:'capitalize'
                  }}
                  />
                </FormGroup>
              </Box>
            }
          />
          <Travelers onCountsUpdated={handleCountsUpdated} /> 
          <AirportClass onAlignmentChange={handleAlignmentChange} />
          <CardContent 
            sx={{ pt: theme => `${theme.spacing(0)} !important`, display: 'flex', justifyContent: 'flex-end' }}
          >
            <Button variant='text' onClick={handleCancel}>
              Cancel
            </Button>
            <Button variant='contained' onClick={handleSave}>
              Save
            </Button>
          </CardContent>
        </Card>
      </Popover>
      </Grid>
    </>
  )
}

export default TravellerClass
