import * as React from 'react'


import Card from '@mui/material/Card'

import FlightIcon from '@mui/icons-material/Flight'
import HotelIcon from '@mui/icons-material/Hotel'
import Select from '@mui/material/Select'
import MenuItem from '@mui/material/MenuItem'
import { SelectChangeEvent } from '@mui/material/Select'
import FormControl from '@mui/material/FormControl'
import InputLabel from '@mui/material/InputLabel'

import { Tabs, Tab, Box, Stack, Grid, TextField } from '@mui/material'
import { useTheme, useMediaQuery } from '@mui/material'
import moment, { Moment } from 'moment'
import 'react-dates/initialize'
import 'react-dates/lib/css/_datepicker.css'
import { DateRangePicker, FocusedInputShape } from 'react-dates'

import { Paper } from '@mui/material'

import { useQuery } from '@apollo/client'
import { gql } from '@apollo/client'

// import { Autocomplete, AutocompleteRenderOptionState } from '@mui/material'

import { Autocomplete } from '@mui/material'


// import { HTMLAttributes } from '@mui/types';


import ListItem from '@mui/material/ListItem'

import ListItemText from '@mui/material/ListItemText'

interface CardNavigationState {
  startDate: Moment | null
  endDate: Moment | null
  focusedInput: FocusedInputShape | null
}

interface TabPanelProps {
  children?: React.ReactNode
  index: number
  value: number
}

interface DateRangePicker {
  small: boolean
  required: boolean
  showClearDates: boolean
  reopenPickerOnClearDates: boolean
}

// function generate(element: React.ReactElement) {
//   return [0, 1, 2].map((value) =>
//     React.cloneElement(element, {
//       key: value,
//     }),
//   );
// }

const TabPanel = (props: TabPanelProps) => {
  const { children, value, index, ...other } = props

  return (
    <div
      role='tabpanel'
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && <Box sx={{ p: 3 }}>{children}</Box>}
    </div>
  )
}

const a11yProps = (index: number) => {
  return {
    id: `simple-tab-${index}`,
    'aria-controls': `simple-tabpanel-${index}`
  }
}

const AIRPORT_QUERY = gql`
  query Top100Films {
    top100Films {
      cityName
      airportName
      country
      countryCode
    }
  }
`
interface Top100Film {
  cityName: string
  airportName: string
  country: string
  countryCode: string
}

interface AirtportsData {
  top100Films: Top100Film[]
}

// const renderOption = (option: Top100Film) => (
//   <div className="makeFlex hrtlCenter">
//     <img className="icLocAlt appendRight8" src="https://imgak.mmtcdn.com/flights/assets/media/dt/common/icons/ic-flight-onward.png" alt="icon" />
//     <div className="calc60">
//       <p className="font14 appendBottom5 blackText">{option.label}, {option.label}</p>
//       <p className="font12 greyText appendBottom3">{option.label}</p>
//     </div>
//     <div className="pushRight font14 lightGreyText latoBold">{option.year}</div>
//   </div>
// );

const CardNavigation = () => {
  const [value, setValue] = React.useState(0)
  const [nestedValue, setNestedValue] = React.useState(0)
  const [selectedOption, setSelectedOption] = React.useState('One Way')

  // const [dense, setDense] = React.useState(false);

  // const [secondary, setSecondary] = React.useState(false)

  //  const [top100Films, setAirportsOption] = React.useState<AirtportsData["top100Films"]>([]);
  //const [top100Film, setTop100Film] = React.useState<string>('');

  // const [isOpen, setIsOpen] = React.useState(true)

  // const { loading, error, data } = useQuery<AirtportsData>(AIRPORT_QUERY)

  const { data } = useQuery<AirtportsData>(AIRPORT_QUERY)

  
  // React.useEffect(() => {
  //   const fetchData = async () => {
  //     try {
  //       const response = await fetch('<YOUR_GRAPHQL_ENDPOINT>', {
  //         method: 'POST',
  //         headers: {
  //           'Content-Type': 'application/json',
  //         },
  //         body: JSON.stringify({
  //           query: AIRPORT_QUERY,
  //         }),
  //       });
  //       const result = await response.json();
  //       const airportsData = result.data as AirtportsData;
  //       setAirportsOption(airportsData.top100Films);
  //     } catch (error) {
  //       console.error('Error fetching airport data:', error);
  //     }
  //   };

  //   fetchData();
  // }, []);

  const top100Films = data?.top100Films || []

  // const [selectedDate, setSelectedDate] = React.useState(null);

  // const handleDateChange = (date) => {
  //   setSelectedDate(date);
  // };

  const [dateRange, setDateRange] = React.useState<CardNavigationState>({
    startDate: null,
    endDate: null,
    focusedInput: null
  })

  const handleChange = (event: React.SyntheticEvent, newValue: number) => {
    setValue(newValue)
  }

  const handleNestedChange = (event: React.SyntheticEvent, newValue: number) => {
    setNestedValue(newValue)
  }

  // const handleOptionChange = (event: React.ChangeEvent<{ value: unknown }>) => {
  //   setSelectedOption(event.target.value as string);
  // };

  const handleOptionChange = (event: SelectChangeEvent<string>) => {
    setSelectedOption(event.target.value)
  }

  const theme = useTheme()

  const isMobileLandscape = useMediaQuery(theme.breakpoints.down('md'))

  const handleDateChange = ({ startDate, endDate }: { startDate: Moment | null; endDate: Moment | null }) => {
    const currentDate = moment()
    if (startDate && startDate.isBefore(currentDate)) {
      startDate = currentDate
    }
    setDateRange(prevState => ({
      ...prevState,
      startDate,
      endDate
    }))
  }

  const isOutsideRanges = (date: Moment) => {
    return date.isBefore(moment(), 'day')
  }

  const isDesktop = useMediaQuery('(min-width: 1024px)')
  const numberOfMonths = isDesktop ? 2 : 1

  return (
    <>
      <Tabs
        value={value}
        onChange={handleChange}
        aria-label='basic tabs example'
        sx={{
          backgroundColor: '#fff',
          width: 'fit-content',
          borderRadius: '30px',
          marginBottom: '2rem',
          '& .MuiTabs-indicator': { display: 'none' },
          '& .Mui-selected': { backgroundColor: theme.palette.common.black, borderRadius: '30px', margin: '4px' }
        }}
      >
        <Tab
          label='Business'
          {...a11yProps(0)}
          sx={{
            minHeight: 'auto',
            paddingTop: '11px',
            paddingBottom: '11px',
            '&.Mui-selected': { color: theme.palette.common.white }
          }}
        />
        <Tab
          label='Personal'
          {...a11yProps(1)}
          sx={{
            minHeight: 'auto',
            paddingTop: '11px',
            paddingBottom: '11px',
            '&.Mui-selected': { color: theme.palette.common.white }
          }}
        />
      </Tabs>
      <Card sx={{ overflow: 'visible', borderRadius: 3 }} className='mainSearchBox'>
        <Box sx={{ display: 'flex', width: '100%' }}>
          <TabPanel value={value} index={0}>
            <Stack direction={isMobileLandscape ? 'column' : 'row'} spacing={2}>
              <Tabs
                value={nestedValue}
                onChange={handleNestedChange}
                aria-label='nested tabs example'
                orientation={isMobileLandscape ? 'horizontal' : 'vertical'}
                variant={isMobileLandscape ? 'standard' : 'scrollable'}
              >
                <Tab label='Flight' {...a11yProps(0)} icon={<FlightIcon sx={{ rotate: '45deg' }} />} />
                <Tab label='Hotel' {...a11yProps(1)} icon={<HotelIcon />} />
              </Tabs>
              <TabPanel value={nestedValue} index={0}>
                <Select
                  value={selectedOption}
                  onChange={handleOptionChange}
                  sx={{
                    '& .MuiOutlinedInput-notchedOutline': {
                      borderColor: 'transparent !important',
                      boxShadow: 'none'
                    },
                    '&.MuiInputBase-root:hover .MuiOutlinedInput-notchedOutline': {
                      borderColor: 'transparent'
                    }
                  }}
                  MenuProps={{
                    anchorOrigin: {
                      vertical: 'bottom',
                      horizontal: 'right'
                    },
                    transformOrigin: {
                      vertical: 'top',
                      horizontal: 'right'
                    },

                    sx: {
                      overflow: 'hidden',
                      marginTop: theme.spacing(4),
                      '& .MuiMenu-list': {
                        padding: 0,
                        minWidth: 200
                      },
                      '& .MuiMenuItem-root': {
                        paddingTop: '0.5rem',
                        paddingBottom: '0.5rem'
                      },
                      [theme.breakpoints.down('sm')]: {
                        '& .MuiMenu-paper': {
                          width: '100%'
                        }
                      }
                    }
                  }}
                >
                  <MenuItem value='One Way'>One Way</MenuItem>
                  <MenuItem value='Two Way'>Two Way</MenuItem>
                </Select>

                <Grid container spacing={2}>
                  <Grid item>
                    <FormControl>
                      <InputLabel
                        htmlFor='from-input'
                        sx={{
                          transform: 'none',
                          position: 'static',
                          '&.Mui-focused': {
                            color: 'inherit'
                          },
                          marginBottom: '5px'
                        }}
                        disableAnimation
                      >
                        From
                      </InputLabel>
                      <Autocomplete
                        disablePortal
                        className='boxShadowBox'
                        options={top100Films}
                        getOptionLabel={(option: Top100Film) => `${option.cityName},${option.country} `}

                        // renderOption={(props, option: Top100Film, state: AutocompleteRenderOptionState) => (

                        renderOption={(props, option: Top100Film) => (

                          <ListItem {...props}>
                            <FlightIcon sx={{color:'#687591',marginRight:'10px', fontSize:'1.25rem', rotate:'45deg'}}/>
                            <ListItemText
                              primary={`${option.cityName},${option.country} `}
                              secondary={option.airportName}
                            />
                           <span style={{fontWeight:'500', fontSize:'0.875rem', marginLeft:'10px'}}>{option.countryCode}</span>
                          </ListItem>
                        )}
                      
                        fullWidth
                        sx={{
                          width: 290,
                          '.MuiOutlinedInput-root': {
                            padding: '2px'
                          }
                        }}
                        PaperComponent={({ children }) => (
                          <Paper
                            sx={{ width: '19rem', marginTop: 4, paddingBottom: 3, paddingTop: 3 }}
                            className='boxShadowBox'
                          >
                            {children}
                          </Paper>
                        )}
                        renderInput={params => (
                          <TextField
                            {...params}
                            sx={{
                              '& .MuiOutlinedInput-notchedOutline': {
                                borderColor: 'rgba(58, 53, 65, 0.32)',
                                borderWidth: '1px',
                                boxShadow: 'none',
                                border: 'none'
                              },
                              '&:hover .MuiOutlinedInput-notchedOutline': {
                                borderColor: 'rgba(58, 53, 65, 0.32)',
                                borderWidth: '1px'
                              },
                              '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                                borderColor: 'rgba(58, 53, 65, 0.32)',
                                borderWidth: '1px'
                              }
                            }}
                          />
                        )}
                      />
                    </FormControl>
                    <FlightIcon
                      sx={{
                        rotate: '90deg',
                        marginTop: '2.25rem',
                        position: 'relative',
                        left: '4px',
                        top: '0px',
                        fontSize: '1.25rem'
                      }}
                    />
                    <FlightIcon
                      sx={{
                        rotate: '-90deg',
                        marginTop: '2.25rem',
                        position: 'relative',
                        right: '4px',
                        top: '7px',
                        fontSize: '1.25rem'
                      }}
                    />
                    <FormControl>
                      <InputLabel
                        htmlFor='from-input'
                        sx={{
                          transform: 'none',
                          position: 'static',
                          '&.Mui-focused': {
                            color: 'inherit'
                          },
                          marginBottom: '5px'
                        }}
                        disableAnimation
                      >
                        To
                      </InputLabel>
                      <Autocomplete
                        disablePortal
                        className='boxShadowBox'
                        options={top100Films}
                        getOptionLabel={(option: Top100Film) => `${option.cityName},${option.country} `}

                        // renderOption={(props, option: Top100Film, state: AutocompleteRenderOptionState) => (

                        renderOption={(props, option: Top100Film) => (

                          <ListItem {...props}>
                            <FlightIcon sx={{color:'#687591',marginRight:'10px', fontSize:'1.25rem', rotate:'45deg'}}/>
                            <ListItemText
                              primary={`${option.cityName},${option.country} `}
                              secondary={option.airportName}
                            />
                            <span style={{fontWeight:'500', fontSize:'0.875rem', marginLeft:'10px'}}> {option.countryCode}</span>
                           
                          </ListItem>
                        )}
                       
                        fullWidth
                        sx={{
                          width: 290,
                          '.MuiOutlinedInput-root': {
                            padding: '2px'
                          }
                        }}
                        PaperComponent={({ children }) => (
                          <Paper
                            sx={{ width: '19rem', marginTop: 4, paddingBottom: 3, paddingTop: 3 }}
                            className='boxShadowBox'
                          >
                            {children}
                          </Paper>
                        )}
                        renderInput={params => (
                          <TextField
                            {...params}
                            sx={{
                              '& .MuiOutlinedInput-notchedOutline': {
                                borderColor: 'rgba(58, 53, 65, 0.32)',
                                borderWidth: '1px',
                                boxShadow: 'none',
                                border: 'none'
                              },
                              '&:hover .MuiOutlinedInput-notchedOutline': {
                                borderColor: 'rgba(58, 53, 65, 0.32)',
                                borderWidth: '1px'
                              },
                              '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                                borderColor: 'rgba(58, 53, 65, 0.32)',
                                borderWidth: '1px'
                              }
                            }}
                          />
                        )}
                      />
                    </FormControl>
                  </Grid>
                  <Grid item>
                    <Box sx={{ position: 'relative', zIndex: 1 }} className='calenderBox'>
                      <FormControl>
                        <InputLabel
                          htmlFor='from-input'
                          sx={{
                            transform: 'none',
                            position: 'static',
                            '&.Mui-focused': {
                              color: 'inherit'
                            },
                            marginBottom: '5px'
                          }}
                          disableAnimation
                        >
                          Departure-Return
                        </InputLabel>
                        <DateRangePicker
                          startDate={dateRange.startDate}
                          endDate={dateRange.endDate}
                          onDatesChange={handleDateChange}
                          focusedInput={dateRange.focusedInput}
                          onFocusChange={focusedInput => setDateRange(prevState => ({ ...prevState, focusedInput }))}
                          small={true}
                          showDefaultInputIcon={true}

                          // required={true}

                          showClearDates={true}
                          reopenPickerOnClearDates={true}
                          isOutsideRange={isOutsideRanges}

                          // portal={document.getElementById('portal')!}

                          disableScroll
                          hideKeyboardShortcutsPanel 
                          displayFormat='ddd DD MMM'
                          numberOfMonths={numberOfMonths}
                          withPortal={!isDesktop}
                          anchorDirection='right'
                        />
                      </FormControl>
                    </Box>
                  </Grid>
                </Grid>
              </TabPanel>
              <TabPanel value={nestedValue} index={1}>
                Nested Tab 2 Content
              </TabPanel>
            </Stack>
          </TabPanel>
          <TabPanel value={value} index={1}>
            Item Two Content
          </TabPanel>
        </Box>
      </Card>
    </>
  )
}

export default CardNavigation
