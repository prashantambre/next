// import React from 'react';

// // interface ImageIconProps {
// //   src: string;
// //   alt: string;
// // }

// interface LogPathProps {
//   logo2: string;
// }

// const LogPath: React.FC<LogPathProps> = ({ logo2 }) => (

//   <img src={logo2} alt="Logo" />
// );

// export default LogPath;


import { styled } from '@mui/material/styles';

// Styled component for the trophy image
const TrophyImg = styled('img')({
  right: 36,
  bottom: 20,
  height: 98,
  position: 'absolute',
});

type TrophyImgProps = {
  alt: string;
  src: string;
};

const LogPath: React.FC<TrophyImgProps> = ({ alt, src }) => {
  return <TrophyImg alt={alt} src={src} />;
};

export default LogPath;