
import { useQuery } from "@apollo/client";
import { gql } from "@apollo/client";

const USERS_QUERY = gql`
  query Users {
    users {
      id
      name
    }
  }
`;

interface User {
  id: string;
  name: string;
}

interface UserData {
  users: User[];
}

const UserList = () => {
  const { loading, error, data } = useQuery<UserData>(USERS_QUERY);

  if (loading) return <p>Loading...</p>;
  if (error || !data) return <p>Error :</p>;

  // console.log(data, "working");
  return (
    <div>
      <h1>User List</h1>
      <ul>
        {data?.users.map((user) => (
          <li key={user.id}>
            <h3>{user.name}</h3>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default UserList;




