// import * as React from "react";
// import {
//   Box,
//   FormControlLabel,
//   Checkbox,
//   Button,
//   Tooltip,
//   IconButton,
// } from "@mui/material";
// import { useQuery, gql } from "@apollo/client";

// const REFUNDABILITY_QUERY = gql`
//   query Refunds {
//     refunds {
//       type
//     }
//   }
// `;

// interface Refund {
//   type: string;
//   checked: boolean;
// }

// interface RefundData {
//   refunds: Refund[];
// }

// interface RefundFilterProps {
//   onRefundSelectedChange: (selectedValue: string[]) => void;
// }

// const Refundability = ({ onRefundSelectedChange }: RefundFilterProps) => {
//   const [refunds, setRefunds] = React.useState<RefundData["refunds"]>([]);
//   const { loading, error, data } = useQuery<RefundData>(REFUNDABILITY_QUERY);

//   React.useEffect(() => {
//     if (!loading && data) {
//       const refundTypesWithChecked = data.refunds.map((refund) => ({
//         ...refund,
//         checked: false,
//       }));
//       setRefunds(refundTypesWithChecked);
//     }
//   }, [loading, data]);

//   const handleToggleRefund = (index: number) => {
//     const updatedRefunds = [...refunds];
//     updatedRefunds[index].checked = !updatedRefunds[index].checked;
//     setRefunds(updatedRefunds);

//     const selectedRefunds = updatedRefunds
//       .filter((refund) => refund.checked)
//       .map((refund) => refund.type);
//     onRefundSelectedChange(selectedRefunds);
//   };

//   const handleClearAll = () => {
//     const updatedRefunds = refunds.map((refund) => ({
//       ...refund,
//       checked: false,
//     }));
//     setRefunds(updatedRefunds);
//   };

//   const handleSelectAll = () => {
//     const allChecked = refunds.every((refund) => refund.checked);
//     const updatedRefunds = refunds.map((refund) => ({
//       ...refund,
//       checked: !allChecked,
//     }));
//     setRefunds(updatedRefunds);
//   };

//   if (loading) return <p>Loading...</p>;
//   if (error || !data) return <p>Error :</p>;

//   return (
//     <>
//       <Box sx={{ display: "flex", flexDirection: "column" }} className="filterBox">
//         <Button
//           variant="text"
//           onClick={handleClearAll}
//           className="clearButton"
//         >
//           Clear
//         </Button>
//         <FormControlLabel
//           control={
//             <Checkbox
//               checked={refunds.every((refund) => refund.checked)}
//               indeterminate={
//                 refunds.some((refund) => refund.checked) &&
//                 !refunds.every((refund) => refund.checked)
//               }
//               onChange={handleSelectAll}
//             />
//           }
//           label={
//             refunds.every((refund) => refund.checked)
//               ? "All Refunds"
//               : "All Refunds"
//           }
//           sx={{
//             "& .Mui-checked": {
//               color: "#F0971A !important",
//             },
//             textTransform: "capitalize",
//             "& .MuiCheckbox-indeterminate": {
//               color: "#F0971A !important",
//             },
//           }}
//         />
//         {refunds.map((refund, index) => (
//           <Tooltip
//             key={refund.type}
//             title={
//               refund.checked ? (
//                 <IconButton
//                   onClick={() => {
//                     handleToggleRefund(index);
//                   }}
//                 >
//                   Only
//                 </IconButton>
//               ) : (
//                 ""
//               )
//             }
//             placement="right"
//             classes={{ tooltip: "tooltipBox" }}
//           >
//             <FormControlLabel
//               key={refund.type}
//               control={
//                 <Checkbox
//                   checked={refund.checked}
//                   onChange={() => handleToggleRefund(index)}
//                   sx={{
//                     "& .Mui-checked": {
//                       color: "#F0971A !important",
//                     },
//                   }}
//                 />
//               }
//               label={refund.type}
//               sx={{
//                 "& .Mui-checked": {
//                   color: "#F0971A !important",
//                 },
//                 textTransform: "capitalize",
//                 "& .MuiCheckbox-indeterminate": {
//                   color: "#F0971A !important",
//                 },
//               }}
//             />
//           </Tooltip>
//         ))}
//       </Box>
//     </>
//   );
// };

// export default Refundability;

import * as React from "react";
import {
  Box,
  FormControlLabel,
  Checkbox,
  Button,
  Tooltip,
  IconButton,
} from "@mui/material";
import { useQuery, gql } from "@apollo/client";

const REFUNDABILITY_QUERY = gql`
  query Refunds {
    refunds {
      type
    }
  }
`;

interface Refund {
  type: string;
  checked: boolean;
}

interface RefundData {
  refunds: Refund[];
}

interface RefundFilterProps {
  onRefundClear: (event) => void;
  onRefundSelectedChange: (selectedValue: string[]) => void;
}

const Refundability = ({ onRefundClear, onRefundSelectedChange }: RefundFilterProps) => {
  const [refunds, setRefunds] = React.useState<RefundData["refunds"]>([]);
  const [refundsSelectedValue, setRefundsSelectedValue] = React.useState<string[]>([]);
  const { loading, error, data } = useQuery<RefundData>(REFUNDABILITY_QUERY);

  React.useEffect(() => {
    if (!loading && data) {
      const refundTypesWithChecked = data.refunds.map((refund) => ({
        ...refund,
        checked: refundsSelectedValue.indexOf(refund.type) > -1,
      }));
      setRefunds(refundTypesWithChecked);
    }
  }, [loading, data, refundsSelectedValue]);

  React.useEffect(() => {
    const storedSelectedRefunds = localStorage.getItem('selectedRefunds');
    if (storedSelectedRefunds) {
      const parsedRefunds = JSON.parse(storedSelectedRefunds);
      setRefundsSelectedValue(parsedRefunds);
    }
  }, []);

  React.useEffect(() => {
    localStorage.setItem('selectedRefunds', JSON.stringify(refundsSelectedValue));
  }, [refundsSelectedValue]);

  const handleToggleRefund = (index: number) => {
    const updatedRefunds = [...refunds];
    updatedRefunds[index].checked = !updatedRefunds[index].checked;
    setRefunds(updatedRefunds);

    const selectedRefunds = updatedRefunds
      .filter((refund) => refund.checked)
      .map((refund) => refund.type);
    setRefundsSelectedValue(selectedRefunds);
    onRefundSelectedChange(selectedRefunds);
  };

  const handleDeslectAll = (index: number) => {
    const updatedRefunds = refunds.map((refund, i) => ({
      ...refund,
      checked: i === index,
    }));
    setRefunds(updatedRefunds);
    const selectedRefunds = updatedRefunds
      .filter((refund) => refund.checked)
      .map((refund) => refund.type);
    setRefundsSelectedValue(selectedRefunds);
    onRefundSelectedChange(selectedRefunds);
  };

  const handleClearAll = () => {
    const updatedRefunds = refunds.map((refund) => ({
      ...refund,
      checked: false,
    }));
    setRefunds(updatedRefunds);
    setRefundsSelectedValue([]);
    onRefundClear(event);
  };

  const handleSelectAll = () => {
    const allChecked = refunds.every((refund) => refund.checked);
    const updatedRefunds = refunds.map((refund) => ({
      ...refund,
      checked: !allChecked,
    }));
    setRefunds(updatedRefunds);
    const selectedRefunds = updatedRefunds
    .filter((refund) => refund.checked)
    .map((refund) => refund.type);
  setRefundsSelectedValue(selectedRefunds);
  onRefundSelectedChange(selectedRefunds);
  };

  if (loading) return <p>Loading...</p>;
  if (error || !data) return <p>Error :</p>;

  return (
    <>
      <Box sx={{ display: "flex", flexDirection: "column" }} className="filterBox">
        <Button
          variant="text"
          onClick={handleClearAll}
          className="clearButton"
        >
          Clear
        </Button>
        <FormControlLabel
          control={
            <Checkbox
              checked={refunds.every((refund) => refund.checked)}
              indeterminate={
                refunds.some((refund) => refund.checked) &&
                !refunds.every((refund) => refund.checked)
              }
              onChange={handleSelectAll}
            />
          }
          label={
            refunds.every((refund) => refund.checked)
              ? "All Refunds"
              : "All Refunds"
          }
          sx={{
            "& .Mui-checked": {
              color: "#F0971A !important",
            },
            textTransform: "capitalize",
            "& .MuiCheckbox-indeterminate": {
              color: "#F0971A !important",
            },
          }}
        />
        {refunds.map((refund, index) => (
          <Tooltip
            key={refund.type}
            title={
              refund.checked ? (
                <IconButton
                  onClick={() => {
                    handleDeslectAll(index);
                  }}
                >
                  Only
                </IconButton>
              ) : (
                ""
              )
            }
            placement="right"
            classes={{ tooltip: "tooltipBox" }}
          >
            <FormControlLabel
              key={refund.type}
              control={
                <Checkbox
                  checked={refund.checked}
                  onChange={() => handleToggleRefund(index)}
                  sx={{
                    "& .Mui-checked": {
                      color: "#F0971A !important",
                    },
                  }}
                />
              }
              label={refund.type}
              sx={{
                "& .Mui-checked": {
                  color: "#F0971A !important",
                },
                textTransform: "capitalize",
                "& .MuiCheckbox-indeterminate": {
                  color: "#F0971A !important",
                },
              }}
            />
          </Tooltip>
        ))}
      </Box>
    </>
  );
};

export default Refundability;


