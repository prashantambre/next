

import RequestSearch from './RequestSearch';

const Requests = () => {
    return (
        <>
      
            <RequestSearch/>
       
        </>
    )
}

export default  Requests;