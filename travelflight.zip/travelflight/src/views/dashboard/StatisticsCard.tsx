// ** React Imports
// import { ReactElement } from 'react'

// ** MUI Imports
import Box from '@mui/material/Box'
import Grid from '@mui/material/Grid'
import Card from '@mui/material/Card'

import CardHeader from '@mui/material/CardHeader'

// import Typography from '@mui/material/Typography'
import dynamic from 'next/dynamic' // import the dynamic function from next/dynamic
// Dynamically import the Typography component  
const Typography = dynamic(() => import('@mui/material/Typography'), {
  ssr: false // Set `ssr` option to `false` to prevent hydration errors
})
import CardContent from '@mui/material/CardContent'
import FormGroup from '@mui/material/FormGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import Checkbox from '@mui/material/Checkbox';




// ** Types

// import { ThemeColor } from 'src/@core/layouts/types'

import { Button, ButtonGroup } from '@mui/material'

// interface DataType {
//   stats: string
//   title: string
//   color: ThemeColor
//   icon: ReactElement
// }

const buttons = [
  <Button key="one">-</Button>,
  <Button key="two">1</Button>,
  <Button key="three">+</Button>,
];


const renderStats = () => {
  return  (
    <>
    <Grid item xs={12} sm={6}>
      <Box sx={{ display: 'flex', alignItems: 'center' }}> 
        <Box sx={{ display: 'flex', flexDirection: 'column', mr: 3 }}>
        <Typography variant='caption' sx={{fontWeight:'bold'}}>Adults</Typography>
        <Typography variant='caption'>Over 12 years</Typography>
          
        </Box>
      
        <ButtonGroup size="small" aria-label="small button group">
         {buttons}
        </ButtonGroup>
      </Box>
    </Grid>
    <Grid item xs={12} sm={6}>
      <Box sx={{ display: 'flex', alignItems: 'center' }}> 
        <Box sx={{ display: 'flex', flexDirection: 'column', mr: 3 }}>
        <Typography variant='caption' sx={{fontWeight:'bold'}}>Children</Typography>
        <Typography variant='caption'>Over 12 years</Typography> 
        </Box>
        <ButtonGroup size="small" aria-label="small button group">
         {buttons}
        </ButtonGroup>
      </Box>
    </Grid>
    <Grid item xs={12} sm={6} sx={{marginTop:'1rem'}}>
      <Box sx={{ display: 'flex', alignItems: 'center' }}> 
        <Box sx={{ display: 'flex', flexDirection: 'column', mr: 3 }}>
        <Typography variant='caption' sx={{fontWeight:'bold'}}>Infants</Typography>
        <Typography variant='caption'>Over 12 years</Typography>
          
        </Box>
        <ButtonGroup size="small" aria-label="small button group">
         {buttons}
        </ButtonGroup>
      </Box>
    </Grid>
    </>
  )
}

const StatisticsCard = () => {
  return (
    <>
    <Card sx={{ p: 2, width: '34rem' }}>
      <CardHeader
        title='Travelers'
       
        subheader={
          <Typography variant='body2'>
            <Box component='span' sx={{ fontWeight: 600, color: 'text.primary' }}>
            <FormGroup>
             <FormControlLabel control={<Checkbox defaultChecked />} label="Include me" /> 
           </FormGroup>
            </Box>
            {/* {' '}
            😎 this month */}
          </Typography>
        }
        titleTypographyProps={{
          sx: {
            mb: 2.5,
            lineHeight: '2rem !important',
            letterSpacing: '0.15px !important'
          }
        }}
      />
      <CardContent sx={{ pt: theme => `${theme.spacing(3)} !important` }}>
        <Grid container spacing={[5, 0]}>
          {renderStats()}
        </Grid>
      </CardContent>
    </Card>
    </>
  )
}

export default StatisticsCard
