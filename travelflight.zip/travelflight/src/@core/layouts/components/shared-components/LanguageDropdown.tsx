// ** React Imports
import { useState, Fragment, useEffect, } from 'react' 
import Box from '@mui/material/Box' 
import { styled} from '@mui/material/styles' 
import MuiMenuItem, { MenuItemProps } from '@mui/material/MenuItem'
import "country-flag-icons/3x2/flags.css"; 
import dynamic from 'next/dynamic'
import { TypographyProps } from '@mui/material/Typography' 
import { useQuery } from "@apollo/client";
import { gql } from "@apollo/client";
import  React from 'react'
import Select, { SelectChangeEvent } from '@mui/material/Select';  
import { useTheme } from '@mui/material/styles'

const Typography = dynamic(
  () => import('@mui/material/Typography'),
  { ssr: false }
) as React.ComponentType<TypographyProps> 

const MenuItem = styled(MuiMenuItem)<MenuItemProps>(({ theme }) => ({
  paddingTop: theme.spacing(3),
  paddingBottom: theme.spacing(3),
  borderBottom: `1px solid ${theme.palette.divider}`
}))

// const styles = {
//   maxHeight: 349,
//   '& .MuiMenuItem-root:last-of-type': {
//     border: 0
//   }
// }
// const PerfectScrollbar = styled(PerfectScrollbarComponent)({
//   ...styles
// })

const MenuItemTitle = styled(Typography)<TypographyProps>(({ theme }) => ({
  fontWeight: 600,
  flex: '1 1 100%',
  overflow: 'hidden',
  fontSize: '0.875rem',
  whiteSpace: 'nowrap',
  textOverflow: 'ellipsis',
  marginBottom: theme.spacing(0.75)
}))

const LANGUAGE_QUERY = gql`
  query Languages {
    languages {
      id 
      name 
      flag
    }
  }
`;
interface Language {
  id: string;
  name : string
  flag: string
}

interface LanguageData {
  languages: Language[];
}

const LanguageDropdown = () => { 

  const theme = useTheme()

  const [languages, setLanguages] = useState<Language[]>([]);
  const [language, setLanguage] = useState<string>('');

  const { loading, error, data } = useQuery<LanguageData>(LANGUAGE_QUERY);
  console.log(data,'done')
  useEffect(() => {
    if (data && data.languages) {
      setLanguages(data.languages);
      if (data.languages.length > 0) {
        setLanguage(data.languages[0].id);
      }
    }
  }, [data]);

  if (loading) return <p>Loading...</p>;
  if (error || !data) return <p>Error :</p>;



const handleChange = (event: SelectChangeEvent) => {
  setLanguage(event.target.value);
};
 
  return (
    <Fragment>  
     
      <Select
      value={language}
      onChange={handleChange}
      variant="standard"
      disableUnderline
      sx={{ display: 'flex', alignItems: 'center',
      '&.Mui-focused': { 
        backgroundColor: '#fff'
      },
      '& .MuiSelect-select:focus': { 
        backgroundColor: '#fff'
      },
      '& .MuiSelect-select': {  
        paddingRight:'0rem !important',
        paddingLeft:'0.5rem'
      }
      
      }}

      MenuProps={{
        anchorOrigin: {
          vertical: 'bottom',
          horizontal: 'right'
        },
        transformOrigin: {
          vertical: 'top',
          horizontal: 'right'
        },
       
        sx: {
          overflow: 'hidden', 
          marginTop: theme.spacing(4),
          '& .MuiMenu-list': {
            padding: 0,
            minWidth:200,
          },
          '& .MuiMenuItem-root':{
            paddingTop:'0.5rem',
            paddingBottom:'0.5rem'
          },
          [theme.breakpoints.down('sm')]: {
            '& .MuiMenu-paper': { 
              width:'100%'
            }
          }
          
        }
      }}
     
    >
      {languages.map((item) => (
        <MenuItem key={item.id} value={item.id}>
          <Box sx={{ width: '100%', display: 'flex', alignItems: 'center' }}>
            <Typography variant='caption'  sx={{
                '& .MuiSvgIcon-root': { 
                    fontSize:21,
                    position:'relative',
                    top:1
                  },
              }}>
                 <span className={`flag:${item.flag}`} /> 
          </Typography>
          <Box sx={{ mx: 1, flex: '1 1', display: 'flex', overflow: 'hidden', flexDirection: 'column' }}>
          <MenuItemTitle>{item.name}</MenuItemTitle>
          </Box>
          </Box>
        </MenuItem>
      ))}
    </Select>

    </Fragment>
  )
}

export default LanguageDropdown
