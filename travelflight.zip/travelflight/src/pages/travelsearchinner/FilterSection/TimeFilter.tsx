import * as React from "react";

import Typography from '@mui/material/Typography';

import CardContent from '@mui/material/CardContent';

import Box from '@mui/material/Box';
import Stack from "@mui/material/Stack";
import ToggleButton from "@mui/material/ToggleButton";
import ToggleButtonGroup from "@mui/material/ToggleButtonGroup";
import { useTheme } from '@mui/material/styles'


import { Tab, Tabs,Button} from "@mui/material";

import {WbSunny, WbTwilight,DarkMode, WbCloudy} from '@mui/icons-material';

interface TabPanelProps {
    children?: React.ReactNode;
    index: number;
    value: number;
  }

  
  function CustomTabPanel(props: TabPanelProps) {
    const { children, value, index, ...other } = props;
  
    return (
      <div
        role="tabpanel"
        hidden={value !== index}
        id={`simple-tabpanel-${index}`}
        aria-labelledby={`simple-tab-${index}`}
        {...other}
      >
        {value === index && (
          <Box sx={{ p: 3 }}>
            <Typography>{children}</Typography>
          </Box>
        )}
      </div>
    );
  }
  
  function a11yProps(index: number) {
    return {
      id: `simple-tab-${index}`,
      'aria-controls': `simple-tabpanel-${index}`,
    };
  }
  

  interface TimeFilterProps {
    onSelectedClassesChange: (selectedValue: string[]) => void;
    onClearAll: (event) => void;
  }
  
  const TIME_FILTER_KEY = "selectedTimeClasses"; // Key for localStorage

  

// const TimeFilter = ({ onSelectedClassesChange, onClearAll  }) => {

  const TimeFilter = ({
    onSelectedClassesChange,
    onClearAll,
  }: TimeFilterProps) => {
    const [selectedClasses, setSelectedClasses] = React.useState<string[]>([]);
    const [value, setValue] = React.useState(0);
    const handleChangeTab = (event: React.SyntheticEvent, newValue: number) => {
      setValue(newValue);
    };

    React.useEffect(() => {
      const storedSelectedClasses = localStorage.getItem(TIME_FILTER_KEY);
      if (storedSelectedClasses) {
        const parsedClasses = JSON.parse(storedSelectedClasses);
        setSelectedClasses(parsedClasses);
      }
    }, []);

    React.useEffect(() => {
      localStorage.setItem(TIME_FILTER_KEY, JSON.stringify(selectedClasses));
    }, [selectedClasses]);

    
    const handleChange = (
        event: React.MouseEvent<HTMLElement>,
        newAlignment: string
      ) => {

        // Convert the newAlignment to lowercase

        const lowerCaseAlignment = newAlignment.toLowerCase();
    
        // Check if the selected class is already in the array
        
        const isSelected = selectedClasses.includes(lowerCaseAlignment);
    
        const updatedClasses = isSelected
          ? selectedClasses.filter((item) => item !== lowerCaseAlignment)
          : [...selectedClasses, lowerCaseAlignment];
    
        setSelectedClasses(updatedClasses) 
        onSelectedClassesChange(updatedClasses);
      };

      const theme = useTheme()
      const children = [
        <ToggleButton   value="12AM-6AM" key="12AM-6AM"  sx={{border:'none', 
         borderRadius:'6px !important',
         marginRight:'5px', 
         '&.Mui-selected':{
            background:theme.palette.secondary.light
         },

         '&.Mui-selected .MuiSvgIcon-root':{
                color:theme.palette.common.white
         },
         '&.Mui-selected h6':{
            color:theme.palette.common.white
         },
         '&.Mui-selected:hover':{
            background:theme.palette.secondary.light
         },
         }}> 
          <Stack direction="column" alignItems="center">
        <WbSunny sx={{
            '&.MuiSvgIcon-root':{
                marginBottom:'8px',
                color:theme.palette.common.black
            }
        }}  />
        <WbCloudy sx={{
            '&.MuiSvgIcon-root':{
                position:'absolute',
                left:'1.825rem',
                top:'10px',
                color:theme.palette.common.black
            }
        }}  />
        <Typography  variant='subtitle2' display='block' gutterBottom sx={{
            fontSize:'10px'
        }}>
          12AM - 6AM
        </Typography>
         </Stack>
      
        </ToggleButton>,
        <ToggleButton value="6AM-12PM" key="6AM-12PM" sx={{ border:'none',
         borderRadius:'6px !important',
         marginRight:'5px', 
         '&.Mui-selected':{
            background:theme.palette.secondary.light
         }, 
         '&.Mui-selected .MuiSvgIcon-root':{
                color:theme.palette.common.white
         },
         '&.Mui-selected h6':{
            color:theme.palette.common.white
         },
         '&.Mui-selected:hover':{
            background:theme.palette.secondary.light
         },
         }}> 
         <Stack direction="column" alignItems="center">
          <WbSunny sx={{
            '&.MuiSvgIcon-root':{
                marginBottom:'8px',
                color:theme.palette.common.black
            }
        }}/>
          <Typography  variant='subtitle2' display='block' gutterBottom sx={{
            fontSize:'10px'
        }}>
          6AM - 12PM
          </Typography> 
          </Stack>
        </ToggleButton>,
        <ToggleButton value="12PM-6PM" key="12PM-6PM" sx={{border:'none', 
         borderRadius:'6px !important', 
         marginRight:'5px',
         '&.Mui-selected':{
            background:theme.palette.secondary.light
         }, 
         '&.Mui-selected .MuiSvgIcon-root':{
                color:theme.palette.common.white
         },
         '&.Mui-selected h6':{
            color:theme.palette.common.white
         },
         '&.Mui-selected:hover':{
            background:theme.palette.secondary.light
         },
         }}>
          <Stack direction="column" alignItems="center">
          <WbTwilight sx={{
            '&.MuiSvgIcon-root':{
                marginBottom:'8px',
                color:theme.palette.common.black
            }
        }}/>
        <Typography  variant='subtitle2' display='block' gutterBottom sx={{
            fontSize:'10px'
        }}>
          12PM - 6PM
          </Typography> 
          </Stack>
        </ToggleButton>,
        <ToggleButton value="6PM-12AM" key="6PM-12AM" sx={{border:'none',
          borderRadius:'6px !important', 
          marginRight:'5px',
          '&.Mui-selected':{
            background:theme.palette.secondary.light
         },
         '&.Mui-selected .MuiSvgIcon-root':{
                color:theme.palette.common.white
         },
         '&.Mui-selected h6':{
            color:theme.palette.common.white
         },
         '&.Mui-selected:hover':{
            background:theme.palette.secondary.light
         },
          }}>
          <Stack direction="column" alignItems="center">
          <DarkMode sx={{
            '&.MuiSvgIcon-root':{
                marginBottom:'8px',
                color:theme.palette.common.black
            }
        }}/>
         <Typography  variant='subtitle2' display='block' gutterBottom sx={{
            fontSize:'10px'
        }}>
           6PM - 12AM
          </Typography> 
          </Stack>
        </ToggleButton>
      ];

      const control = {
        value: selectedClasses,
        onChange: handleChange,
        exclusive: true
      };

    

      const handleClearAll = () => {
        setSelectedClasses([]);
        onClearAll(event);
      };
      
     return (
        <> 
        
         <Box sx={{ display: "flex", flexDirection: "column" }} className="filterBox">
         <Button variant="text" onClick={handleClearAll} className="clearButton">
          Clear  
        </Button>

      <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
        <Tabs value={value} onChange={handleChangeTab} 
         sx={{
            '& .MuiButtonBase-root.Mui-selected':{
              color:`${theme.palette.secondary.light} !important` ,
              textTransform:'capitalize'
            },
            '& .MuiButtonBase-root':{
              textTransform:'capitalize'
            },
            '& .MuiTabs-indicator':{
              background:theme.palette.secondary.light
            }
            
          }}
        >
          <Tab label="Outbound" {...a11yProps(0)} />
          <Tab label="Return" {...a11yProps(1)} /> 
        </Tabs>
      </Box>
      <CustomTabPanel value={value} index={0}>
      <CardContent sx={{ pt: (theme) => `${theme.spacing(3)} !important`, px: 0,  pb:'0px !important'}}>
        <Stack spacing={2} alignItems="left">
          <ToggleButtonGroup
            size="small"
            {...control}
            aria-label="Small sizes"
            sx={{ display: 'block' }}
            
          >
            {/* {children} */}

            {children.map((child, index) => (
                <ToggleButton
                  key={index}
                  value={child.props.value}
                  selected={selectedClasses.includes(child.props.value.toLowerCase())}
                  sx={child.props.sx}
                  onClick={(e) => handleChange(e, child.props.value)}
                >
                  {child.props.children}
                </ToggleButton>
              ))}


          </ToggleButtonGroup>
        </Stack>
      </CardContent>
      </CustomTabPanel>
      <CustomTabPanel value={value} index={1}>
      <CardContent sx={{ pt: (theme) => `${theme.spacing(3)} !important` , px: 0,  pb:'0px !important'}}>
        <Stack spacing={2} alignItems="left">
          <ToggleButtonGroup
            size="small"
            {...control}
            aria-label="Small sizes"
            sx={{ display: 'block' }}
            
          >
            {/* {children} */}
            {children.map((child, index) => (
                <ToggleButton
                  key={index}
                  value={child.props.value}
                  selected={selectedClasses.includes(child.props.value.toLowerCase())}
                  sx={child.props.sx}
                  onClick={(e) => handleChange(e, child.props.value)}
                >
                  {child.props.children}
                </ToggleButton>
              ))}
          </ToggleButtonGroup>
        </Stack>
      </CardContent>
      </CustomTabPanel>
    
    </Box>

        
        </>
     )

}

export default TimeFilter