

// ** Icon imports
// import {useState, useEffect} from 'react'

// import Login from 'mdi-material-ui/Login'
// import Table from 'mdi-material-ui/Table'

// import AccountCogOutline from 'mdi-material-ui/AccountCogOutline'
// import CreditCardOutline from 'mdi-material-ui/CreditCardOutline'
// import AccountPlusOutline from 'mdi-material-ui/AccountPlusOutline'
// import AlertCircleOutline from 'mdi-material-ui/AlertCircleOutline'
// import GoogleCirclesExtended from 'mdi-material-ui/GoogleCirclesExtended'

// import LogPath from 'src/layouts/components/LogPath'
// import Image from 'next/image';

// ** Type import

import { VerticalNavItemsType } from 'src/@core/layouts/types'

const navigation = (): VerticalNavItemsType => {
  return [
    {
      title: 'Dashboard ',
      icon:'/images/icons/iconnav.png',
      path: '/'
    },
    {
      sectionTitle: 'Services'
    },
    {
      title: 'RFQ',
      icon: '/images/icons/iconnav.png',
      path: '/account-settings'
    },
    {
      title: 'Travel',
      icon: '/images/icons/iconnav.png',
      path: '/travelsearch',
      openInNewTab: false, 
    },
    {
      title: 'Rent',
      icon: '/images/icons/iconnav.png',
      path: '/tables',
      openInNewTab: false
    },
    {
      title: 'Utility',
      icon: '/images/icons/iconnav.png',
      path: '/form-layouts',
      openInNewTab: false
    },
    {
      title: 'Courier',
      icon: '/images/icons/iconnav.png',
      path: '/pages/register',
      openInNewTab: false
    },
    {
      title: 'Catalog',
      icon: '/images/icons/iconnav.png',
      path: '/pages/register',
      openInNewTab: false
    },
    {
      title: 'Lens',
      icon: '/images/icons/iconnav.png',
      path: '/pages/register',
      openInNewTab: false
    },
    {
      sectionTitle: 'RECORDS'
    },
    {
      title: 'Inventory',
      icon: '/images/icons/iconnav.png',
      path: '/pages/error',
      openInNewTab: false
    },
   
    {
      title: 'Purchase Orders',
      icon: '/images/icons/iconnav.png',
      path: '/typography'
    },
    {
      title: 'Orders',
      icon: '/images/icons/iconnav.png',
      path: '/typography'
    },
    {
      title: 'Invoice',
      path: '/icons',
      icon: '/images/icons/iconnav.png'
    },
    {
      title: 'Reports',
      icon: '/images/icons/iconnav.png',
      path: '/cards'
    },
    {
      sectionTitle: 'ORG'
    },
    {
      title: 'User Management',
      icon: '/images/icons/iconnav.png',
      path: '/tables'
    },
    {
      title: 'Corporate setup',
      icon: '/images/icons/iconnav.png',
      path: '/tables'
    },
    {
      title: 'Policies',
      icon: '/images/icons/iconnav.png',
      path: '/tables'
    },
    {
      title: 'Clients',
      icon: '/images/icons/iconnav.png',
      path: '/tables'
    },
   
  ]
}

// const verticalNavItems = navigation({ isTravelActive: false })

export default navigation
