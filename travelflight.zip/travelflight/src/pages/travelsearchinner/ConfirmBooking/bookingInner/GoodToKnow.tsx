import { Card, CardContent, Typography, CardHeader, Avatar,  } from '@mui/material/'
import { PriorityHigh } from '@mui/icons-material'
import { useTheme } from '@mui/material/styles'

const GoodToKnow = () => {

  const theme = useTheme()

  return (
    <>
      <Card sx={{marginTop:'2rem'}}>
        <CardContent className='payNowBox'>
          <Typography variant='h6' gutterBottom>
            Good to Know
          </Typography>
          <Typography variant='subtitle2' gutterBottom>
            subtitle2. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quos blanditiis tenetur
          </Typography>
          <Typography variant='body2' gutterBottom>
            body2. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quos blanditiis tenetur unde suscipit, quam
            beatae rerum inventore consectetur, neque doloribus, cupiditate numquam dignissimos laborum fugiat deleniti?
            Eum quasi quidem quibusdam. body2. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quos blanditiis
            tenetur unde suscipit, quam beatae rerum inventore consectetur, neque doloribus, cupiditate numquam
            dignissimos laborum fugiat deleniti? Eum quasi quidem quibusdam.
          </Typography>
        </CardContent>

        <Typography>
          <CardHeader
            sx={{ mx: '1rem', background: '#FCFCFC', mb: '2rem', border: '1px solid #f0f0f0' }}
            avatar={
              <Avatar
                sx={{
                  background: theme.palette.error.dark,
                  color: '#fff',
                  position: 'relative',
                  top: '-18px',
                  width: '25px',
                  height: '25px'
                }}
                aria-label='recipe'
              >
                <PriorityHigh sx={{ fontSize: '1rem' }} />
              </Avatar>
            }
            title='Covid 19 Information'
            subheader='Please check your itinerary, including layovers, for travel restrictions prior to booking. A displayed itinerary is not confirmation of your eligibility to travel.'
          />
        </Typography>
      </Card>
    </>
  )
}

export default GoodToKnow
