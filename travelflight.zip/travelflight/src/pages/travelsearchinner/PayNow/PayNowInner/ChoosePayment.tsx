import * as React from 'react'
import {
  Box,
  Typography,
  Tab,
  Tabs,

  Card,
  CardContent,

  ListItem,
  IconButton,
  ListItemButton,
  ListItemIcon,
  Checkbox,
  ListItemText,
  
} from '@mui/material'

// import DatePicker from 'react-datepicker'

import 'react-datepicker/dist/react-datepicker.css'

// import moment from 'moment'

// import themeConfig from 'src/configs/themeConfig'

import { useTheme } from '@mui/material/styles'
import CreditCard from '../PayNowInner/CreditCard'
import WalletPayment from './WalletPayment'
import NetBanking from './NetBanking'
import UpiOptions from './UpiOptions'
import {AccountBalanceWallet}from '@mui/icons-material'
import { useRouter } from 'next/router'

interface TabPanelProps {
  children?: React.ReactNode
  index: number
  value: number
}

function TabPanel(props: TabPanelProps) {
  const { children, value, index, ...other } = props

  return (
    <div
      role='tabpanel'
      hidden={value !== index}
      id={`vertical-tabpanel-${index}`}
      aria-labelledby={`vertical-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{ p: 3 }}>
          <Typography>{children}</Typography>
        </Box>
      )}
    </div>
  )
}

function a11yProps(index: number) {
  return {
    id: `vertical-tab-${index}`,
    'aria-controls': `vertical-tabpanel-${index}`
  }
}
const VerticalTabs = () => {
  const [value, setValue] = React.useState(1)

 // const [selectedMonth, setSelectedMonth] = React.useState<moment.Moment | null>(null)

  const theme = useTheme()

  const [checked, setChecked] = React.useState([0])

  const handleToggle = (value: number) => () => {
    const currentIndex = checked.indexOf(value)
    const newChecked = [...checked]

    if (currentIndex === -1) {
      newChecked.push(value)
    } else {
      newChecked.splice(currentIndex, 1)
    }

    setChecked(newChecked)
  }

  // const handleMonthChange = (date: Date) => {
  //   setSelectedMonth(moment(date))
  // }

  const handleChange = (event: React.SyntheticEvent, newValue: number) => {
    setValue(newValue)
  }

  const router = useRouter();

  const handleSearchFlight = () => {
    router.push('/travelsearchinner/ConfirmBooking');
  };
  
  React.useEffect(() => {
    if (router.pathname === '/travelsearchinner/PayNow') { 
      const travelSearch = document.querySelector('.navList-Box [href="/travelsearch/"] span');
      travelSearch?.classList.add('active');
    }
  }, [router.pathname]);


  return (
    <>
      <Typography variant='h6' gutterBottom>
        Choose Payment Mode
      </Typography>
      <Card sx={{ marginTop: '1.5rem',boxShadow:'none',border:'1px solid #E4E6E8' }}>
        <CardContent
          sx={{
            pt: theme => `${theme.spacing(2.25)} !important`,
            '&.MuiCardContent-root': {

              // paddingTop: '0rem !important',

            }
          }}
        >
          <ListItem
            secondaryAction={
              
              <IconButton
               onClick = {handleSearchFlight}
               edge='end' sx={{border:'1px solid #E4E6E8 !important',position:'relative',top:'5px'}} >
                <AccountBalanceWallet />
              </IconButton>
             
            }
            disablePadding
            className='headBoxChoosePay' 
          >
            <ListItemButton role={undefined} onClick={handleToggle(0)} dense>
              <ListItemIcon>
                <Checkbox
                  edge='start'
                  checked={checked.indexOf(0) !== -1}
                  tabIndex={-1}
                  disableRipple
                  inputProps={{ 'aria-labelledby': 'checkbox-list-label-0' }}
                  sx={{'&.Mui-checked':{
                    color:theme.palette.secondary.main,  
                  },
                  '&.MuiCheckbox-root':{
                    position:'relative',top:'9px'
                  }
                }} 
                />
              </ListItemIcon>
              <ListItemText id='checkbox-list-label-0' 
              primary='Genie Wallet'
              secondary='Available Balance: Rs.10000' />
            </ListItemButton>
          </ListItem>
        </CardContent>
      </Card>
      <Box
        className='tabBox'
        sx={{ flexGrow: 1, bgcolor: 'background.paper', display: 'flex', minHeight: 324, marginTop: '1.5rem' }}
      >
        <Tabs
          orientation='vertical'
          variant='scrollable'
          value={value}
          onChange={handleChange}
          aria-label='Vertical tabs example'
          sx={{ borderRight: 1, borderColor: 'divider' }}
        >
          <Tab label='UPI Options' {...a11yProps(0)} />
          <Tab label='Credit/Debit/ATM/Corporate Card' {...a11yProps(1)} />
          <Tab label='Net Banking' {...a11yProps(2)} />
          <Tab label='Wallets & More' {...a11yProps(3)} />
        </Tabs>

        <TabPanel value={value} index={0}>
          <UpiOptions />
        </TabPanel>
        <TabPanel value={value} index={1}>
          <CreditCard />
        </TabPanel>
        <TabPanel value={value} index={2}>
          <NetBanking />
        </TabPanel>
        <TabPanel value={value} index={3}>
          <WalletPayment />
        </TabPanel>
      </Box>
    </>
  )
}

export default VerticalTabs
