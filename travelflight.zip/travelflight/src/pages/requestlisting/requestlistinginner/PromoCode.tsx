

import { Clear } from '@mui/icons-material';
import { Card, CardContent, Typography,  Button, Box, FormControl, InputLabel, TextField, InputAdornment, RadioGroup, FormControlLabel, Radio, Dialog, DialogContent } from "@mui/material";
import { useTheme } from '@mui/material/styles';
import { useState, useEffect} from "react";
import { useQuery } from '@apollo/client'
import { gql } from '@apollo/client'


// import CheckCircleOutlineIcon from '@mui/icons-material/CheckCircleOutline';

import CheckIcon from '@mui/icons-material/Check';
import { Close } from '@mui/icons-material' 

const PROMOCODES_QUERY = gql`
  query PromoCodes {
    promoCodes {
      code
      discount
      icon
      offer
    }
  }
`
interface PromoCode {
  code: string
  discount: string
  icon: any
  offer:number
}

interface PromoCodesData {
  promoCodes: PromoCode[]
}



const PromoCode = ({ onDataUpdate }) => {
  const [value, setValue] = useState('');
  const [openDialog, setOpenDialog] = useState(false);

  const [promoCodes, setPromoCodes] = useState<PromoCodesData["promoCodes"]>([]);

  const [appliedPromoCode, setAppliedPromoCode] = useState<string | null>(null);

  // const [selectedPromoOffer, setSelectedPromoOffer] = useState<number | null>(null);

  

  const { loading,  data } = useQuery<PromoCodesData>(PROMOCODES_QUERY);
  useEffect(() =>{
    if(!loading && data){
      setPromoCodes(data.promoCodes)
    }
  }, [loading, data])

 
  

  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setValue(event.target.value); 
   
    console.log(event.target.value);
  };

  const handleOpenDialog = () => {
    setOpenDialog(true);
  };

  const handleCloseDialog = () => {
    setOpenDialog(false);
  };

  const handleClear = () => {
    setValue('');
    setAppliedPromoCode(null);
    onDataUpdate(null);
  };

  const theme = useTheme();

  return (
    <>
     
      <Box sx={{ mt: 5 }}>
        <Card>
          <CardContent sx={{
            pt: theme => `${theme.spacing(2.25)} !important`, '&.MuiCardContent-root': {
              paddingTop: '1rem !important'
            }
          }}>
            <FormControl fullWidth>
              <InputLabel
                htmlFor='from-input'
                sx={{
                  transform: 'none',
                  position: 'static',
                  fontWeight: 600,
                  '&.Mui-focused': {
                    color: 'inherit'
                  },
                  marginBottom: '5px',
                  color: theme.palette.common.black
                }}
                disableAnimation
              >
                
                Promo Code
              </InputLabel>
              <TextField
                sx={{
                  '& .MuiOutlinedInput-input': {
                    padding: '14.50px 14px'
                  },
                  '& .MuiOutlinedInput-notchedOutline': {
                    borderColor: 'rgba(58, 53, 65, 0.32)',
                    borderWidth: '1px',
                    boxShadow: 'none'
                  },
                  '&:hover .MuiOutlinedInput-notchedOutline': {
                    borderColor: 'rgba(58, 53, 65, 0.32)',
                    borderWidth: '1px'
                  },
                  '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                    borderColor: 'rgba(58, 53, 65, 0.32) !important',
                    borderWidth: '1px'
                  }
                }}
                InputProps={{
                  endAdornment: (
                    <InputAdornment position="end">
                      {value && (
                        <Button
                          variant="text"
                          onClick={handleClear}
                          sx={{
                            color: theme.palette.text.secondary,
                            '&:hover': {
                              color: theme.palette.text.primary
                            }
                          }}
                        >
                          <Clear/>
                        </Button>
                        
                      )}

                      <Button variant='contained'
                        sx={{
                         backgroundColor: theme.palette.common.black,
                         right: '-1rem',
                         zIndex:'1',
                         lineHeight: '2.71',
                         textTransform:'capitalize',
                         '&:hover':{
                          background:theme.palette.common.black,
                         }
                        }} 
                       
                        >
                        {/* Apply */}
                        {appliedPromoCode ? (
                           <>
                          Applied
                          <CheckIcon
                          sx={{ marginLeft: '0.5rem', color: theme.palette.common.white }}
                          />
                           </>
                            ) : (
                          'Apply'
                           )}
                      </Button>
                    </InputAdornment>
                  ),
                }}
                value={value}
              />
            </FormControl>
          </CardContent>
        </Card>
      </Box>
      <Box>
        <FormControl fullWidth>
          <RadioGroup
            aria-labelledby="demo-controlled-radio-buttons-group"
            name="controlled-radio-buttons-group"
            value={value}
            onChange={handleChange}
          >
            {promoCodes.map((promoCode) => {
              
              return ( 
                 <>
                  <Box  key={promoCode.code} sx={{ mt: 5,cursor:'pointer' }} >
                <Card variant="outlined"  
                onClick={() => {
                  setValue(promoCode.code);
                  setAppliedPromoCode(promoCode.code); // Update applied promo code

                  // setSelectedPromoOffer(promoCode.offer)

                  // onDataUpdate(selectedPromoOffer);

                  onDataUpdate(promoCode.offer);
                  
                }} 
                >
                  <CardContent sx={{
                    pt: theme => `${theme.spacing(2.25)} !important`, '&.MuiCardContent-root': {
                      paddingTop: '1rem !important'
                    }
                  }}>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                      <FormControlLabel 
                      sx={{'& .MuiFormControlLabel-label':{
                        color:theme.palette.common.black,
                        fontWeight:'600',
                        fontSize:'1rem'
                      }
                    }} 
                      value={promoCode.code} 
                      control={<Radio sx={{'&.Mui-checked':{
                        color:theme.palette.secondary.main
                      }
                    }}/>}
                      label={promoCode.code}  />

                      {/* {promoCode.icon} */}

                    </Box>
                    <Typography variant="body2" gutterBottom sx={{ marginLeft: '2rem' }}>
                      {promoCode.discount}
                      
                      
                    </Typography>
                    <Box sx={{ display: 'flex', justifyContent: 'flex-end' }}>
                      <Button variant="text" onClick={handleOpenDialog} sx={{ marginLeft: 'auto',textTransform:'capitalize' }}>
                        Terms & Conditions
                      </Button>
                    </Box>
                  </CardContent>
                </Card>
              </Box>
                  
                
              </>
               )
              })}  
          </RadioGroup>
        </FormControl>
      </Box>
      <Dialog open={openDialog} onClose={handleCloseDialog}
        PaperProps={{ sx: { maxWidth:{xs:'42vw',sm:'58vw',md:'36vw'},overflow:'visible' } }}
      >
        <DialogContent>

          {/* Dialog content goes here */}

          <Typography variant="h6" gutterBottom>
          Terms & Conditions
      </Typography>
      <Close 
    onClick={handleCloseDialog}
              sx={{
                '&.MuiSvgIcon-root':{
                  background:theme.palette.common.white,
                  width:'2.5rem', height:'2.5rem', position:'absolute',
                  borderRadius:'100%',
                  top:'-1rem',
                  right:'-1rem',
                  padding:'10px',
                  cursor:'pointer'

                }
              }}
            />
          <ul style={{fontSize:'12px', paddingLeft:'1rem'}}>
      <li>
        In case of full/partial cancellation Genie’s offer stands void and the
        customer will not be eligible for the discount. Geniebazaar will refund
        the amount after adjusting the discount and any other applicable charges
        and penalties.
      </li>
      <li>
        Any change in the booking will involve a change fee and difference of
        fare, which would be borne by the passenger.
      </li>
      <li>
        The offer is not applicable on infant and group bookings.
      </li>
      <li>
        This offer cannot be clubbed with any other promotion on{' '}
        <a href="https://www.geniebazaar.com">www.geniebazaar.com</a>.
      </li>
      <li>
        Geniebazaar Online Limited reserves the right without prior notice to
        add, alter, modify, all or any of these terms and conditions.
      </li>
      <li>
        The offer may be replaced wholly or in part, by any other offer,
        whether similar or not, and can be withdrawn altogether.
      </li>
      <li>
        Any disputes arising out of this offer shall be subject to the exclusive
        jurisdiction of competent courts in Gurgaon, Haryana.
      </li>
      <li>
        All other standard terms and conditions of geniebazaar.com shall apply.
      </li>
    </ul>
        </DialogContent>

        {/* <DialogActions>
          <Button onClick={handleCloseDialog}>Close</Button>
        </DialogActions> */}

      </Dialog>
    </>
  );
};

export default PromoCode;

