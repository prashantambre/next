import React, { useEffect } from 'react'

// import { Accordion, AccordionDetails, AccordionSummary, Card, Divider, Grid, Typography,Button,Box } from "@mui/material";

import { Card,  Grid, Typography, Box } from '@mui/material'

import { useState } from 'react'

import TotalFare from './requestlistinginner/TotalFare'

// import PromoCode from "./flightListingInner/PromoCode";

import TripDetails from './requestlistinginner/TripDetails'

import { useTheme } from '@mui/material/styles'

const FlightListing = () => {
 
  const [dataFromChild, setDataFromChild] = useState('')
  const handleDataFromChild = data => {
    setDataFromChild(data)
  }

  const travelerNames = ['Oliver James', 'John Doe', 'Alice Smith', 'Bob Johnson', 'Bob Johnsons']

  const mealsBeverage = ['Kosher food', 'Tableware', 'Burger', 'Pizza', 'Sandwitch', 'Vada Pav']
  
  const baggage = ['10kg', '20kg', '15kg', '18kg', '23kg', '21kg']

  const theme = useTheme()

  return (
    <>
      <Grid container spacing={6}>
        <Grid item sm={8} xs={12}>
          <Card>
            <Box sx={{ padding: '1rem 1.5rem 0.5rem 1.5rem' }}>
              <Typography variant='h6' component='h1' gutterBottom>
                Flight details
              </Typography>
              <Typography variant='subtitle2' gutterBottom>
                {dataFromChild}
              </Typography>
              <TripDetails onDataUpdate={handleDataFromChild} />
            </Box>
          </Card>
          <Card sx={{ mt: 4 }}>
            <Box sx={{ padding: '1rem 1.5rem 0.5rem 1.5rem' }}>
              <Typography variant='h6' component='h1' gutterBottom>
                Traveler details
              </Typography>

              <Typography variant='subtitle2' gutterBottom>
                {travelerNames.length > 0 ? (
                  <>
                    {travelerNames.slice(0, 2).map((name, index) => (
                      <React.Fragment key={index}>
                        {name}
                        {index < 1 && ', '}
                      </React.Fragment>
                    ))}
                    {/* {travelerNames.length > 2 && `, +${travelerNames.length - 2} more`} */}
                    {travelerNames.length > 2 && (
                      <span style={{ color: theme.palette.primary.light }}>, +{travelerNames.length - 2} more</span>
                    )}
                  </>
                ) : (
                  'No travelers'
                )}
              </Typography>
            </Box>
          </Card>

          <Card sx={{ mt: 4 }}>
            <Box sx={{ padding: '1rem 1.5rem 0.5rem 1.5rem' }}>
              <Typography variant='h6' component='h1' gutterBottom>
                Meals-beverage (optional)
              </Typography>

              <Typography variant='subtitle2' gutterBottom>
                 Departure:
              </Typography>

              <Typography variant='subtitle2' gutterBottom>

                {mealsBeverage.length > 0 ? (
                  <>
                    {mealsBeverage.slice(0, 2).map((name, index) => (
                      <React.Fragment key={index}>
                        {name}
                        {index < 1 && ', '}
                      </React.Fragment>
                    ))}
                    {/* {travelerNames.length > 2 && `, +${travelerNames.length - 2} more`} */}
                    {mealsBeverage.length > 2 && (
                      <span style={{ color: theme.palette.primary.light }}>, +{mealsBeverage.length - 2} more</span>
                    )}
                  </>
                ) : (
                  'No travelers'
                )}
              </Typography>
            </Box>
          </Card>

          <Card sx={{ mt: 4 }}>
            <Box sx={{ padding: '1rem 1.5rem 0.5rem 1.5rem' }}>
              <Typography variant='h6' component='h1' gutterBottom>
                Select baggage (Optional)
              </Typography>

              <Typography variant='subtitle2' gutterBottom>
                 Departure:
              </Typography>

              <Typography variant='subtitle2' gutterBottom>

                {baggage.length > 0 ? (
                  <>
                    {baggage.slice(0, 2).map((name, index) => (
                      <React.Fragment key={index}>
                        {name}
                        {index < 1 && ', '}
                      </React.Fragment>
                    ))}
                    {/* {travelerNames.length > 2 && `, +${travelerNames.length - 2} more`} */}
                    {baggage.length > 2 && (
                      <span style={{ color: theme.palette.primary.light }}>, +{baggage.length - 2} more</span>
                    )}
                  </>
                ) : (
                  'No travelers'
                )}
              </Typography>
            </Box>
          </Card>
        </Grid>
        <Grid item sm={4} xs={12}>
          <TotalFare />
        </Grid>
      </Grid>
    </>
  )
}
export default FlightListing
