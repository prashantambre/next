// import * as React from 'react';
// import { Button, Slider, Typography, Box } from '@mui/material';
// import { useState, useEffect } from 'react';
// import { useQuery, gql } from '@apollo/client';

// const DURATION_QUERY = gql`
//   query Durations {
//     durations {
//       type
//       max
//       marks {
//         value
//         label
//       }
//     }
//   }
// `;

// interface MarksData {
//   value: number;
//   label: string;
// }

// interface Duration {
//   type: string;
//   max: number;
//   marks: MarksData[];
// }

// interface DurationData {
//   durations: Duration;
// }
// interface FlightDurationProps {
//   onDurationSelectedChange: (selectedValue: number) => void;
// }

// const FlightDuration =  ({ onDurationSelectedChange }: FlightDurationProps) => {  
//   const [durationsss, setDurationTypes] = useState<DurationData["durations"] | null>(null);
//   const [defaultValue, setDefaultValue] = useState(20);
//   const [selectedDurationValue, setSelectedDurationValue] = useState<number>(defaultValue);

//   const { loading, error, data } = useQuery<DurationData>(DURATION_QUERY);   
//   // useEffect(() => {
//   //   if (data?.durations) { 
//   //     setDurationTypes(data.durations);
//   //   }  
//   // }, [data]); 
//   useEffect(() => {
//     if (data?.durations) { 
//       setDurationTypes(data.durations);
//       setSelectedDurationValue(defaultValue); // Set the initial selected value to the default value
//     }  
//   }, [data, defaultValue]); // Include 'defaultValue' in the dependencies array



//   // const handleClearClick = () => {
//   //   setDefaultValue(40);
//   // };
//   const handleClearClick = () => {
//     setDefaultValue(40);
//     setSelectedDurationValue(40); // Update the selected value when clearing
//     onDurationSelectedChange(40); 
//   };

//   const handleSliderChange = (event: Event, newValue: number | number[]) => {
//     setSelectedDurationValue(newValue as number); // Update the selected value when the slider changes
//     onDurationSelectedChange(newValue as number);
//   };

//   const formatValue = (value: number) => `${value} hr`;
//   if (loading) {
//     return <p>Loading...</p>;
//   }
//   if (error) {
//     return <p>Error: {error.message}</p>;
//   }
//   return (
//     <>
//       <Box sx={{ display: 'flex', flexDirection: 'column' }} className="filterBox">
//         <Button variant="text" className="clearButton" onClick={handleClearClick}>
//           Clear 
//         </Button> 
//         {durationsss && (
//           <>
//             <Typography component="h2" mt={4} mb={7}>
//                {durationsss.type}  
//             </Typography>
//             <Slider
//               // value={defaultValue}
//               value={selectedDurationValue} // Use the selectedDurationValue as the value for the Slider
//               onChange={handleSliderChange} // Handle the slider change to update the selected value
//               sx={{ width: '95%', color: '#F0971A !important' }}
//               // onChange={(event, newValue) => setDefaultValue(newValue as number)}
//               aria-label="Custom marks"
//               valueLabelDisplay="on"
//               valueLabelFormat={formatValue}
//               max={durationsss.max}
//               marks={durationsss.marks}
//               step={1}
//             />
//           </>
//           )} 
//       </Box>
//     </>
//   );
// }; 
// export default FlightDuration;



import * as React from 'react';
import { Button, Slider, Typography, Box } from '@mui/material';
import { useState, useEffect } from 'react';
import { useQuery, gql } from '@apollo/client';

const DURATION_QUERY = gql`
  query Durations {
    durations {
      type
      max
      marks {
        value
        label
      }
    }
  }
`;

interface MarksData {
  value: number;
  label: string;
}

interface Duration {
  type: string;
  max: number;
  marks: MarksData[];
}

interface DurationData {
  durations: Duration;
}
interface FlightDurationProps {
  onDurationClear: (event) => void;
  onDurationSelectedChange: (selectedValue: number) => void;
}

const FlightDuration = ({ onDurationClear, onDurationSelectedChange }: FlightDurationProps) => {
  const [durationsss, setDurationTypes] = useState<DurationData["durations"] | null>(null);
  const [defaultValue, setDefaultValue] = useState(20);
  const [selectedDurationValue, setSelectedDurationValue] = useState<number>(defaultValue);

  const { loading, error, data } = useQuery<DurationData>(DURATION_QUERY);

  useEffect(() => {
    if (data?.durations) {
      setDurationTypes(data.durations);
      setSelectedDurationValue(defaultValue);
    }
  }, [data, defaultValue]);

  // Load selected duration from localStorage on component mount
  useEffect(() => {
    const storedSelectedDuration = localStorage.getItem('selectedDuration');
    if (storedSelectedDuration) {
      const parsedDuration = JSON.parse(storedSelectedDuration);
      setSelectedDurationValue(parsedDuration);
    }
  }, []);

  // Save selected duration to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem('selectedDuration', JSON.stringify(selectedDurationValue));
  }, [selectedDurationValue]);

  const handleClearClick = () => {
    setDefaultValue(20);
    setSelectedDurationValue(20);
    onDurationSelectedChange(20);
    onDurationClear(event);
  };

  const handleSliderChange = (event: Event, newValue: number | number[]) => {
    setSelectedDurationValue(newValue as number);
    onDurationSelectedChange(newValue as number);
  };

  const formatValue = (value: number) => `${value} hr`;

  if (loading) {
    return <p>Loading...</p>;
  }

  if (error) {
    return <p>Error: {error.message}</p>;
  }

  return (
    <>
      <Box sx={{ display: 'flex', flexDirection: 'column' }} className="filterBox">
        <Button variant="text" className="clearButton" onClick={handleClearClick}>
          Clear
        </Button>
        {durationsss && (
          <>
            <Typography component="h2" mt={4} mb={7}>
              {durationsss.type}
            </Typography>
            <Slider
              value={selectedDurationValue}
              onChange={handleSliderChange}
              sx={{ width: '95%', color: '#F0971A !important' }}
              aria-label="Custom marks"
              valueLabelDisplay="on"
              valueLabelFormat={formatValue}
              max={durationsss.max}
              marks={durationsss.marks}
              step={1}
            />
          </>
        )}
      </Box>
    </>
  );
};

export default FlightDuration;
