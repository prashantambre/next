import { Box, FormControlLabel, Checkbox, Button, IconButton } from "@mui/material";
import { useState, useEffect } from "react";
import { useQuery, gql } from "@apollo/client";
import Tooltip from "@mui/material/Tooltip";

// import { Delete } from "@mui/icons-material";




const AIRLINES_QUERY = gql`
  query AirlineNames {
    airlineNames {
      name
    }
  }
`;

interface AirlineName {
  name: string;
  checked: boolean;
}

interface AirlineData {
  airlineNames: AirlineName[];
}


interface AirlineFilterProps {
  onAirlineClear: (event) => void; // Add the prop for clearing airlines
  onAirlineSelectedChange: (selectedValue: string[]) => void; // Function to send the selected stops value to the parent component
  // selectedStops: string[]; // Add the selectedStops prop

}

const AirlinesFilter =  ( {onAirlineClear, onAirlineSelectedChange}: AirlineFilterProps)  => {
  const [airlineNames, setAirlineNames] = useState<AirlineData["airlineNames"]>([]);
  const [airlineSelectedValue, setAirlineSelectedValue] = useState<string[]>([]); // State to store selected stop values
  const { loading, error, data } = useQuery<AirlineData>(AIRLINES_QUERY);

  useEffect(() => {
    // alert('hello   '+JSON.stringify(airlineSelectedValue));
    if (!loading && data) {
      const airlineNamesWithChecked = data.airlineNames.map((airline) => ({
        ...airline,
        checked: airlineSelectedValue.indexOf(airline.name) > -1,

        //checked: airlineSelectedValue.includes(airline.name),

      }));

      // alert('hello   '+JSON.stringify(airlineNamesWithChecked));
      
      setAirlineNames(airlineNamesWithChecked);

      // alert('hello   '+JSON.stringify(airlineSelectedValue));

    }
  }, [data,airlineSelectedValue]);


  useEffect(() => {
    const storedSelectedAirlines = localStorage.getItem('selectedAirlines');
    if (storedSelectedAirlines) {
      const parsedAirlines = JSON.parse(storedSelectedAirlines);
      setAirlineSelectedValue(parsedAirlines);
      
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('selectedAirlines', JSON.stringify(airlineSelectedValue));
  }, [airlineSelectedValue]);

  const handleToggleAirline = (index: number) => {
   
    // const updatedAirlines = [...airlineNames];
    // updatedAirlines[index].checked = !updatedAirlines[index].checked;
    // setAirlineNames(updatedAirlines);

    const updatedAirlines = [...airlineNames];
    updatedAirlines[index].checked = !updatedAirlines[index].checked;

    // const airlineSelect =  updatedAirlines.map((airline,index) => ({
     
    // }));

    // alert(JSON.stringify(updatedAirlines));
     
    setAirlineNames(updatedAirlines);

    // alert(JSON.stringify(airlineNames));

    const selectedAirlines = updatedAirlines
      .filter((airline) => airline.checked)
      .map((airline) => airline.name);
    setAirlineSelectedValue(selectedAirlines);

    // alert(JSON.stringify(selectedAirlines));

    onAirlineSelectedChange(selectedAirlines); 


  };



  // const handleDeslectAll = (index: number) => {
  //   const updatedAirlines = airlineNames.map((airline, i) => ({
  //     ...airline,
  //     checked: i === index ? !airline.checked : false,
  //   }));
  //   setAirlineNames(updatedAirlines);
  // };

  const handleDeslectAll = (index: number) => {
    const updatedAirlines = airlineNames.map((airline, i) => ({
      ...airline,
      checked: i === index,
    }));
    setAirlineNames(updatedAirlines);
    const selectedAirlines = updatedAirlines
    .filter((airline) => airline.checked)
    .map((airline) => airline.name);
  setAirlineSelectedValue(selectedAirlines);
  onAirlineSelectedChange(selectedAirlines);
  };

  const handleClearAll = () => { 
    const updatedAirlines = airlineNames.map((airline) => ({
      ...airline,
      checked: false,
    }));
    setAirlineNames(updatedAirlines);
    setAirlineSelectedValue([]);
    onAirlineClear(event); 
  };

  // const handleSelectAll = () => {
  //   const updatedAirlines = airlineNames.map((airline) => ({
  //     ...airline,
  //     checked: true,
  //   }));
  //   setAirlineNames(updatedAirlines);
  // };

  // const handleSelectAll = () => {
  //   const allChecked = airlineNames.every((airline) => airline.checked);
  //   const updatedAirlines = airlineNames.map((airline) => ({
  //     ...airline,
  //     checked: !allChecked,
  //   }));
  //   setAirlineNames(updatedAirlines); 
  // };


  const handleSelectAll = () => {
    const allChecked = airlineNames.every((airline) => airline.checked);
    const updatedAirlines = airlineNames.map((airline) => ({
      ...airline,
      checked: !allChecked,
    }));
    setAirlineNames(updatedAirlines);
    const selectedAirlines = updatedAirlines
      .filter((airline) => airline.checked)
      .map((airline) => airline.name);
    setAirlineSelectedValue(selectedAirlines);
    onAirlineSelectedChange(selectedAirlines);
  };


  if (loading) return <p>Loading...</p>;
  if (error || !data) return <p>Error :</p>;

  return (
    <>
      <Box sx={{ display: "flex", flexDirection: "column" }} className="filterBox">
      <Button variant="text" onClick={handleClearAll} className="clearButton">
          Clear 
        </Button>
        {/* <Button variant="outlined" onClick={handleSelectAll}>
          Select All
        </Button> */}
        <FormControlLabel
          control={
            <Checkbox
              checked={airlineNames.every((airline) => airline.checked)}
              
              indeterminate={
                airlineNames.some((airline) => airline.checked) &&
                !airlineNames.every((airline) => airline.checked)
              }
              onChange={handleSelectAll}
            />
          }
          label={airlineNames.every((airline) => airline.checked) ? "All Airlines" : "All Airlines"}
          sx={{'& .Mui-checked':{
            color:'#F0971A !important'
           },
           textTransform:'capitalize',
           '& .MuiCheckbox-indeterminate':{
            color:'#F0971A !important'
           }

         }}
        />
      
        {airlineNames.map((airline, index) => (
          <Tooltip
            key={airline.name}

            // title=""

            title={
              airline.checked ? (
                <IconButton 
                  onClick={() => { 
                    handleDeslectAll(index);
                  }}
                >
                  Only
                </IconButton>
              ) : (
                ""
              )
            }
            placement="right"  
           classes={{ tooltip: "tooltipBox" }}
          >
            <FormControlLabel
              control={
                <Checkbox
                   checked={airline.checked}

                  //checked={airlineSelectedValue.includes(airline.name)}

                  onChange={() => handleToggleAirline(index)}
                  
                />
              }
              label={airline.name}
              onClick={(e) => e.stopPropagation()}
              sx={{'& .Mui-checked':{
                color:'#F0971A !important'
               },
              
             }}
            />
          </Tooltip>
        ))}
      
      </Box>
    </>
  );
};

export default AirlinesFilter;
