

import React, { useEffect, useState } from 'react'
import {
  Avatar,
  Grid,

  Typography,
  Card,
 
  Button,

  useTheme,

  Box,
  
} from '@mui/material'
import { CurrencyRupee, ArrowUpward, ArrowDownward,Flight,Hotel  } from '@mui/icons-material' 

import { useQuery } from '@apollo/client'
import { gql } from '@apollo/client'
import { useRouter } from 'next/router'

import {  MenuItem, Menu, } from '@mui/material';


const PENDINGREQUEST_QUERY = gql`
  query PendingRequest {
    pendingRequest {
      tripId
      travelerDetails
      date
      dastination 
      tripPurpose
      tripPurposeDescription 
      amount
    }
  }
`

// const OwlCarousel = ReactOwlCarousel;

interface pendingRequest {
  tripId:string
  travelerDetails:string
  date:string
  dastination:string
  tripPurpose:string
  tripPurposeDescription:string
  amount:number
}

interface PendingRequestData {
  pendingRequest: pendingRequest[]
}


// interface FlightDetailsItem {
//   arrivalPlace: string;
//   // ... other properties
// }

const Approved = () => {
    const [pendingRequest, setPendingRequest] = useState<PendingRequestData["pendingRequest"]>([]);
    
  const theme = useTheme()
  const black = theme.palette.common.black

  // const [expandedItem, setExpandedItem] = useState<number | null>(null); // Track the expanded item index

  const [anchorEl, setAnchorEl] = useState<Element | null>(null)

  // const [openModal, setOpenModal] = useState(false);

  // const [currentModalIndex, setCurrentModalIndex] = useState<number | null>(null);

  // const [childData, setChildData] = useState('');


  // const handleAccordionChange = (index: number) => {
  //   setExpandedItem(prevExpandedItem => (prevExpandedItem === index ? null : index));
  // };

const { loading, data } = useQuery<PendingRequestData>(PENDINGREQUEST_QUERY);
useEffect(() =>{
  if(!loading && data){
    console.log(data)
    setPendingRequest(data.pendingRequest)
  }
}, [loading, data])


const router = useRouter();


// const handleSearchFlight = () => {
//   router.push('/travelsearchinner/flightlisting');
// };

React.useEffect(() => {
  if (router.pathname === '/travelsearchinner') { 
    const travelSearch = document.querySelector('.navList-Box [href="/travelsearch/"] span');
    travelSearch?.classList.add('active');
  }
}, [router.pathname]);



// const handleSortChange = (event: React.ChangeEvent<{ value: unknown }>) => {
//     const selectedOption = event.target.value as string;
//     // setSortOption(selectedOption);
//     // sortFlightResults(selectedOption);
//   };
  
  const handleDropdownClose = (url?: string) => {
    if (url) {
      router.push(url)
    }
    setAnchorEl(null)
  }
  
  
  const handleDropdownOpen = (event) => {
    setAnchorEl(event.currentTarget)
  }
  
  const styles = {
    py: 2,
    px: 4,
    width: '100%',
    display: 'flex',
    alignItems: 'center',
    color: 'text.primary',
    textDecoration: 'none',
    '& svg': {
      fontSize: '1.375rem',
      color: 'text.secondary'
    }
  }
  
    return (
        <>
         
         <Grid container spacing={2} alignItems='center' sx={{ justifyContent: 'flex-end', marginTop:'1rem' }}>
          <Grid item>
          <Box onClick={handleDropdownOpen}> 
<Typography component={'h3'} sx={{ fontWeight: '600',cursor:'pointer' }}>
                 Sort by: <ArrowUpward sx={{ '&.MuiSvgIcon-root':{
                    position:'relative',
                    left:'-5px',
                    top:'0px',
                    fontSize:'16px'  ,
                    
                  }
                  }}/> 
                  <ArrowDownward  sx={{
                  '&.MuiSvgIcon-root':{
                    position:'relative',
                    left:'-11px',
                    top:'9px',
                    fontSize:'16px'  
                  }
                 }}/>
              </Typography>     
        </Box>

      <Menu
        anchorEl={anchorEl}
        open={Boolean(anchorEl)}
        onClose={() => handleDropdownClose()}
        sx={{ '& .MuiMenu-paper': { width: 130, marginTop: 4 } }}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
        transformOrigin={{ vertical: 'top', horizontal: 'right' }}
      >
        <MenuItem sx={{ p: 0 }} onClick={() => handleDropdownClose()}>
          <Box sx={styles}> 
            Today
          </Box>
        </MenuItem> 
        <MenuItem sx={{ p: 0 }} onClick={() => handleDropdownClose()}>
          <Box sx={styles}> 
            Yesterday
          </Box>
        </MenuItem> 
        <MenuItem sx={{ p: 0 }} onClick={() => handleDropdownClose()}>
         <Box sx={styles}> 
            This Week
         </Box>
        </MenuItem>
        <MenuItem sx={{ py: 2 }} onClick={() => handleDropdownClose()}>
          Last Week
        </MenuItem>
        <MenuItem sx={{ py: 2 }} onClick={() => handleDropdownClose()}> 
          This Month
        </MenuItem>
        <MenuItem sx={{ py: 2 }} onClick={() => handleDropdownClose()}> 
          Last Month
        </MenuItem>
        <MenuItem sx={{ p: 0 }} onClick={() => handleDropdownClose()}>
          <Box sx={styles}> 
            This Year
          </Box>
        </MenuItem>
        <MenuItem sx={{ p: 0 }} onClick={() => handleDropdownClose()}>
          <Box sx={styles}> 
            Last Year
          </Box>
        </MenuItem>
        <MenuItem sx={{ p: 0 }} onClick={() => handleDropdownClose()}>
          <Box sx={styles}>
            All Time
          </Box>
        </MenuItem>
      </Menu>

          </Grid>
  </Grid>
     {pendingRequest?.map((item, index) => { 
      return(

        <React.Fragment key={index}>
       
       <Card className='dataResultBox'  sx={{
           background:theme.palette.common.white, 
           border:'none',
           marginBottom:'1rem'
       }}>
       <Grid container spacing={2} alignItems='baseline' sx={{ justifyContent: 'space-between' }}>
         <Grid item sx={{ display: 'flex', justifyContent: 'center', flexDirection: 'column' }}>
         <Typography variant="body2" gutterBottom>
             Trip ID
          </Typography>
           <Typography
             variant='subtitle1'
             display='block'
             gutterBottom
             sx={{ textTransform: 'capitalize', color: black }}
           >
            {item.tripId}
            {/* {item.name} */}
           </Typography>
         </Grid>

         <Grid item sx={{ display: 'flex', justifyContent: 'center', flexDirection: 'column', width:'10rem' }}>
         <Typography variant="body2" gutterBottom>
             Traveler Details  
          </Typography>
           <Typography
             variant='subtitle1'
             display='block'
             gutterBottom
             sx={{ textTransform: 'capitalize', color: black }}
           >
             {item.travelerDetails}
            {/* {item.name} */}
           </Typography>
           <Typography variant="subtitle2" sx={{ textTransform: 'capitalize', color: black }} gutterBottom>
             1+ more
           </Typography>
         </Grid>
         <Grid item sx={{ display: 'flex', justifyContent: 'center', flexDirection: 'column', width:'15rem' }}>
         <Typography variant="body2" gutterBottom>
             Date - Destination
          </Typography>
           <Typography
             variant='subtitle1'
             display='block'
             gutterBottom
             sx={{ textTransform: 'capitalize', color: black }}
           >
             {item.date}
            {/* {item.name} */}
           </Typography>
           <Typography variant="subtitle2" sx={{ textTransform: 'capitalize', color: black }} gutterBottom>
            {item.dastination}
           </Typography>
           <Box sx={{display:'flex'}}>
           <Avatar sx={{ background: '#F5F7FA',marginRight:'1rem' }}><Flight sx={{ color: '#687591' }} /></Avatar>
           <Avatar sx={{ background: '#F5F7FA' }}><Hotel sx={{ color: '#687591' }} /></Avatar>
           </Box>
         </Grid>

         <Grid item sx={{ display: 'flex', justifyContent: 'center', flexDirection: 'column', width:'12rem' }}>
         <Typography variant="body2" gutterBottom>
             Trip Purpose
          </Typography>
           <Typography
             variant='subtitle1'
             display='block'
             gutterBottom
             sx={{ textTransform: 'capitalize', color: black }}
           >
            {item.tripPurpose}
            {/* {item.name} */}
           </Typography>
           <Typography variant="subtitle2" sx={{ textTransform: 'capitalize', color: black }} gutterBottom>
            {item.tripPurposeDescription}
           </Typography>
         </Grid>
         
        
         <Grid item sx={{ display: 'flex', justifyContent: 'center', flexDirection: 'column' }}>
         <Typography variant="body2" gutterBottom>
             Amount
          </Typography>
           <Typography
             variant='subtitle1'
             display='block'
             gutterBottom
             sx={{ textTransform: 'capitalize', color: black }}
           >
               <CurrencyRupee sx={{ fontSize: '12px' }} /> {item.amount}
            {/* {item.name} */}
           </Typography>
          
         </Grid>
        
         <Grid item sx={{ display: 'flex', justifyContent: 'center', flexDirection: 'column' }}>
         <Typography variant="body2" gutterBottom>
             In-Policy
          </Typography>
           <Typography
             variant='subtitle1'
             display='block'
             gutterBottom
             sx={{ textTransform: 'capitalize', color: black }}
           >
               No
            {/* {item.name} */}
           </Typography>
           <Typography variant="subtitle2" sx={{ textTransform: 'capitalize', color:'red' }} gutterBottom>
             *View details for <br/>
             further info
           </Typography>
          
         </Grid>
         <Grid sx={{position:'relative', top:'3rem'}}>
          
           <Box sx={{ display: 'block' }}>
             <Button sx={{ display: 'block', 
             minWidth:'100%', 
             textTransform:'capitalize', 
             background:'none',
             color: theme.palette.common.black,
             borderColor:'transparent',
             boxShadow: '4px 4px 15px -12px rgb(58 53 65)'
             }} 
             onClick = {()=> router.push('/requestlisting') }
             variant="outlined">View Booking</Button>
           </Box>
         </Grid>
        
       </Grid>
     </Card>
   
     </React.Fragment>
     );
    })}
        </>


    )
}

export default Approved

