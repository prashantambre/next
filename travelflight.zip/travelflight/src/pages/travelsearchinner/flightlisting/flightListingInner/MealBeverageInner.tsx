import React, {  useState, useEffect } from 'react'
import { 
  Grid,
  Typography,
  Divider,
  Button, 
  useTheme,
  Box,
  FormGroup,
  FormControlLabel,
  Checkbox,
  Popover,
  Stack,
  Paper
} from '@mui/material'
import { CurrencyRupee,ArrowBackIos,ArrowForwardIos,Circle  } from '@mui/icons-material' 

import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import Slider from 'react-slick';
import Image from 'next/image';
import { styled } from '@mui/material/styles';
import { useQuery } from '@apollo/client'
import { gql } from '@apollo/client'
import Chip from '@mui/material/Chip';


interface Item {
  type: 'non-veg' | 'veg';
  name: string;
  price: number;
}

interface SelectItem {
  seatId: string;
  name: string;
  price: number;
}

 const Item = styled(Paper)(({ theme }) => ({
    backgroundColor: theme.palette.mode === 'dark' ? '#1A2027' : '#fff',
    ...theme.typography.body2,
    padding: theme.spacing(0),
    textAlign: 'center',
    color: theme.palette.text.secondary,
    boxShadow:'none',
   
  }));



const MEALBEVERAGE_QUERY = gql`
query MealBeverage {
    mealBeverage {
     id
     type
     name
     price
  }
}
`


interface MealBeverage {
  id:number
  type:string
  name:string
  price:number
}

interface MealBeverageData {
  mealBeverage: MealBeverage[]
}


// const updateStoredSelectedMeals = (selectedMeals) => {
//   localStorage.setItem('selectedMeals', JSON.stringify(selectedMeals));
// };




const MealBeverageInner = ({onDataUpdateMeal}) => {
  const [isVegChecked, setIsVegChecked] = useState(false);

  const [isNonVegChecked, setIsNonVegChecked] = useState(false);

  const [anchorEl, setAnchorEl] = useState<HTMLElement | null>(null);

  // const [mealBeverage, setmealBeverage] = useState<Item | null>(null);

  const [mealBeverage, setmealBeverage] = React.useState<MealBeverageData["mealBeverage"]>([]);

  const [mealBeverageIndex, setmealBeverageIndex] = useState<number>(-1)

  const [mealBeverageIndexId, setmealBeverageIndexId] = useState<number>(-1)

  const [isActiveClass, setIsActiveClass] = useState<number[]>([]);

  const [isAnyCheckboxChecked, setIsAnyCheckboxChecked] = useState<boolean>(false);

  const [previouslySelectedIndexes, setPreviouslySelectedIndexes] = useState<number[]>([]);

  const [selectedMeal, setSelectedMeal] = useState<string[]>([]);


  const { loading, data } = useQuery<MealBeverageData>(MEALBEVERAGE_QUERY);
//   React.useEffect(() =>{

//     const storedSelectedMeals = localStorage.getItem('selectedMeals');
//     if (storedSelectedMeals) {
//       setSelectedMeal(JSON.parse(storedSelectedMeals));
//     }

    
//     if(!loading && data){
//       setmealBeverage(data.mealBeverage) 

//       console.log(selectedMeal)

//     }

//     updateStoredSelectedMeals(selectedMeal);

useEffect(() => {

 if(!loading && data){
  setmealBeverage(data.mealBeverage) 
    if (data.mealBeverage.length > 0) { 
      const selectedMealString = selectedMeal.length > 0 ? (
        <>
          {selectedMeal.slice(0, 2).map((name, index) => (
            <React.Fragment key={index}>
              {name}
              {index < 1 && ', '}
            </React.Fragment>
          ))}
          {selectedMeal.length > 2 && (
            <span style={{ color: theme.palette.primary.light }}>
              , +{selectedMeal.length - 2} more
            </span>
          )}
        </>
      ) : (
        'No meals selected'
      );
      
      onDataUpdateMeal(selectedMealString);
    }
  }

  }, [loading, data,  selectedMeal])


// useEffect(() => {
//   const storedSelectedMeals = localStorage.getItem('selectedMeals');
//   if (storedSelectedMeals) {
//     setSelectedMeal(JSON.parse(storedSelectedMeals));
//   }
// }, []);

// useEffect(() => {
//   if (!loading && data) {
//     setmealBeverage(data.mealBeverage) 

//     if (data.mealBeverage.length > 0) {
//       const baggageMealSelect = selectedMeal.map((name, index) => (
//         <Box key={index}>
//           <Button
//             variant="text"
//             sx={{
//               '&.MuiButton-root': {
//                 color: theme.palette.secondary.light,
//                 padding: '5px 10px 5px 0px',
//               },
//               '&.MuiButton-root:hover': {
//                 background: 'transparent',
//               },
//             }}
//           >
//             {name}
//           </Button>
//         </Box>
//       ));
//       onDataUpdateMeal(baggageMealSelect);
//     }
//   }
// }, [loading, data, selectedMeal, onDataUpdateMeal]);
  
  // const [mealBeverageIndex, setmealBeverageIndex] = useState<number | null>(null);



const theme = useTheme() 
const sliderSettings = {
  infinite: true,
  slidesToShow: 4,
  slidesToScroll: 1, 
  responsive: [
    {
      breakpoint: 1024,
      settings: {
        slidesToShow: 3,
        slidesToScroll: 1,
        infinite: true,
      },
    },
    {
      breakpoint: 600,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 1,
        initialSlide: 2,
      },
    },
    {
      breakpoint: 480,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1,
      },
    },
  ],
  prevArrow: <ArrowBackIos />, // Left arrow icon
  nextArrow: <ArrowForwardIos  />, // Right arrow icon
};

  const selectItem = [
    {
      id: 1,
      baggageId: 0,
      name: 'Shubham J'
    },
    {
      id: 2,
      baggageId: 0,
      name: 'Ashok P'
    },
    {
      id: 3,
      baggageId: 0,
      name: 'Rahul K'
    }
  ];

  const [ mealBeverageItem , setmealBeverageItem] = React.useState(selectItem)



  const handleSelectClick = (
    event: React.MouseEvent<HTMLButtonElement>,
    item: MealBeverage | SelectItem,
    index: number,
    id:number
  ) => {
    setAnchorEl(event.currentTarget);

    setmealBeverageIndex(index)

    setmealBeverageIndexId(id) 

    const updatedActiveClassArray = [...isActiveClass, index + 1];

  setIsActiveClass(updatedActiveClassArray);

  const updatedPreviouslySelectedIndexes = [...previouslySelectedIndexes, index];

  setPreviouslySelectedIndexes(updatedPreviouslySelectedIndexes);


  };
  
  const handleClosePopover = () => {
    setAnchorEl(null);

    // setmealBeverage(null);
    
    setmealBeverageIndexId(-1)
  };

  const handleCheckboxChange =
    (baggageIndex: number, itemId: number) => (event: React.ChangeEvent<HTMLInputElement>) => { 

      const updatedBaggage = [...mealBeverageItem] 

      updatedBaggage[itemId].baggageId = event.target.checked ? baggageIndex : 0;
      
      const selectedMeals = mealBeverage.find(selected => selected.id === baggageIndex)?.name;

      const updatedSelectedMeal = [...selectedMeal];

      if (event.target.checked) {
        updatedSelectedMeal.push(selectedMeals || ''); 
      } else {
        const indexToRemove = updatedSelectedMeal.indexOf(selectedMeals || ''); 
        // if (indexToRemove !== -1) {
          updatedSelectedMeal.splice(indexToRemove, 1); 
        // }
      }
     
      setSelectedMeal(updatedSelectedMeal);

      // setSelectedMeal(prevSelectedMeals => [...prevSelectedMeals, selectedMeals || '']);

      //  console.log(selectedWeight)

      const activeClassArray = updatedBaggage
      .filter(bag => mealBeverageIndexId === bag.baggageId)
      .map(bag => bag.baggageId || 0); 

      setIsActiveClass([...activeClassArray]);


      // const activeClassArray = updatedBaggage
      // .map((bag, index) => (mealBeverageIndexId === bag.baggageId) || index === mealBeverageIndex ? index + 1 : 0);
      
      // setIsActiveClass(activeClassArray);

      setmealBeverageItem(updatedBaggage)
     
      //  Check if any checkbox is checked
      const anyChecked = updatedBaggage.some(item => item.baggageId !== 0);
      setIsAnyCheckboxChecked(anyChecked);
      
      if (!event.target.checked) {
        alert(1)
        setPreviouslySelectedIndexes(prevIndexes =>
          prevIndexes.filter(prevIndex => prevIndex !== itemId)
        );

        setIsActiveClass(activeClassArray.filter(index => index !== itemId + 1));
      }

    }


  

  return (
    <>
      <Grid container>
        <Grid item xs={12} sm={12} className='slickSliderBox vegNonVegBox'>
          <Box>

        
            <FormGroup sx={{flexDirection:'row', paddingBottom:'0.5rem'}}>
              <FormControlLabel
               sx={{'& .Mui-checked':{
                color:`${theme.palette.secondary.light} !important`
               },
              }}
                control={
                  <Checkbox
                    checked={isVegChecked}
                    onChange={(e) => setIsVegChecked(e.target.checked)}
                  />
                }
                label='Veg'
              />
              <FormControlLabel
               sx={{'& .Mui-checked':{
                color:`${theme.palette.secondary.light} !important`
               },
              }}
                control={
                  <Checkbox
                    checked={isNonVegChecked}
                    onChange={(e) => setIsNonVegChecked(e.target.checked)}
                  />
                }
                label='Non-Veg'
              />
            </FormGroup>
          </Box>

          <Slider {...sliderSettings}>
            {mealBeverage
              .filter(
                (item) =>
                  (isVegChecked && item.type === 'veg') ||
                  (isNonVegChecked && item.type === 'non-veg') ||
                  (!isVegChecked && !isNonVegChecked)
              )
              .map((item, index) => {
                const isActive = isActiveClass.includes(index + 1) || previouslySelectedIndexes.includes(index);

              return (
                
                <>
                <Box
                className={`item ${isActive ? 'active' : ''}`}
                 key={index}>
                  <Box>
                    <div
                      className={`${
                        item.type === 'veg'
                          ? 'filter-box veg-box'
                          : item.type === 'non-veg'
                          ? 'filter-box non-veg-box'
                          : 'filter-box'
                      }`}
                    >
                      <Circle className='nonVegIcon vegIcon'/>
                      <Image
                        style={{ margin: 'auto' }}
                        src='/images/sandwitch.png'
                        width={100}
                        height={100}
                        alt=''
                      />
                    </div>
                    {/* ... Rest of the content */}
                  </Box>

                  <Divider/>
                  {/* ... Rest of the content */}

                  <Box sx={{padding:'10px'}}>
                         <Typography variant='subtitle2' display='block' gutterBottom sx={{
                          color: theme.palette.common.black, fontSize:'0.813rem'
                         }}>
                           {item.name}<br/> <CurrencyRupee sx={{ fontSize: '12px' }} />  
                           {item.price}
                        </Typography>
                
                         <Button variant="text" sx={{textAlign:'center', margin:'0 auto', display:'table'}}

                        //  onClick={(event) => handleSelectClick(event, item, index)}

                         onClick={(event) => handleSelectClick(event, item , index, item.id)}

                         >Select</Button>
                       </Box>
                
                </Box>


                </>
              )
            } 
              
              )}
          </Slider>

          {/* {mealBeverage !== null && anchorEl && mealBeverageIndex ( */}
          {mealBeverage !== null && anchorEl && mealBeverageIndex !== -1 && (
            <Popover
            open={Boolean(anchorEl)}
            anchorEl={anchorEl}
            onClose={handleClosePopover} 
            anchorOrigin={{
              vertical:'bottom',
              horizontal: 'center',
            }}
            transformOrigin={{
              vertical: 'top',
              horizontal: 'center',
            }}
          >
             <Box sx={{padding:'1rem'}}>  
               <Button variant="contained" sx={{minWidth:'auto',
                width:'100%', 
                textTransform:'capitalize',
                justifyContent:'space-between',
                background:theme.palette.common.black,
                '&.MuiButton-root:hover':{
                  background:theme.palette.common.black,
                }
                }}>
               <Typography variant="subtitle1" gutterBottom sx={{color:theme.palette.common.white, marginBottom:'0rem'}}>
              {mealBeverage[mealBeverageIndex]?.name} 
               
              </Typography>
              <Typography variant="subtitle1" gutterBottom sx={{color:theme.palette.common.white, marginBottom:'0rem',marginLeft:'1rem'}}>
              <CurrencyRupee sx={{ fontSize: '12px' }} />
              {mealBeverage[mealBeverageIndex]?.price} 
               </Typography>
               </Button>

               {/* {upcomingTrips.map((trip, index) => (   ))} */}

               {mealBeverageItem.map((item, index) => (
                  <>
  <Stack direction="row" spacing={1} sx={{alignItems:'center'}}>
  <Item>
    <FormControlLabel 
   sx={{minWidth:'8rem',
   '& .Mui-checked':{
    color:`${theme.palette.secondary.light} !important`
   },
  }}
  
   control={
   <Checkbox 
   checked={item.baggageId !== 0}
   onChange={handleCheckboxChange(mealBeverageIndexId, index)}
   value={item.id}
   name={item.name} // Use the item name as the checkbox name
   
   />} label={item.name} /></Item>
  <Item>  
    {/* <Typography variant="subtitle1" gutterBottom sx={{paddingTop:'0.5rem'}}>
    {mealBeverage[mealBeverageIndex]?.name} 
               
      </Typography> */}

                  <Typography variant="body2" gutterBottom
                      sx={{
                        color: theme.palette.common.black, paddingTop:'0.5rem'
                      }}
                    >
                    {item.baggageId !== 0 &&
                     mealBeverage.find(selected => selected.id === item.baggageId)?.name.substring(0, 15)+ '...'}


                    </Typography>
  </Item>
</Stack>
                  </>
                ) )}
           
             </Box>

            </Popover>
          )}

        </Grid>
      </Grid>
    </>
  );
};

export default MealBeverageInner;

