import React, { useEffect, useState } from 'react'
import {
  Avatar,
  Grid,
  Typography,
  Card,
  Divider,
  Button,
  useTheme,
  Chip,
  Box,
  Accordion,
  AccordionSummary,
  AccordionDetails, 
  Dialog, 
  DialogContent,
  DialogTitle,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
} from '@mui/material'

import { CurrencyRupee,Close,Flight,Error  } from '@mui/icons-material' 

import { useQuery } from '@apollo/client'
import { gql } from '@apollo/client'
import { useRouter } from 'next/router'

import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';

// import Slider from 'react-slick';
// import { text } from 'stream/consumers';

import { Tooltip} from '@mui/material';


const FLIGHTDETAILS_QUERY = gql`
  query FlightDetails {
    flightDetails {
      name
      arrivalTime
      arrivalPlace
      timeDuration
      stopDuration
      departureTime
      departurePlace
      weight
      amount
      day
      date
    }
  }
`

// const OwlCarousel = ReactOwlCarousel;

interface FlightDetails {
  name: string
  arrivalTime: string
  arrivalPlace: string
  timeDuration: string
  stopDuration: string
  departureTime: string
  departurePlace: string
  weight: string
  amount: string
  day:string
  date:string
}

interface FlightDetailsData {
  flightDetails: FlightDetails[]
}


// interface FlightDetailsItem {
//   arrivalPlace: string;

//   // ... other properties

// }

const FlightDetails = ({ onDataUpdate }) => {
    const [flightDetails, setFlightDetails] = useState<FlightDetailsData["flightDetails"]>([]);
    
  const theme = useTheme()
  const black = theme.palette.common.black
  const [expandedItem, setExpandedItem] = useState<number | null>(null); // Track the expanded item index

  // const [anchorEl, setAnchorEl] = useState<Element | null>(null)

  const [openModal, setOpenModal] = useState(false);
  const [currentModalIndex, setCurrentModalIndex] = useState<number | null>(null);

  // const [childData, setChildData] = useState('');


  const handleAccordionChange = (index: number) => {
    setExpandedItem(prevExpandedItem => (prevExpandedItem === index ? null : index));
  };

const { loading,  data } = useQuery<FlightDetailsData>(FLIGHTDETAILS_QUERY);
useEffect(() =>{
  if(!loading && data){
    setFlightDetails(data.flightDetails)
  }
}, [loading, data])


const router = useRouter();


// const handleSearchFlight = () => {
//   router.push('/travelsearchinner/flightlisting');
// };

React.useEffect(() => {
  if (router.pathname === '/travelsearchinner') { 
    const travelSearch = document.querySelector('.navList-Box [href="/travelsearch/"] span');
    travelSearch?.classList.add('active');
  }
}, [router.pathname]);



// const handleSortChange = (event: React.ChangeEvent<{ value: unknown }>) => {
//     const selectedOption = event.target.value as string;
//     // setSortOption(selectedOption);
//     // sortFlightResults(selectedOption);
//   };
  
  // const handleDropdownClose = (url?: string) => {
  //   if (url) {
  //     router.push(url)
  //   }
  //   setAnchorEl(null)
  // }
  
  
  // const handleDropdownOpen = (event) => {
  //   setAnchorEl(event.currentTarget)
  // }
  
  // const styles = {
  //   py: 2,
  //   px: 4,
  //   width: '100%',
  //   display: 'flex',
  //   alignItems: 'center',
  //   color: 'text.primary',
  //   textDecoration: 'none',
  //   '& svg': {
  //     fontSize: '1.375rem',
  //     color: 'text.secondary'
  //   }
  // }

//   const handleOpenModal = () => {
//     setOpenModal(true);
//   };


  const handleOpenModal = (index: number) => {
    setCurrentModalIndex(index);
    setOpenModal(true);
  };
  
  const handleCloseModal = () => {
    setOpenModal(false);
  };



  useEffect(() => {
  if (!loading && data) {
    setFlightDetails(data.flightDetails);
    
    if (data.flightDetails.length > 0) {
      const arrivalPlaces = data.flightDetails.map(item => (
        <>
        <Box>
        <Button
          key={item.arrivalPlace} // Provide a unique key for each button
          variant="text"
          sx={{
            '&.MuiButton-root': {
              color: theme.palette.secondary.light,
              padding: '5px 10px 5px 0px',
            },
            '&.MuiButton-root:hover': {
              background: 'transparent',
            },
          }}
        >
          {item.arrivalPlace}
          <Flight
            sx={{
              rotate: '90deg',
              marginRight: '10px',
              position: 'relative',
              left: '4px',
              top: '0px',
              fontSize: '1.25rem',
            }}
          />
          {item.departurePlace}
        </Button>

        <Button variant="text" >

<Typography variant='subtitle2' display='block' gutterBottom sx={{ marginBottom: '0rem',  textTransform:'capitalize' }}>
       {item.day}, {item.date} 
    </Typography>
    <Typography variant='subtitle2' display='block' gutterBottom sx={{ marginBottom: '0rem',  textTransform:'capitalize' }}>
    <span className='dot'>.</span> {item.stopDuration}
    </Typography>
    <Typography variant='subtitle2' display='block' gutterBottom sx={{ marginBottom: '0rem',  textTransform:'capitalize' }}>
    <span className='dot'>.</span> {item.timeDuration} 
    </Typography>
</Button>
    


</Box>

        </>
      ));

      // setChildData(arrivalPlaces.join(', '));
      
      onDataUpdate(arrivalPlaces);
    }
  }
}, [loading, data]);

   
  
    return (
        <>
         
     {/* {flightDetails?.map((item, index)=>( */}
     {flightDetails?.map((item, index) => {
      // setChildData(item.arrivalPlace); 
      return(

        <React.Fragment key={index}>
        <Grid item xs={12} >
        <Divider/>
       <Button variant="text"
        sx={{
         '&.MuiButton-root':{
            color:theme.palette.secondary.light,

           padding:'5px 10px 5px 0px',
         },
         '&.MuiButton-root :hover':{
           background:'transparent'
         }
       }}

       
        
        >
         {item.arrivalPlace}

              <Flight
                 sx={{
                   rotate: '90deg',
                   marginRight:'10px',
                   position: 'relative',
                   left: '4px',
                   top: '0px',
                   fontSize: '1.25rem'
                 }}
               /> {item.departurePlace}</Button>
       <Button variant="text" >

       <Typography variant='subtitle2' display='block' gutterBottom sx={{ marginBottom: '0rem', color: black, textTransform:'capitalize' }}>
              {item.day}, {item.date}
           </Typography>
       </Button>
     
             </Grid>
       <Card className='dataResultBox'  sx={{
           background:'#F7F7F7', 
           border:'none',
           marginBottom:'1rem'
       }}>
       <Grid container spacing={2} alignItems='center' sx={{ justifyContent: 'space-between' }}>
         <Grid item sx={{ display: 'flex', justifyContent: 'center', flexDirection: 'column' }}>
           <Avatar>Air</Avatar>
           <Typography
             variant='subtitle1'
             display='block'
             gutterBottom
             sx={{ textTransform: 'capitalize', color: black }}
           >
            {item.name}
           </Typography>
         </Grid>
         <Grid item>
           <Typography variant='subtitle2' display='block' gutterBottom sx={{ marginBottom: '0rem', color: black }}>
             {item.arrivalTime}
           </Typography>
           <Typography variant='subtitle2' display='block' gutterBottom sx={{ color: black }}>
             {item.arrivalPlace}
           </Typography>
         </Grid>
         <Grid item>
           <Typography
             variant='subtitle2'
             gutterBottom
             sx={{ marginBottom: '0rem', justifyContent: 'center', display: 'flex', color: black }}
           >
           {item.timeDuration}
           </Typography>
           <div className='dividerBox' />
           <Typography
             variant='subtitle2'
             gutterBottom
             sx={{ justifyContent: 'center', display: 'flex', color: black }}
           >
             {item.stopDuration}
           </Typography>
         </Grid>
         <Grid item>
           <Typography variant='subtitle2' display='block' gutterBottom sx={{ marginBottom: '0rem', color: black }}>
           {item.departureTime}
           </Typography>
           <Typography variant='subtitle2' display='block' gutterBottom sx={{ color: black }}>
           {item.departurePlace}
           </Typography>
         </Grid>
        
         <Grid item>
           <Typography
             variant='subtitle2'
             display='block'
             gutterBottom
             sx={{ marginBottom: '0rem', color: theme.palette.success.dark }}
           >
             <CurrencyRupee sx={{ fontSize: '12px' }} />
             {item.amount}
           </Typography>
           <Typography variant='subtitle2' display='block' gutterBottom sx={{}}>
             Trip fare
           </Typography>
         </Grid>
         <Grid item>
         <Tooltip 
         classes={{ tooltip: "tooltipBoxChip" }}   
         title="Your organisation does not permit booking a flight for more than INR 2000 per segment/passenger, booking a flight more than 30 days from the date of travel, or booking an ECONOMY class flight for the designated Primary Traveller.
         " placement="top" arrow>
           <Chip
             className="chipFlightDetails"
             label='Out of Policy'
             icon={<Error />} 
           />
           </Tooltip>
           <Box sx={{ display: 'block' }}>
             <Button
               variant='text'
               className='borderRadiusButton'

               // onClick = {()=> router.push('/travelsearchinner/flightlisting') }
               // onClick={handleSearchFlight} 

               sx={{
                 backgroundColor: 'transparent',
                 marginTop: '0.5rem',
                 paddingRight:'0rem',
                 float:'right',
                 border: 'none',
                 textTransform:'capitalize',
                 '&:hover': {
                   background:'none',
                   color: theme.palette.common.black
                 },
                 color: theme.palette.common.black
               }}
             >  
               Economy
             </Button>
           </Box>
         </Grid>
         <Grid
           item
           xs={12}
           sx={{
             '&.MuiGrid-item': {
               paddingTop: '0rem'
             }
           }}
         >
           <Accordion

             // expanded={isDetailsExpanded}

             expanded={expandedItem === index}

             onChange={() => handleAccordionChange(index)} 
             sx={{
               boxShadow: 'none',
               '&.Mui-expanded': {
                 boxShadow: 'none'
               }
             }}
           >
             <AccordionSummary
               sx={{
                 minHeight: '0px',
                 height: '0rem',
                 '&.Mui-expanded': {
                   minHeight: 0,
                   height: '1rem'
                 }
               }}
             >
               {/* <Typography variant='body2'>Additional content</Typography> */}
             </AccordionSummary>
             <AccordionDetails>
               <Grid container spacing={2} alignItems='center'>
                 <Grid item xs={6}>
                   {/* <IncludeBaggage /> */}
                 </Grid>
                 <Grid item xs={6}>
                   {/* <IncludeBaggage /> */}
                 </Grid>
               </Grid>
             </AccordionDetails>
           </Accordion>
         </Grid>
       </Grid>
     </Card>
     <Box sx={{
       justifyContent:'flex-end',
       display:'flex',
       width:'100%', 
     }}>
        <Button variant="text"
        sx={{
         '&.MuiButton-root':{
           color:theme.palette.primary.light,
           padding:'0px',
           
           textTransform:'capitalize'
         },
         '&.MuiButton-root :hover':{
           background:'transparent'
         }
       }}

       // onClick={handleOpenModal}
       
       onClick={() => handleOpenModal(index)}
        >
            View Fare Rules
       </Button>
    </Box>  

    <Dialog
 open={openModal}
 onClose={handleCloseModal}
 PaperProps={{ sx: { maxWidth:{xs:'42vw',sm:'58vw',md:'36vw'},overflow:'visible' } }}
 id={`modal-${currentModalIndex}`}
 maxWidth="md"
 fullWidth
>
 <DialogTitle sx={{textAlign:'center'}}>
   Fare Rules
   
   <Close 
   onClick={handleCloseModal}
             sx={{
               '&.MuiSvgIcon-root':{
                 background:theme.palette.common.white,
                 width:'2.5rem', height:'2.5rem', position:'absolute',
                 borderRadius:'100%',
                 top:'-1rem',
                 right:'-1rem',
                 padding:'10px',
                 cursor:'pointer'

               }
             }}
           />

 </DialogTitle>
 <DialogContent>
 <Button variant="outlined"
        sx={{
         '&.MuiButton-root':{
            color:theme.palette.secondary.light,
            borderColor:theme.palette.secondary.light,
           padding:'5px 10px 5px',
         },
         '&.MuiButton-root :hover':{
           background:'transparent'
         }
       }}
        
        >
         MUM 
              <Flight
                 sx={{
                   rotate: '90deg',
                   marginRight:'10px',
                   position: 'relative',
                   left: '4px',
                   top: '0px',
                   fontSize: '1.25rem'
                 }}
               /> DEL</Button>
   <TableContainer className="customTable" sx={{marginTop:'1rem'}}> 
     <Table  aria-label="simple table">
       <TableHead>
         <TableRow>
           <TableCell>
               
               <Typography variant="button" sx={{textTransform:'capitalize'}} display="block" gutterBottom>
               Time frame
              </Typography>
               <Typography variant="body2" sx={{textTransform:'capitalize'}} gutterBottom>
               Duration(From Scheduled flight departure)
               </Typography>
           </TableCell>
           <TableCell>
           <Typography variant="button" sx={{textTransform:'capitalize'}} display="block" gutterBottom>
           Airline Cancellation fee
              </Typography>
              <Typography variant="body2" sx={{textTransform:'capitalize'}} gutterBottom>
              (Per passenger)
               </Typography>
               </TableCell>
         </TableRow>
       </TableHead>
       <TableBody>
         {/* Render your table rows here */}
         <TableRow>
         <TableCell>0 hours to 4 hours</TableCell>
         <TableCell><span style={{color:'rgba(58, 53, 65, 0.87)'}}>Adult</span>: Non Refundable</TableCell>
         </TableRow>
         <TableRow>
           <TableCell>0 hours to 365 days</TableCell>
           <TableCell><span style={{color:'rgba(58, 53, 65, 0.87)'}}>Adult</span>: ₹1000</TableCell>
         </TableRow>
       </TableBody>
     </Table>
   </TableContainer>

   <Box sx={{ border: '1px solid #ddd', padding: '16px', marginTop: '16px' }}>
   <Typography variant="body2">
     <span  style={{ color: '#FF3C3C' }} >Please note: </span>  The airline charge is a guideline. In addition to the airline cancellation price, Genie charges a service fee, which affects the sort of refund that will be given.
   </Typography>
 </Box>

 </DialogContent>
 
</Dialog>
    
     </React.Fragment>
     );
    })}
        </>


    )
}

export default FlightDetails
