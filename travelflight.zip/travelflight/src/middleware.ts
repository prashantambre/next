// import { NextResponse,NextRequest } from 'next/server'

// import {isAuthenticated} from './pages/api/auth/auth';

// import getConfig from 'next/config';

// const { publicRuntimeConfig } = getConfig();
export const config = {
    matcher: [
        /*
         * Match all request paths except for the ones starting with:
         * - api (API routes)
         * - _next/static (static files)
         * - favicon.ico (favicon file)
         */
        '/((?!api|_next/static|pages/*|images/*|favicon.ico).*)',
      ],
}

// export async function middleware(req: NextRequest, res: NextResponse) {

    export async function middleware() {

    // const authenticate =  await isAuthenticated(req)
    // if(authenticate){
    //     return NextResponse.next();
    // }else{
    //     const signInPage = '/pages/login';
    //     const signInUrl = new URL(signInPage, req.nextUrl.origin);
    //     signInUrl.searchParams.append('callbackUrl', req.url);
    //     return NextResponse.redirect(signInUrl);
    // }
}
