export const countriesData = {
    countries: [
      {
        name: "United States",
        code: "US",
        emoji: "🇺🇸",
      },
      {
        name: "Canada",
        code: "CA",
        emoji: "🇨🇦",
      },
      {
        name: "Mexico",
        code: "MX",
        emoji: "🇲🇽",
      },
      {
        name: "United Kingdom",
        code: "GB",
        emoji: "🇬🇧",
      },
      {
        name: "France",
        code: "FR",
        emoji: "🇫🇷",
      },
    ],
  };