import React, { useEffect, useState } from 'react'
import {
  Avatar,
  Grid,
 
  Typography,
  Card,
  Divider,
  Button,

  useTheme,
  Chip,
  Box,
  Accordion,
  AccordionSummary,
  AccordionDetails,
  
  Dialog,

  DialogContent,
  DialogTitle,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
} from '@mui/material'
import { CurrencyRupee,Close,Flight,Error  } from '@mui/icons-material' 

import { useQuery } from '@apollo/client'
import { gql } from '@apollo/client'
import { useRouter } from 'next/router'

import {  Tooltip} from '@mui/material';


const FLIGHTDETAILS_QUERY = gql`
  query FlightDetails {
    flightDetails {
      name
      arrivalTime
      arrivalPlace
      timeDuration
      stopDuration
      departureTime
      departurePlace
      weight
      amount
      day
      date
    }
  }
`

// const OwlCarousel = ReactOwlCarousel;

interface FlightDetails {
  name: string
  arrivalTime: string
  arrivalPlace: string
  timeDuration: string
  stopDuration: string
  departureTime: string
  departurePlace: string
  weight: string
  amount: string
  day:string
  date:string
}

interface FlightDetailsData {
  flightDetails: FlightDetails[]
}


// interface FlightDetailsItem {
//   arrivalPlace: string;

//   // ... other properties

// }

const FlightDetails = ({ onDataUpdate }) => {
    const [flightDetails, setFlightDetails] = useState<FlightDetailsData["flightDetails"]>([]);
    
  const theme = useTheme()
  const black = theme.palette.common.black
  const [expandedItem, setExpandedItem] = useState<number | null>(null); // Track the expanded item index

  // const [anchorEl, setAnchorEl] = useState<Element | null>(null)
  
  const [openModal, setOpenModal] = useState(false);
  const [currentModalIndex, setCurrentModalIndex] = useState<number | null>(null);

  // const [childData, setChildData] = useState('');


  const handleAccordionChange = (index: number) => { 
    setExpandedItem(prevExpandedItem => (prevExpandedItem === index ? null : index));
  };

 
const { loading,  data } = useQuery<FlightDetailsData>(FLIGHTDETAILS_QUERY);
useEffect(() =>{
  if(!loading && data){
    setFlightDetails(data.flightDetails)
  }
}, [loading, data])


const router = useRouter();


// const handleSearchFlight = () => {
//   router.push('/travelsearchinner/flightlisting');
// };

React.useEffect(() => {
  if (router.pathname === '/travelsearchinner') { 
    const travelSearch = document.querySelector('.navList-Box [href="/travelsearch/"] span');
    travelSearch?.classList.add('active');
  }
}, [router.pathname]);



// const handleSortChange = (event: React.ChangeEvent<{ value: unknown }>) => {
//     const selectedOption = event.target.value as string;

//     // setSortOption(selectedOption);
//     // sortFlightResults(selectedOption);
//   };
  
  // const handleDropdownClose = (url?: string) => {
  //   if (url) {
  //     router.push(url)
  //   }
  //   setAnchorEl(null)
  // }
  
  
  // const handleDropdownOpen = (event) => {
  //   setAnchorEl(event.currentTarget)
  // }
  
  // const styles = {
  //   py: 2,
  //   px: 4,
  //   width: '100%',
  //   display: 'flex',
  //   alignItems: 'center',
  //   color: 'text.primary',
  //   textDecoration: 'none',
  //   '& svg': {
  //     fontSize: '1.375rem',
  //     color: 'text.secondary'
  //   }
  // }

//   const handleOpenModal = () => {
//     setOpenModal(true);
//   };


  const handleOpenModal = (index: number) => {
    setCurrentModalIndex(index);
    setOpenModal(true);
  };
  
  const handleCloseModal = () => {
    setOpenModal(false);
  };



  useEffect(() => {
  if (!loading && data) {
    setFlightDetails(data.flightDetails);
    
    if (data.flightDetails.length > 0) {
      const arrivalPlaces = data.flightDetails.map(item => (
        <>
        <Box>
        <Button
          key={item.arrivalPlace} // Provide a unique key for each button
          variant="text"
          sx={{
            '&.MuiButton-root': {
              color: theme.palette.secondary.light,
              padding: '5px 10px 5px 0px',
            },
            '&.MuiButton-root:hover': {
              background: 'transparent',
            },
          }}
        >
          {item.arrivalPlace}
          <Flight
            sx={{
              rotate: '90deg',
              marginRight: '10px',
              position: 'relative',
              left: '4px',
              top: '0px',
              fontSize: '1.25rem',
            }}
          />
          {item.departurePlace}
        </Button>

        <Button variant="text" >

<Typography variant='subtitle2' display='block' gutterBottom sx={{ marginBottom: '0rem',  textTransform:'capitalize' }}>
       {item.day}, {item.date} 
    </Typography>
    <Typography variant='subtitle2' display='block' gutterBottom sx={{ marginBottom: '0rem',  textTransform:'capitalize' }}>
    <span className='dot'>.</span> {item.stopDuration}
    </Typography>
    <Typography variant='subtitle2' display='block' gutterBottom sx={{ marginBottom: '0rem',  textTransform:'capitalize' }}>
    <span className='dot'>.</span> {item.timeDuration} 
    </Typography>
</Button>
    


</Box>

        </>
      ));

      // setChildData(arrivalPlaces.join(', '));

       onDataUpdate(arrivalPlaces);

    //  let childData = arrivalPlaces.join(', ');
    //   setChildData(childData);
    //   onDataUpdate(childData);

    }
  }
}, [loading, data]);

    return (
      <>
      </>
    )
  
}

export default FlightDetails
