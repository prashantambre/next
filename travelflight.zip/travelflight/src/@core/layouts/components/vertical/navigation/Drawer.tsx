// ** React Imports
import { ReactNode, useEffect, useState} from 'react'

// ** MUI Imports
import { styled, useTheme } from '@mui/material/styles'
import MuiSwipeableDrawer, { SwipeableDrawerProps } from '@mui/material/SwipeableDrawer'

// ** Type Import
import { Settings } from 'src/@core/context/settingsContext'

// import { NoSsr } from '@mui/material'

import { Theme } from '@mui/material/styles'
import useMediaQuery from '@mui/material/useMediaQuery' 
import { useRouter } from 'next/router'


interface Props {
  hidden: boolean
  navWidth: number
  settings: Settings
  navVisible: boolean
  children: ReactNode
  setNavVisible: (value: boolean) => void
  saveSettings: (values: Settings) => void
}

const SwipeableDrawer = styled(MuiSwipeableDrawer)<SwipeableDrawerProps>({
  overflowX: 'hidden',
  transition: 'width .25s ease-in-out',
  '& ul': {
    listStyle: 'none'
  },
  '& .MuiListItem-gutters': {
    paddingLeft: 4,
    paddingRight: 4,
    marginTop:0,
  },
  '& .MuiDrawer-paper': {
    left: 'unset',
    right: 'unset',
    overflowX: 'hidden',
    transition: 'width .25s ease-in-out, box-shadow .25s ease-in-out'
  }
})

const Drawer = (props: Props) => {
  // ** Props
  const { hidden, children, navWidth, navVisible, setNavVisible } = props
  const [isTravelMenuActive, setIsTravelMenuActive] = useState(false);

  // ** Hook
  const theme = useTheme()

  // Drawer Props for Mobile & Tablet screens
  const MobileDrawerProps = {
    open: navVisible,
    onOpen: () => setNavVisible(true),
    onClose: () => setNavVisible(false),
    ModalProps: {
      keepMounted: true // Better open performance on mobile.
    },

  
  }

  // Drawer Props for Desktop screens
  // const DesktopDrawerProps = {
  //   // open: true,
  //   // onOpen: () => null,
  //   // onClose: () => null
  //   // navVisible:open,
  //  open: navVisible,
  //  onOpen: () => setNavVisible(true),
  //  onClose: () => setNavVisible(false), 
  // // open: true,

  // // onClick: () => console.log('DesktopDrawerProps clicked')
  // // onOpen: () => setNavVisible(true),
  // // onClose: () => setNavVisible(false),

  // }

  const DesktopDrawerProps = 
  navVisible ? {
      open: false,
      onOpen: () => setNavVisible(true),
      onClose: () => setNavVisible(false)
    } 
    : {
    open: true,
    onOpen: () => {''},
    onClose: () => {''},
    };


    
 
  // const DesktopDrawerProps = {
  //   open: true,
  //   onOpen: () => setNavVisible(true),
  //   onClose: () => setNavVisible(false),
   
  // };
  
  // if (navVisible) {
  //   DesktopDrawerProps.open = false;
  //   DesktopDrawerProps.onOpen = () => {};
  //   DesktopDrawerProps.onClose = () => {};
     
  // }

  const router = useRouter();  
  
  useEffect(()=>{
    const travelMenu = document.querySelector('.navList-Box [href="/travelsearch/"] span'); 
     if(travelMenu?.classList.contains('active')){
      setIsTravelMenuActive(true);
    } else {
      setIsTravelMenuActive(false);
    }

  }, []); 

  useEffect(() => {
    const handleNavClick = (item) => {     
       if(item.currentTarget.pathname === '/travelsearch/'){  
      const travelMenu = document.querySelector('.navList-Box [href="/travelsearch/"] span'); 
      if(travelMenu){ 
        setIsTravelMenuActive(true);
      } 
       }else{
        setIsTravelMenuActive(false);
       }
    }
  
    document.querySelectorAll('.navList-Box .nav-link a').forEach((item) => {
      item.addEventListener('click', handleNavClick);
    }); 
  }, [router]);


  const hiddenSm = useMediaQuery((theme: Theme) => theme.breakpoints.down('sm'))


  return (
    <>
    <SwipeableDrawer
      className={`layout-vertical-nav ${navVisible && !hiddenSm ? 'drawerShow' : ''}`}

      variant={hidden ? 'temporary' : 'persistent'}

      // {...(hidden ? { ...MobileDrawerProps } : { ...DesktopDrawerProps})}
      // {...(hidden ? { ...MobileDrawerProps } : { ...DesktopDrawerProps, open: true, onOpen: () => setNavVisible(true), onClose: () => setNavVisible(false) })}
     
      {...(hidden ? { ...MobileDrawerProps } : { ...DesktopDrawerProps })}
      PaperProps={{ sx: { width: navWidth } }}
      sx={{ 
        marginTop: isTravelMenuActive ? '10rem' : '5rem',
        [theme.breakpoints.down('sm')]: {
          marginTop: isTravelMenuActive ? '10rem' : '9rem',
        },
        width: navWidth,
        '& .MuiDrawer-paper': {
          borderRight: 0,
          backgroundColor: theme.palette.background.paper,

          borderRadius:'0px 10px 10px 0px',
          top: isTravelMenuActive ? '9rem' : '6.5rem',
          [theme.breakpoints.down('sm')]: {
            top: isTravelMenuActive ? '0rem' : '0rem',
          }
        }

        // [theme.breakpoints.down('sm')]: {
        //   '& .MuiDrawer-paper': {
        //     top:'0rem'
        //   }
        // }

      }}
    >
      {children}
    </SwipeableDrawer>
    </>
  )
}

export default Drawer



