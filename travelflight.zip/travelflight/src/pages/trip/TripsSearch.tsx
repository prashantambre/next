import * as React from 'react';
import Box from '@mui/material/Box';
import Tab from '@mui/material/Tab';
import TabContext from '@mui/lab/TabContext';
import TextField from '@mui/material/TextField'
import TabList from '@mui/lab/TabList';
import TabPanel from '@mui/lab/TabPanel';
import { Typography } from '@mui/material';
import { Card  } from '@mui/material'
import { useTheme } from '@mui/material/styles' 
import Upcoming from './Upcoming';
import InputAdornment from '@mui/material/InputAdornment' 
import Magnify from 'mdi-material-ui/Magnify' 

import { useRouter } from 'next/router'

const TripsSearch = () =>{


    const [value, setValue] = React.useState('1');

    const handleChange = (event: React.SyntheticEvent, newValue: string) => {
      setValue(newValue);
    };
    const router = useRouter();

    React.useEffect(() => {
      if (router.pathname === '/trip') { 
        const travelSearch = document.querySelector('.navList-Box [href="/travelsearch/"] span');
        travelSearch?.classList.add('active');
      }
    }, [router.pathname]);

    const theme = useTheme()

    return(
        <>
          <Card sx={{
             border:`1px solid ${theme.palette.grey.A100} `, 
             boxShadow:'none',
             overflow:'visible'
          }} >   

        <Box sx={{ display:'flex', flexWrap:'wrap', justifyContent:'space-between', padding:'2rem' }}>
        <Typography variant="h5" component="div" >
           Trips   
        </Typography>

      
        <TextField 
          size='small' 
          placeholder='Seach booking ID'
          sx={{ 
            '& .MuiOutlinedInput-root': { 

              // borderRadius: 21.5,

              boxShadow: '0px 0px 20px rgba(22, 22, 22, 0.08)', // add box shadow
              paddingLeft:'6px',

              // width:{xs:'30rem',sm:'17rem',md:'30rem'},

              '&:hover:not(.Mui-disabled)': { // remove hover color
                borderColor: 'transparent'
              },
              '&.Mui-focused .MuiOutlinedInput-notchedOutline': { // remove focus color
                borderColor: 'transparent'
              }
            },
            '& .MuiSvgIcon-root': { 

              // backgroundColor: '#F0971A',
              // borderRadius:'50%',

              width:'30px',
              height:'30px',
              padding:'4px',

              // color:'#fff'
              
            },
            '& .MuiOutlinedInput-notchedOutline':{
              borderColor:'transparent'
            },
            [theme.breakpoints.down('sm')]: {
              '& .MuiOutlinedInput-root': {
                width: '11rem'
              }
            }
             
          }}
          InputProps={{
            startAdornment: (
              <InputAdornment position='start'>
                <Magnify fontSize='small' />
              </InputAdornment>
            )
          }}
        />
        </Box>
     <Box sx={{ width: '100%', typography: 'body1', marginTop:'3rem', paddingLeft:'3rem' }}>
      <TabContext value={value}>
        <Box >
          <TabList onChange={handleChange} 
                     sx={{
                      overflow:'visible',
                      '& .MuiTabs-scroller':{
                         overflow:'visible !important'
                      },
                     '& .MuiButtonBase-root':{
                          textTransform:'capitalize',
                          padding:'0.5rem 2rem',
                          position:'relative',
                          top:'1px',
                          
                     },
                     '& .MuiTabs-indicator':{
                       display:'none'
                     },
                     '& .Mui-selected':{
                        borderLeft:`1px solid ${theme.palette.grey.A100} `,
                        borderRight:`1px solid ${theme.palette.grey.A100}`,
                        borderTop:`5px solid ${theme.palette.secondary.light}`,
                        color:`${theme.palette.common.black } !important`,
                        fontWeight:'600',
                        borderTopLeftRadius:'8px',
                        borderTopRightRadius:'8px', 
                        background:'#F4F5FA'
                     },
                   }}
           >
            <Tab label="Upcoming" value="1" />
            <Tab label="Completed" value="2" />
            <Tab label="Cancelled" value="3" />
          </TabList>
        </Box>
      
      </TabContext>
    </Box>

      </Card>
     <Box>
      <TabContext value={value}>
      <TabPanel value="1" sx={{padding:'0rem'}}>
         <Upcoming/> 
      </TabPanel>
        <TabPanel value="2" sx={{padding:'0rem'}}>
        <Upcoming/>
        </TabPanel>
        <TabPanel value="3" sx={{padding:'0rem'}}>
        <Upcoming/>
        </TabPanel>
      </TabContext>
      </Box>
        </>
    )
}

export default TripsSearch