

import TripsSearch from './TripsSearch';

const Trips = () => {
    return (
        <>
      
            <TripsSearch/>
       
        </>
    )
}

export default  Trips;