

import React, { useEffect, useState } from 'react'
import {

  Avatar,

  Grid,

  Typography,

  Card,
 
  Button,
 
  useTheme,
 
  Box,
  
  Dialog,
  
  DialogContent,

  DialogTitle,

  DialogActions,
 
  FormGroup,

  FormControlLabel,

  Checkbox

} from '@mui/material'
import { CurrencyRupee,Close, ArrowUpward, ArrowDownward, Flight, Hotel  } from '@mui/icons-material' 

// import IncludeBaggage from './ResultData/IncludedBaggage'
import { useQuery } from '@apollo/client'
import { gql } from '@apollo/client'
import { useRouter } from 'next/router'


import {  MenuItem, Menu,} from '@mui/material';

// import  TextareaAutosize  from '@mui/base/TextareaAutosize';

import TextareaAutosize from '@mui/material/TextareaAutosize';

import Image from 'next/image';



const PENDINGREQUEST_QUERY = gql`
  query PendingRequest {
    pendingRequest {
      tripId
      travelerDetails
      date
      dastination 
      tripPurpose
      tripPurposeDescription 
      amount
    }
  }
`

// const OwlCarousel = ReactOwlCarousel;

interface pendingRequest {
  tripId:string
  travelerDetails:string
  date:string
  dastination:string
  tripPurpose:string
  tripPurposeDescription:string
  amount:number
}

interface PendingRequestData {
  pendingRequest: pendingRequest[]
}


// interface FlightDetailsItem {
//   arrivalPlace: string;
//   // ... other properties
// }


const Pending = () => {
  const [pendingRequest, setPendingRequest] = useState<PendingRequestData["pendingRequest"]>([]);
  const theme = useTheme()
  const black = theme.palette.common.black

  // const [expandedItem, setExpandedItem] = useState<number | null>(null); // Track the expanded item index

  const [anchorEl, setAnchorEl] = useState<Element | null>(null)
  const [openModal, setOpenModal] = useState(false);
  const [openModalReject, setOpenModalReject] = useState(false);
  const [currentModalIndex, setCurrentModalIndex] = useState<number | null>(null);

  // const [childData, setChildData] = useState('');
  
  const [currentModalIndexReject, setCurrentModalIndexReject] = useState<number | null>(null);

  const [showTextarea, setShowTextarea] = useState(false);


  // const handleAccordionChange = (index: number) => {
  //   setExpandedItem(prevExpandedItem => (prevExpandedItem === index ? null : index));
  // };

const { loading,  data } = useQuery<PendingRequestData>(PENDINGREQUEST_QUERY);
useEffect(() =>{
  if(!loading && data){ 
    setPendingRequest(data.pendingRequest)
  }
}, [loading, data])


const router = useRouter();

const handleCheckboxChange = (event) => {
  setShowTextarea(event.target.checked);
};


// const handleSearchFlight = () => {
//   router.push('/travelsearchinner/flightlisting');
// };

React.useEffect(() => {
  if (router.pathname === '/travelsearchinner') { 
    const travelSearch = document.querySelector('.navList-Box [href="/travelsearch/"] span');
    travelSearch?.classList.add('active');
  }
}, [router.pathname]);



// const handleSortChange = (event: React.ChangeEvent<{ value: unknown }>) => {
//     const selectedOption = event.target.value as string;

//     // setSortOption(selectedOption);
//     // sortFlightResults(selectedOption);

//   };
  
  const handleDropdownClose = (url?: string) => {
    if (url) {
      router.push(url)
    }
    setAnchorEl(null)
  }
  
  
  const handleDropdownOpen = (event) => {
    setAnchorEl(event.currentTarget)
  }
  
  const styles = {
    py: 2,
    px: 4,
    width: '100%',
    display: 'flex',
    alignItems: 'center',
    color: 'text.primary',
    textDecoration: 'none',
    '& svg': {
      fontSize: '1.375rem',
      color: 'text.secondary'
    }
  }

  const handleOpenModal = (index: number) => {
    setCurrentModalIndex(index);
    setOpenModal(true);
  };

  const handleOpenModalReject = (index: number) => {
    setCurrentModalIndexReject(index);
    setOpenModalReject(true);
  };
  
  const handleCloseModal = () => {
    setOpenModal(false);
    setOpenModalReject(false);
  };






  return (
        <>

<Grid container spacing={2} alignItems='center' sx={{ justifyContent: 'flex-end', marginTop:'1rem' }}>

{setPendingRequest.length === 0 ? (

<Grid item xs={12} sm={6} sx={{margin:'6rem auto 0rem', display:'flex', justifyContent:'center',flexDirection:'column',}}>
<Image
style={{margin:'auto'}}
 src="/images/nullData.png" // Provide the path to your image file in the public directory 
 width={300}
 height={250}
 alt=''
  />

<Typography variant="subtitle2" gutterBottom 
sx={{
  '&.MuiTypography-root':{ 
    position:'relative',
    top:'-4rem',
    textAlign:'center',
    color:theme.palette.common.black
  } 
}}

>
Looks empty, you've no completed bookings.
</Typography>
<Button variant="contained" 
     className="borderRadiusButton"  
     sx={{backgroundColor:theme.palette.secondary.main,
           marginTop:'1.5rem', 
           margin:'0 auto',
           width:'8rem',
           padding:'8px !important',
           '&:hover':{
            background:theme.palette.primary.light
           }, 
           minWidth:'auto !important'
           
      }}>
     Plan a Trip
</Button> 
</Grid>


):(


  <Grid item>
  <Box onClick={handleDropdownOpen}> 
<Typography component={'h3'} sx={{ fontWeight: '600',cursor:'pointer' }}>
         Sort by: <ArrowUpward sx={{ '&.MuiSvgIcon-root':{
            position:'relative',
            left:'-5px',
            top:'0px',
            fontSize:'16px'  ,
            
          }
          }}/> 
          <ArrowDownward  sx={{
          '&.MuiSvgIcon-root':{
            position:'relative',
            left:'-11px',
            top:'9px',
            fontSize:'16px'  
          }
         }}/>
      </Typography>     
</Box>

<Menu
anchorEl={anchorEl}
open={Boolean(anchorEl)}
onClose={() => handleDropdownClose()}
sx={{ '& .MuiMenu-paper': { width: 130, marginTop: 4 } }}
anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
transformOrigin={{ vertical: 'top', horizontal: 'right' }}
>
<MenuItem sx={{ p: 0 }} onClick={() => handleDropdownClose()}>
  <Box sx={styles}> 
    Today
  </Box>
</MenuItem> 
<MenuItem sx={{ p: 0 }} onClick={() => handleDropdownClose()}>
  <Box sx={styles}> 
    Yesterday
  </Box>
</MenuItem> 
<MenuItem sx={{ p: 0 }} onClick={() => handleDropdownClose()}>
 <Box sx={styles}> 
    This Week
 </Box>
</MenuItem>
<MenuItem sx={{ py: 2 }} onClick={() => handleDropdownClose()}>
  Last Week
</MenuItem>
<MenuItem sx={{ py: 2 }} onClick={() => handleDropdownClose()}> 
  This Month
</MenuItem>
<MenuItem sx={{ py: 2 }} onClick={() => handleDropdownClose()}> 
  Last Month
</MenuItem>
<MenuItem sx={{ p: 0 }} onClick={() => handleDropdownClose()}>
  <Box sx={styles}> 
    This Year
  </Box>
</MenuItem>
<MenuItem sx={{ p: 0 }} onClick={() => handleDropdownClose()}>
  <Box sx={styles}> 
    Last Year
  </Box>
</MenuItem>
<MenuItem sx={{ p: 0 }} onClick={() => handleDropdownClose()}>
  <Box sx={styles}>
    All Time
  </Box>
</MenuItem>
</Menu>

  </Grid>


)}







  </Grid>
       
         
     {pendingRequest?.map((item, index) => {
      // setChildData(item.arrivalPlace); 
      return(
        

        <React.Fragment key={index}>


       <Card className='dataResultBox'  sx={{
           background:theme.palette.common.white, 
           border:'none',
           marginBottom:'1rem'
       }}>
       <Grid container spacing={2} alignItems='baseline' sx={{ justifyContent: 'space-between' }}>
         <Grid item sx={{ display: 'flex', justifyContent: 'center', flexDirection: 'column' }}>
         <Typography variant="body2" gutterBottom>
             Trip ID
          </Typography>
           <Typography
             variant='subtitle1'
             display='block'
             gutterBottom
             sx={{ textTransform: 'capitalize', color: black }}
           >
            {item.tripId}
          
           </Typography>
         </Grid>

         <Grid item sx={{ display: 'flex', justifyContent: 'center', flexDirection: 'column', width:'10rem' }}>
         <Typography variant="body2" gutterBottom>
             Traveler Details  
          </Typography>
           <Typography
             variant='subtitle1'
             display='block'
             gutterBottom
             sx={{ textTransform: 'capitalize', color: black }}
           >
             {item.travelerDetails}
          
           </Typography>
           <Typography variant="subtitle2" sx={{ textTransform: 'capitalize', color: black }} gutterBottom>
             1+ more
           </Typography>
         </Grid>
         <Grid item sx={{ display: 'flex', justifyContent: 'center', flexDirection: 'column', width:'15rem' }}>
         <Typography variant="body2" gutterBottom>
             Date - Destination
          </Typography>
           <Typography
             variant='subtitle1'
             display='block'
             gutterBottom
             sx={{ textTransform: 'capitalize', color: black }}
           >
             {item.date}
          
           </Typography>
           <Typography variant="subtitle2" sx={{ textTransform: 'capitalize', color: black }} gutterBottom>
            {item.dastination}
           </Typography>
           <Box sx={{display:'flex'}}>
           <Avatar sx={{ background: '#F5F7FA',marginRight:'1rem' }}><Flight sx={{ color: '#687591' }} /></Avatar>
           <Avatar sx={{ background: '#F5F7FA' }}><Hotel sx={{ color: '#687591' }} /></Avatar>
           </Box>
         </Grid>

         <Grid item sx={{ display: 'flex', justifyContent: 'center', flexDirection: 'column', width:'12rem' }}>
         <Typography variant="body2" gutterBottom>
             Trip Purpose
          </Typography>
           <Typography
             variant='subtitle1'
             display='block'
             gutterBottom
             sx={{ textTransform: 'capitalize', color: black }}
           >
            {item.tripPurpose}
           
           </Typography>
           <Typography variant="subtitle2" sx={{ textTransform: 'capitalize', color: black }} gutterBottom>
            {item.tripPurposeDescription}
           </Typography>
         </Grid>
         
        
         <Grid item sx={{ display: 'flex', justifyContent: 'center', flexDirection: 'column' }}>
         <Typography variant="body2" gutterBottom>
             Amount
          </Typography>
           <Typography
             variant='subtitle1'
             display='block'
             gutterBottom
             sx={{ textTransform: 'capitalize', color: black }}
           >
               <CurrencyRupee sx={{ fontSize: '12px' }} /> {item.amount}
           
           </Typography>
          
         </Grid>
        
         <Grid item sx={{ display: 'flex', justifyContent: 'center', flexDirection: 'column' }}>
         <Typography variant="body2" gutterBottom>
             In-Policy
          </Typography>
           <Typography
             variant='subtitle1'
             display='block'
             gutterBottom
             sx={{ textTransform: 'capitalize', color: black }}
           >
               No
           
           </Typography>
           <Typography variant="subtitle2" sx={{ textTransform: 'capitalize', color:'red' }} gutterBottom>
             *View details for <br/>
             further info
           </Typography>
          
         </Grid>
         <Grid sx={{position:'relative', top:'1.75rem'}}>
          
         <Box sx={{ 
          display: 'block', 
          marginBottom:'10px', 
          }}>
        
          <Button 
            variant="contained" 
            sx={{textTransform:'capitalize',marginRight:'10px',
            background:theme.palette.secondary.light,
            '&:hover': {
              background:'none',
              color: theme.palette.common.black
            },
          }}
          onClick={() => handleOpenModal(index)}
          >Approve</Button>
         
          <Button variant="outlined" sx={{textTransform:'capitalize', 
          borderColor:theme.palette.secondary.light,
          color:theme.palette.secondary.light
          }}
          onClick={() => handleOpenModalReject(index)}
          >Reject</Button>
           
          </Box>
           <Box sx={{ display: 'block' }}>
             <Button sx={{ display: 'block', 
             minWidth:'100%', 
             textTransform:'capitalize', 
             background:'none',
             color: theme.palette.common.black,
             borderColor:'transparent',
             boxShadow: '4px 4px 15px -12px rgb(58 53 65)'
             }} 
             onClick = {()=> router.push('/requestlisting') }
             variant="outlined">View Booking</Button>
           </Box>
         </Grid>
        
       </Grid>
     </Card>



     <Dialog
 open={openModal}
 onClose={handleCloseModal}
 PaperProps={{ sx: { maxWidth:{xs:'42vw',sm:'58vw',md:'26vw'},overflow:'visible' } }}
 id={`modal-${currentModalIndex}`}
 maxWidth="md"
 fullWidth
>
<Close 
   onClick={handleCloseModal}
             sx={{
               '&.MuiSvgIcon-root':{
                 background:theme.palette.common.white,
                 width:'2.5rem', height:'2.5rem', position:'absolute',
                 borderRadius:'100%',
                 top:'-1rem',
                 right:'-1rem',
                 padding:'10px',
                 cursor:'pointer'

               }
             }}
           />
 <DialogTitle>
 
 <Typography variant="h5" gutterBottom>
   Approve This Request?
   </Typography>
   <Typography variant="subtitle1" gutterBottom>
   If no additional permissions are needed, the requester will be able to finish the booking.
   </Typography>
   

 </DialogTitle>
 <DialogContent>
 <Typography variant="subtitle2" gutterBottom>
 Any Comments? (Optional)
      </Typography>
   
   <Box sx={{  marginTop: '16px' }}>
   <TextareaAutosize
   
      className='CustomTextArea'
      maxRows={4}
      aria-label="maximum height"
      placeholder="Maximum  6 rows"
      defaultValue="Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt
      ut labore et dolore magna aliqua. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt
      ut labore et dolore magna aliqua."
    />
 </Box>

 </DialogContent>

 <DialogActions> 
          <Button 
            variant="contained" 
            sx={{textTransform:'capitalize',marginRight:'10px',
            background:theme.palette.secondary.light,
            minWidth:'auto',
            padding:'0.46875rem 2.375rem',
            '&:hover': {
              background:'none',
              color: theme.palette.common.black
            },
          }}
          onClick={handleCloseModal}
          >Approve</Button>
</DialogActions>
 
</Dialog>

{/*  */}
<Dialog
 open={openModalReject}
 onClose={handleCloseModal}
 PaperProps={{ sx: { maxWidth:{xs:'42vw',sm:'58vw',md:'36vw'},overflow:'visible' } }}
 id={`modal-${currentModalIndexReject}`}
 maxWidth="md"
 fullWidth
>
<Close 
   onClick={handleCloseModal}
             sx={{
               '&.MuiSvgIcon-root':{
                 background:theme.palette.common.white,
                 width:'2.5rem', height:'2.5rem', position:'absolute',
                 borderRadius:'100%',
                 top:'-1rem',
                 right:'-1rem',
                 padding:'10px',
                 cursor:'pointer'

               }
             }}
           />
 <DialogTitle sx={{
  '&.MuiDialogTitle-root':{
    paddingBottom:0
  }
 }}>
 
 <Typography variant="h5" gutterBottom>
   Reject This Request?
   </Typography>
   <Typography variant="subtitle1" gutterBottom sx={{paddingBottom:'0rem'}}>
   The requester will receive a rejection email along with the selected explanation for rejecting the request.
   </Typography>

 </DialogTitle>
 <DialogContent>
   <Box >
  <FormGroup>
  <FormControlLabel 
    sx={{'& .Mui-checked':{
      color:'#F0971A !important'
     },
    }}
  control={<Checkbox defaultChecked />} label="Out of Policy" />
  <FormControlLabel
    sx={{'& .Mui-checked':{
      color:'#F0971A !important'
     },
    }}
  control={<Checkbox />} label="Change in travel plan" />
  <FormControlLabel
    sx={{'& .Mui-checked':{
      color:'#F0971A !important'
     },
    }}
  control={<Checkbox />} label="Wrong location" />
  <FormControlLabel
     sx={{'& .Mui-checked':{
      color:'#F0971A !important'
     },
    }}
  control={<Checkbox  
  onChange={handleCheckboxChange}
  />} label="Others" />
</FormGroup>
{showTextarea && (
   <TextareaAutosize
     className='CustomTextArea'
      maxRows={4}
      aria-label="maximum height"
      placeholder="Maximum  6 rows"
      defaultValue="Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt
      ut labore et dolore magna aliqua. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt
      ut labore et dolore magna aliqua."
    />
    )}
 </Box>

 </DialogContent>

 <DialogActions> 
          <Button 
            variant="contained" 
            sx={{textTransform:'capitalize',marginRight:'10px',
            background:theme.palette.secondary.light,
            minWidth:'auto',
            padding:'0.46875rem 2.375rem',
            '&:hover': {
              background:'none',
              color: theme.palette.common.black
            },
          }}
          onClick={handleCloseModal}
          >Yes, Reject</Button>
</DialogActions>

 
</Dialog>
    
   
     </React.Fragment>
     );
    })}
        </>


    )
}

export default Pending
