import * as React from 'react'; 
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemAvatar from '@mui/material/ListItemAvatar'; 
import ListItemText from '@mui/material/ListItemText';
import Avatar from '@mui/material/Avatar';
import { Grid, Typography, Button, Box } from '@mui/material';
import { useTheme } from '@mui/material/styles';  
import { Flight, Hotel } from '@mui/icons-material';
import { useQuery } from '@apollo/client'
import { gql } from '@apollo/client'
import { useRouter } from 'next/router'
import Image from 'next/image';

const UPCOMINGTRIPS_QUERY = gql`
  query UpcomingTrips {
    upcomingTrips {
       title
       date
    }
  }
`


interface UpcomingTrips {
    title:string
    date:string
  }
  
  interface UpcomingTripsData {
    upcomingTrips: UpcomingTrips[]
  }
  
 
const Upcoming = () => {
  const theme = useTheme();

  // const [dense, setDense] = React.useState(false);
 
  const [upcomingTrips, setUpcomingTrips] = React.useState<UpcomingTripsData["upcomingTrips"]>([]);
    


const { loading,  data } = useQuery<UpcomingTripsData>(UPCOMINGTRIPS_QUERY);
React.useEffect(() =>{
  if(!loading && data){
    setUpcomingTrips(data.upcomingTrips)

    // setUpcomingTrips([])
    
  }
}, [loading, data])

const router = useRouter();


// const handleSearchFlight = () => {
//   router.push('/travelsearchinner/flightlisting');
// };


  return (
    <>
      <Grid container spacing={2}>

      {setUpcomingTrips.length === 0 ? (
          <Grid item xs={12} sm={6} sx={{margin:'6rem auto 0rem', display:'flex', justifyContent:'center',flexDirection:'column',}}>
                <Image
                style={{margin:'auto'}}
                 src="/images/nullData.png" // Provide the path to your image file in the public directory 
                 width={300}
                 height={250}
                 alt=''
                  />

                <Typography variant="subtitle2" gutterBottom 
                sx={{
                  '&.MuiTypography-root':{ 
                    position:'relative',
                    top:'-4rem',
                    textAlign:'center',
                    color:theme.palette.common.black
                  } 
                }}
                
                >
                Looks empty, you've no completed bookings.
               </Typography>
               <Button variant="contained" 
                     className="borderRadiusButton"  
                     sx={{backgroundColor:theme.palette.secondary.main,
                           marginTop:'1.5rem', 
                           margin:'0 auto',
                           width:'8rem',
                           padding:'8px !important',
                           '&:hover':{
                            background:theme.palette.primary.light
                           }, 
                           minWidth:'auto !important'
                           
                      }}>
                     Plan a Trip
               </Button> 
          </Grid>


) : (
  <Grid item xs={12} md={12}> 
          
  <List >
    {upcomingTrips.map((trip, index) => (
      <ListItem 
        key={index}
        sx={{
          background: theme.palette.common.white,
          marginBottom: '0.5rem'
        }}
        secondaryAction={
          <Button variant="text" 
          onClick = {()=> router.push('/triplisting') }
          sx={{ color: theme.palette.common.black, textTransform: 'capitalize' }}>
            View Details
          </Button>
        }
      > 
        <ListItemText 
          sx={{
            '& .MuiTypography-root': {
              display: 'flex',
              flexWrap: 'wrap',
              alignItems: 'center',
              width: '30%',
              justifyContent: 'space-between'
            }
          }}
        >
          <Typography variant="h6" sx={{ color: theme.palette.common.black, fontSize:'1.125rem !important' }}>
            {trip.title}
          </Typography>
          <Typography variant="body2" gutterBottom sx={{ color: theme.palette.common.black, marginBottom: 0 }}>
            {trip.date}
          </Typography>
          <Box sx={{ display: 'flex' }}>
            <ListItemAvatar>
              <Avatar sx={{ background: '#F5F7FA' }}><Flight sx={{ color: '#687591' }} /></Avatar>
            </ListItemAvatar>
            <ListItemAvatar>
              <Avatar sx={{ background: '#F5F7FA' }}> <Hotel sx={{ color: '#687591' }} /></Avatar>
            </ListItemAvatar>
          </Box>
        </ListItemText>
      </ListItem>
    ))}
  </List>
</Grid>
)}

          
      
      </Grid>
    </>
  );
}

export default Upcoming;
