import * as React from 'react'
import  {  useEffect } from "react";

import Accordion from '@mui/material/Accordion'
import AccordionDetails from '@mui/material/AccordionDetails'
import AccordionSummary from '@mui/material/AccordionSummary'
import Typography from '@mui/material/Typography'
import ExpandMoreIcon from '@mui/icons-material/ExpandMore'
import { Avatar, Button, Box, Grid, FormControl, InputLabel, TextField, OutlinedInput, MenuItem,  } from '@mui/material'
import { Person, CalendarMonth } from '@mui/icons-material'
import { Theme, useTheme } from '@mui/material/styles'
import Select, { SelectChangeEvent } from '@mui/material/Select' 
import { SingleDatePicker } from 'react-dates';
import 'react-dates/initialize';

import 'react-dates/lib/css/_datepicker.css'


const ITEM_HEIGHT = 48
const ITEM_PADDING_TOP = 8

const MenuProps = {
  PaperProps: {
    style: {
      maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
      width: 250
    }
  }
}
const names = ['Male', 'Female']
const nationality = ['Indian', 'America']
function getStyles(name: string, personName: readonly string[], theme: Theme) {
  return {
    fontWeight: personName.indexOf(name) === -1 ? theme.typography.fontWeightRegular : theme.typography.fontWeightMedium
  }
}



const TravelerDetails = ({travelerName, initialExpanded}) => {

 
  const [expanded, setExpanded] = React.useState<string | false>((initialExpanded))
  const [personName, setPersonName] = React.useState<string[]>([])
  const [selectedNationality, setSelectedNationality] = React.useState('')
  const [focused, setFocused] = React.useState(false);
  const [selectedDate, setSelectedDate] = React.useState(null);



  const handleChange = (panel: string) => (event: React.SyntheticEvent, isExpanded: boolean) => {
    setExpanded(isExpanded ? panel : false)
  }

  const handleChangeSelect = (event: SelectChangeEvent<typeof personName>) => {
    const {
      target: { value }
    } = event
    setPersonName(typeof value === 'string' ? value.split(',') : value)
  }

  const handleChangeNationality = (event: SelectChangeEvent<typeof selectedNationality>) => {
    setSelectedNationality(event.target.value as string)
  }

  // const dateFormat = 'DD/MM/YYYY';

  // const placeholderText = moment().format(dateFormat);
  useEffect(() => {
    // You can also set the initial state here
    setExpanded("panel1"); 
  }, []);


  const theme = useTheme()


  return (
    <>
      <Box className='travelerBox'> 
        <Accordion
          expanded={expanded === 'panel1'}
          onChange={handleChange('panel1')}
          sx={{
            boxShadow: 'none',
            '&.Mui-expanded': {
              boxShadow: 'none'
            }
          }}
        >
          <AccordionSummary
            expandIcon={<ExpandMoreIcon />}
            aria-controls='panel1bh-content'
            id='panel1bh-header'
            sx={{ alignItem: 'center', pl: 0 }}
          >
            <Avatar>
              <Person />
            </Avatar>
            <Typography sx={{ width: '20%', flexShrink: 0, fontWeight: '500', ml: 4 }}>
            {travelerName} 
              
              </Typography>
            <Typography sx={{ color: 'text.secondary' }}>
              <Button variant='contained' sx={{ backgroundColor: theme.palette.common.black }}>
                Primary
              </Button>
            </Typography>
          </AccordionSummary>
          <AccordionDetails sx={{ px: 0 }}>
            <Grid container spacing={2}>
              <Grid item xs={6}>
                <FormControl fullWidth>
                  <InputLabel
                    htmlFor='from-input'
                    sx={{
                      transform: 'none',
                      position: 'static',
                      '&.Mui-focused': {
                        color: 'inherit'
                      },
                      marginBottom: '5px'
                    }}
                    disableAnimation
                  >
                    Given Names
                  </InputLabel>
                  <TextField
                    sx={{
                      '& .MuiOutlinedInput-notchedOutline': {
                        borderColor: 'rgba(58, 53, 65, 0.32)',
                        borderWidth: '1px',
                        boxShadow: 'none'
                        
                      },
                      '&:hover .MuiOutlinedInput-notchedOutline': {
                        borderColor: 'rgba(58, 53, 65, 0.32)',
                        borderWidth: '1px'
                      },
                      '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                        borderColor: 'rgba(58, 53, 65, 0.32)',
                        borderWidth: '1px'
                      }
                    }}
                  />
                </FormControl>
              </Grid>
              <Grid item xs={6}>
                <FormControl fullWidth>
                  <InputLabel
                    htmlFor='from-input'
                    sx={{
                      transform: 'none',
                      position: 'static',
                      '&.Mui-focused': {
                        color: 'inherit'
                      },
                      marginBottom: '5px'
                    }}
                    disableAnimation
                  >
                    Surname
                  </InputLabel>
                  <TextField
                    sx={{
                      '& .MuiOutlinedInput-notchedOutline': {
                        borderColor: 'rgba(58, 53, 65, 0.32)',
                        borderWidth: '1px',
                        boxShadow: 'none' 
                      },
                      '&:hover .MuiOutlinedInput-notchedOutline': {
                        borderColor: 'rgba(58, 53, 65, 0.32)',
                        borderWidth: '1px'
                      },
                      '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                        borderColor: 'rgba(58, 53, 65, 0.32)',
                        borderWidth: '1px'
                      }
                    }}
                  />
                </FormControl>
              </Grid>

              <Grid item xs={4}>
                <FormControl fullWidth>
                  <InputLabel
                    htmlFor='from-input'
                    sx={{
                      transform: 'none',
                      position: 'static',
                      '&.Mui-focused': {
                        color: 'inherit'
                      },
                      marginBottom: '5px'
                    }}
                    disableAnimation
                  >
                    Nationality
                  </InputLabel>
                  <Select
                    displayEmpty
                    value={selectedNationality}
                    onChange={handleChangeNationality}
                    input={<OutlinedInput />}
                    renderValue={selected => {
                      if (selected.length === 0) {
                        return <pre>Select</pre>
                      }

                      return selected
                    }}
                    MenuProps={MenuProps}
                    inputProps={{ 'aria-label': 'Without label' }}
                  >
                    {nationality.map(name => (
                      <MenuItem key={name} value={name}>
                        {name}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              </Grid>
              <Grid item xs={4}>
                <FormControl fullWidth>
                  <InputLabel
                    htmlFor='from-input'
                    sx={{
                      transform: 'none',
                      position: 'static',
                      '&.Mui-focused': {
                        color: 'inherit'
                      },
                      marginBottom: '5px'
                    }}
                    disableAnimation
                  >
                    Gender
                  </InputLabel>
                  <Select
                    displayEmpty
                    value={personName}
                    onChange={handleChangeSelect}
                    input={<OutlinedInput />}
                    renderValue={selected => {
                      if (selected.length === 0) {
                        return <pre>Select</pre>
                      }

                      return selected
                    }}
                    MenuProps={MenuProps}
                    inputProps={{ 'aria-label': 'Without label' }}
                  >
                    {/* <MenuItem disabled value="">
            <em>Placeholder</em>
          </MenuItem> */}
                    {names.map(name => (
                      <MenuItem key={name} value={name} style={getStyles(name, personName, theme)}>
                        {name}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              </Grid>
          
              <Grid item xs={4}>
  <FormControl fullWidth>
    <InputLabel
      htmlFor="from-input"
      sx={{
        transform: 'none',
        position: 'static',
        '&.Mui-focused': {
          color: 'inherit',
        },
        marginBottom: '5px',
      }}
      disableAnimation
    >
      Date of birth
    </InputLabel>
    <SingleDatePicker 
      id="date-of-birth-picker"
      placeholder='DD/MM/YYYY'
      date={selectedDate} // Pass the selected date value here
      onDateChange={date => setSelectedDate(date)} // Handle the date change event
      focused={focused}
      onFocusChange={({ focused }) => setFocused(focused)}
      numberOfMonths={1} // Set the number of visible months
      isOutsideRange={() => false} // Allow selecting past dates
      displayFormat='DD/MM/YYYY'// Customize the display format of the selected date 
      customInputIcon={<CalendarMonth />} 
      showDefaultInputIcon={true}
    />
   </FormControl>
   </Grid>
              <Grid item xs={6}>
                <FormControl fullWidth>
                  <InputLabel
                    htmlFor='from-input'
                    sx={{
                      transform: 'none',
                      position: 'static',
                      '&.Mui-focused': {
                        color: 'inherit'
                      },
                      marginBottom: '5px'
                    }}
                    disableAnimation
                  >
                    Mobile No
                  </InputLabel>
                  <TextField
                    sx={{
                      '& .MuiOutlinedInput-notchedOutline': {
                        borderColor: 'rgba(58, 53, 65, 0.32)',
                        borderWidth: '1px',
                        boxShadow: 'none' 

                      },
                      '&:hover .MuiOutlinedInput-notchedOutline': {
                        borderColor: 'rgba(58, 53, 65, 0.32)',
                        borderWidth: '1px'
                      },
                      '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                        borderColor: 'rgba(58, 53, 65, 0.32)',
                        borderWidth: '1px'
                      }
                    }}
                  />
                </FormControl>
              </Grid>
              <Grid item xs={6}>
                <FormControl fullWidth>
                  <InputLabel
                    htmlFor='from-input'
                    sx={{
                      transform: 'none',
                      position: 'static',
                      '&.Mui-focused': {
                        color: 'inherit'
                      },
                      marginBottom: '5px'
                    }}
                    disableAnimation
                  >
                    Email Id
                  </InputLabel>
                  <TextField
                    sx={{
                      '& .MuiOutlinedInput-notchedOutline': {
                        borderColor: 'rgba(58, 53, 65, 0.32)',
                        borderWidth: '1px',
                        boxShadow: 'none'
                        
                      },
                      '&:hover .MuiOutlinedInput-notchedOutline': {
                        borderColor: 'rgba(58, 53, 65, 0.32)',
                        borderWidth: '1px'
                      },
                      '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                        borderColor: 'rgba(58, 53, 65, 0.32)',
                        borderWidth: '1px'
                      }
                    }}
                  />
                </FormControl>
              </Grid>
              <Grid item xs={6}>
                <FormControl fullWidth>
                  <InputLabel
                    htmlFor='from-input'
                    sx={{
                      transform: 'none',
                      position: 'static',
                      '&.Mui-focused': {
                        color: 'inherit'
                      },
                      marginBottom: '5px'
                    }}
                    disableAnimation
                  >
                    Passport or ID number
                  </InputLabel>
                  <TextField
                    sx={{
                      '& .MuiOutlinedInput-notchedOutline': {
                        borderColor: 'rgba(58, 53, 65, 0.32)',
                        borderWidth: '1px',
                        boxShadow: 'none'
                        
                      },
                      '&:hover .MuiOutlinedInput-notchedOutline': {
                        borderColor: 'rgba(58, 53, 65, 0.32)',
                        borderWidth: '1px'
                      },
                      '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                        borderColor: 'rgba(58, 53, 65, 0.32)',
                        borderWidth: '1px'
                      }
                    }}
                  />
                </FormControl>
              </Grid>
              <Grid item xs={6}>
                <FormControl fullWidth>
                  <InputLabel
                    htmlFor='from-input'
                    sx={{
                      transform: 'none',
                      position: 'static',
                      '&.Mui-focused': {
                        color: 'inherit'
                      },
                      marginBottom: '5px'
                    }}
                    disableAnimation
                  >
                    Passport or ID expiration date
                  </InputLabel>
                  <TextField
                    sx={{
                      '& .MuiOutlinedInput-notchedOutline': {
                        borderColor: 'rgba(58, 53, 65, 0.32)',
                        borderWidth: '1px',
                        boxShadow: 'none'
                      
                      },
                      '&:hover .MuiOutlinedInput-notchedOutline': {
                        borderColor: 'rgba(58, 53, 65, 0.32)',
                        borderWidth: '1px'
                      },
                      '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                        borderColor: 'rgba(58, 53, 65, 0.32)',
                        borderWidth: '1px'
                      }
                    }}
                  />
                </FormControl>
              </Grid>
            </Grid>
          </AccordionDetails>
        </Accordion>
      </Box>
    </>
  )
}

export default TravelerDetails
