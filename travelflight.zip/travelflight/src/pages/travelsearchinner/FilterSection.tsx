import { Button, Grid, IconButton, Popover, Box, Card, Typography, Tooltip, Divider } from "@mui/material";
import { ExpandMore, FilterAlt, Close, Add }  from '@mui/icons-material';
import { useState } from 'react';
 import StopsFilter from '../travelsearchinner/FilterSection/StopsFilter';
import AirlinesFilter from "./FilterSection/AirlinesFilter";
import Refundability from "./FilterSection/Refundability";
import Emissions from "./FilterSection/Emissions";
import Policy from "./FilterSection/Policy";
import Prices from "./FilterSection/Prices";
import FlightDuration from "./FilterSection/FlightDuration";
import TimeFilter from "./FilterSection/TimeFilter";
import { useTheme } from '@mui/material/styles'

const FilterSection = () => {
  const [filterAnchorEl, setFilterAnchorEl] = useState(null);
   const [stopsAnchorEl, setStopsAnchorEl] = useState(null);
  const [airlinesAnchorEl, setAirlinesAnchorEl] = useState(null);
  const [timeAnchorEl, setTimeAnchorEl] = useState(null);
  const [flightDurationAnchorEl, setFlightAnchorEl] = useState(null);
  const [priceAnchorEl, setPriceAnchorEl] = useState(null);
  const [refundabilityAnchorEl, setRefundabilityAnchorEl] = useState(null);
  const [emissionsAnchorEl, setEmissionsAnchorEl] = useState(null);
  const [policyAnchorEl, setPolicyAnchorEl] = useState(null);

  const [stopsSelectedValue, setStopsSelectedValue] = useState<string[]>([]);
  const [airlineSelectedValue, setAirlineSelectedValue] = useState<string[]>([]);
  
  const [refundSelectedValue, setRefundSelectedValue] = useState<string[]>([]);
  
  const [emissionSelectedValue, setEmissionSelectedValue] = useState<string[]>([]);

  const [policySelectedValue, setPolicySelectedValue] = useState<string[]>([]);

  const [durationSelectedValue, setDurationSelectedValue] = useState<number>(20);

  const [selectedPriceValue, setSelectedPriceValue] = useState<string>('');
  const [selectedClasses, setSelectedClasses] = useState<string[]>([]);

  

 
  
  const handleStopsSelectedValue = (selectedValue: string[]) => { 
    setStopsSelectedValue(selectedValue);
  };

  const handleAirlineSelectedValue = (selectedValue: string[]) => { 
    setAirlineSelectedValue(selectedValue);
  };

  const handleRefundSelectedValue = (selectedValue: string[]) => { 
    setRefundSelectedValue(selectedValue);
  };

  const handleEmissionSelectedValue = (selectedValue: string[]) => { 
    setEmissionSelectedValue(selectedValue);
  };

  const handlePolicySelectedValue = (selectedValue: string[]) => { 
    setPolicySelectedValue(selectedValue);
  };

  const handleDurationSelectedValue = (selectedValue: number) => {
    setDurationSelectedValue(selectedValue); // Update the selected duration value in the state
  };
  
  const handlePriceSelectedValue = (selectedValue: string) => {
    setSelectedPriceValue(selectedValue);
  };

  const handleFilterClick = (event) => {
    setFilterAnchorEl(event.currentTarget);
  };
  
  const handleSelectedClassesChange = (newSelectedClasses: string[]) => {
    setSelectedClasses(newSelectedClasses);
  };


  // const truncateString = (str, maxChars) => {
  //   return str.length > maxChars ? str.substring(0, maxChars) + '...' : str;
  // };

  // 
  
const handleClearClickStop = () =>{
  if (stopsSelectedValue.length > 0 ) {
      setStopsSelectedValue([]);
      localStorage.removeItem('selectedStops');
    }     
}

const handleClearClickAirline = () =>{ 
     if (airlineSelectedValue.length > 0) {
      setAirlineSelectedValue([]);
      localStorage.removeItem('selectedAirlines');
    }
}

const handleClearClickTime = () => {
  if (selectedClasses.length > 0) { 
    setSelectedClasses([]);
    localStorage.removeItem('selectedTimeClasses');
  }
}

const handleClearClickDuration = () =>{
  if (durationSelectedValue  > 20) { 
    setDurationSelectedValue(20);
    localStorage.removeItem('selectedDuration');
  }

}

const handleClearClickPrice = () =>{
   if(selectedPriceValue ){
    setSelectedPriceValue('');
    localStorage.removeItem('selectedPrice');
   }

}

const handleClearClickRefund = () =>{
  if (refundSelectedValue.length > 0) { 
    setRefundSelectedValue([]);
    localStorage.removeItem('selectedRefunds');
  }

}

const handleClearClickEmission = () =>{
  if (emissionSelectedValue.length > 0) { 
    setEmissionSelectedValue([]);
    localStorage.removeItem('selectedEmissions');
  }

}

const handleClearClickPolicy = () => {
  if (policySelectedValue.length > 0) { 
    setPolicySelectedValue([]);
    localStorage.removeItem('selectedPolicies');
  }

}

  const handleStopsClick = (event) => { 
       setStopsAnchorEl(event.currentTarget);   
  };

  const handleAirlinesClick = (event) => {
    setAirlinesAnchorEl(event.currentTarget);
  };

  const handleTimeClick = (event) => {
    setTimeAnchorEl(event.currentTarget);
  };

  const handleFlightDurationClick = (event) => {
    setFlightAnchorEl(event.currentTarget);
  };

  const handlePriceClick = (event) => {
    setPriceAnchorEl(event.currentTarget);
  };

  const handleRefundabilityClick = (event) => {
    setRefundabilityAnchorEl(event.currentTarget);
  };

  const handleEmissionsClick = (event) => {
    setEmissionsAnchorEl(event.currentTarget);
  };

  const handlePolicyClick = (event) => {
    setPolicyAnchorEl(event.currentTarget);
  };

  const handleFilterClose = () => {
    setFilterAnchorEl(null);
  };

  const handleStopsClose = () => {
    setStopsAnchorEl(null);
    
  };

  const handleAirlinesClose = () => {
    setAirlinesAnchorEl(null);
  };

  const handleTimeClose = () => {
    setTimeAnchorEl(null);
  };

  const handleFlightDurationClose = () => {
    setFlightAnchorEl(null);
  };

  const handlePriceClose = () => {
    setPriceAnchorEl(null);
  };

  const handleRefundabilityClose = () => {
    setRefundabilityAnchorEl(null);
  };

  const handleEmissionsClose = () => {
    setEmissionsAnchorEl(null);
  };

  const handlePolicyClose = () => {
    setPolicyAnchorEl(null);
  };

  const resetAllFilter = () => {
    // const fakeEvent = {}; // Create a fake event object or use an actual event object if available
    // handleClearClick(fakeEvent); // Pass the fake event to handleClearClick
    
    handleClearClickStop()
    handleClearClickAirline()
    handleClearClickTime()
    handleClearClickDuration()
    handleClearClickPrice()
    handleClearClickRefund()
    handleClearClickEmission()
    handleClearClickPolicy()
  } 

  const isFilterPopoverOpen = Boolean(filterAnchorEl);
  const isStopsPopoverOpen = Boolean(stopsAnchorEl);
  const isAirlinesPopoverOpen = Boolean(airlinesAnchorEl);
  const isTimePopoverOpen = Boolean(timeAnchorEl);
  const isFlightDurationPopoverOpen = Boolean(flightDurationAnchorEl);
  const isPricePopoverOpen = Boolean(priceAnchorEl);
  const isRefundabilityPopoverOpen = Boolean(refundabilityAnchorEl);
  const isEmissionsPopoverOpen = Boolean(emissionsAnchorEl);
  const isPolicyPopoverOpen = Boolean(policyAnchorEl);


 

  const theme = useTheme()

  return (
    <>
      <Grid container spacing={3} sx={{ mt: '1rem' }} className="filterSectionMain">
        <Grid container spacing={3} item xs={11}>
        <Grid item>
          <Button variant="outlined" onClick={handleFilterClick}>
            <FilterAlt sx={{color:'#39AAE1'}}/>
          </Button>
          <Popover
            open={isFilterPopoverOpen}
            anchorEl={filterAnchorEl}
            onClose={handleFilterClose}
            anchorOrigin={{
              vertical: 'bottom',
              horizontal: 'center',
            }}
            transformOrigin={{
              vertical: 'top',
              horizontal: 'center',
            }}
          >
            {/* Add the content for the filter popover here */}
            <Card sx={{p:4}}>
            <Box display="flex" justifyContent="space-between" pr={1}>
              <Typography
               component={'h3'}
               sx={{fontWeight:'600'}}
              >
                 Filter
              </Typography>
              <IconButton size="small" onClick={handleFilterClose}  className="boxShadowBox">
                <Close />
              </IconButton>
            </Box>
            
            <Box sx={{position:'relative', 
             '& .filterBox .clearButton':{
               top:'-6px'
             }
           }}>
            <Box display="flex" justifyContent="space-between" pr={1} mt={6}>
              <Typography
               component={'h3'}
               sx={{fontWeight:'600'}}
               >
                 Stops
              </Typography>
              {/* <IconButton size="small" onClick={handleStopsClose}  className="boxShadowBox">
                <Close />
              </IconButton> */}
            </Box>
            <StopsFilter  onStopsClear={handleClearClickStop} onStopsSelectedChange={handleStopsSelectedValue}  /> 
            </Box>
            {/*  */}
            <Box mt={6}>
            <Divider />
            </Box>

            <Box sx={{position:'relative'}}>
            <Box display="flex" justifyContent="space-between" pr={1} mt={6}>
              <Typography
               component={'h3'}
               sx={{fontWeight:'600'}}
               >
                 Airlines
              </Typography>
              {/* <IconButton size="small" onClick={handleAirlinesClose}  className="boxShadowBox">
                <Close />
              </IconButton> */}
            </Box>
             <AirlinesFilter onAirlineClear={handleClearClickAirline} onAirlineSelectedChange={handleAirlineSelectedValue} />
             </Box>

             {/*  */}

             <Box mt={6}>
            <Divider />
            </Box>

            <Box sx={{position:'relative'}}>
            <Box display="flex" justifyContent="space-between" pr={1} mt={6}>
                <Typography component="h3" sx={{ fontWeight: '600' }}>
                  Time
                </Typography>
                {/* <IconButton size="small" onClick={handleTimeClose} className="boxShadowBox">
                  <Close />
                </IconButton> */}
              </Box> 
              <TimeFilter  onSelectedClassesChange={handleSelectedClassesChange}  onClearAll={handleClearClickTime}/>
             </Box>

            <Box mt={6}>
            <Divider />
            </Box>
            {/*  */} 

            <Box sx={{position:'relative'}}>
            <Box display="flex" justifyContent="space-between" pr={1} mt={6}>
                <Typography component="h3" sx={{ fontWeight: '600' }}>
                  Flight Duration
                </Typography>
                {/* <IconButton size="small" onClick={handleFlightDurationClose} className="boxShadowBox">
                  <Close />
                </IconButton> */}
              </Box>
             <FlightDuration   onDurationClear={handleClearClickDuration}  onDurationSelectedChange={handleDurationSelectedValue}/>
            </Box>

            <Box mt={6}>
            <Divider />
            </Box>
            {/*  */} 
            <Box sx={{position:'relative'}}>
            <Box display="flex" justifyContent="space-between" pr={1} mt={6}>
                <Typography component="h3" sx={{ fontWeight: '600' }}>
                  Price
                </Typography>
                {/* <IconButton size="small" onClick={handlePriceClose} className="boxShadowBox">
                  <Close />
                </IconButton> */}
              </Box>
             <Prices onPriceClear={handleClearClickPrice} onPriceSelectedChange={handlePriceSelectedValue} />  
            </Box>
            <Box mt={6}>
            <Divider />
            </Box>
            {/*  */} 
            <Box sx={{position:'relative'}}>
            <Box display="flex" justifyContent="space-between" pr={1} mt={6}>
                <Typography component="h3" sx={{ fontWeight: '600' }}>
                  Refundability
                </Typography>
                {/* <IconButton size="small" onClick={handleRefundabilityClose} className="boxShadowBox">
                  <Close />
                </IconButton> */}
              </Box>
              <Refundability  onRefundClear={handleClearClickRefund} onRefundSelectedChange={handleRefundSelectedValue} />
              </Box> 

            <Box mt={6}>
            <Divider />
            </Box>

            <Box sx={{position:'relative'}}>
            <Box display="flex" justifyContent="space-between" pr={1} mt={6}>
                <Typography component="h3" sx={{ fontWeight: '600' }}>
                  Emissions
                </Typography>
                {/* <IconButton size="small" onClick={handleEmissionsClose} className="boxShadowBox">
                  <Close />
                </IconButton> */}
              </Box>
              <Emissions onEmissionClear={handleClearClickEmission} onEmissionSelectedChange={handleEmissionSelectedValue} />
              </Box>

              <Box mt={6}>
            <Divider />
            </Box>

            <Box sx={{position:'relative'}}>
            <Box display="flex" justifyContent="space-between" pr={1} mt={6}>
                <Typography component="h3" sx={{ fontWeight: '600' }}>
                  Policy
                </Typography>
                {/* <IconButton size="small" onClick={handlePolicyClose} className="boxShadowBox">
                  <Close />
                </IconButton> */}
              </Box>
              <Policy onPolicyClear={handleClearClickPolicy}  onPolicySelectedChange={handlePolicySelectedValue}  />

            </Box>
            
  
            </Card>

          


          </Popover>
        </Grid>
        <Grid item> 

           {/* <Tooltip
            title={stopsSelectedValue.length > 1 ? stopsSelectedValue.join(', ') : ''}
            placement="bottom-start"
            classes={{ tooltip: "tooltipBox1" }}  
          >
            <Button variant="outlined" endIcon={<ExpandMore />} onClick={handleStopsClick}>
              {stopsSelectedValue.length > 0 ? stopsSelectedValue[0] : 'Stops'}
              {/* {stopsSelectedValue.length > 0
              ? truncateString(stopsSelectedValue.join(', '), 4) // Adjust '4' to the desired number of characters
              : 'Stops'} 
              
            </Button>
          </Tooltip> */}

          

        {stopsSelectedValue.length > 0 ? (
            <Tooltip
            title={stopsSelectedValue.length > 1 ? stopsSelectedValue.join(', ') : ''} 
             placement="bottom-start" classes={{ tooltip: "tooltipBox1" }}  >
              <Button sx={{
                '&.MuiButtonBase-root':{
                  borderColor:theme.palette.primary.light, 
                  color:theme.palette.primary.light
                },
               
              }}
                variant="outlined" endIcon={<Close onClick={handleClearClickStop}  />} onClick={handleStopsClick}  data-ignore="true" >
                {stopsSelectedValue[0]}
                <Add sx={{'&.MuiSvgIcon-root':{
                     fontSize:'12px'
                }}}/>
              {stopsSelectedValue.length}
              </Button>
            </Tooltip>
          ) : (
            <Tooltip
              title={stopsSelectedValue.length > 1 ? stopsSelectedValue.join(', ') : ''}
              placement="bottom-start"
              classes={{ tooltip: "tooltipBox1" }}  
            >
              <Button variant="outlined" endIcon={<ExpandMore />} onClick={handleStopsClick}>
                {stopsSelectedValue.length > 0 ? stopsSelectedValue[0] : 'Stops'}
                
              </Button>
            </Tooltip>
          )}

          <Popover
            open={isStopsPopoverOpen}
            anchorEl={stopsAnchorEl}
            onClose={handleStopsClose}
            anchorOrigin={{
              vertical: 'bottom',
              horizontal: 'center',
            }}
            transformOrigin={{
              vertical: 'top',
              horizontal: 'center',
            }}
          >
            <Card sx={{p:4,minWidth:'21.125rem'}}>
            <Box display="flex" justifyContent="space-between" pr={1}>
              <Typography
               component={'h3'}
               sx={{fontWeight:'600'}}
               >
                 Stops
              </Typography>
              {/* <IconButton size="small" onClick={handleStopsClose}  className="boxShadowBox">
                <Close />
              </IconButton> */}
            </Box>
            <StopsFilter onStopsClear={handleClearClickStop} onStopsSelectedChange={handleStopsSelectedValue}   /> 
            </Card>
          </Popover>
          
        </Grid>
        <Grid item>
          {/* <Button variant="outlined" endIcon={<ExpandMore />} onClick={handleAirlinesClick}>
            Airlines
          </Button> */}


         {airlineSelectedValue.length > 0 ? (
            <Tooltip
            title={airlineSelectedValue.length > 1 ? airlineSelectedValue.join(', ') : ''} 
             placement="bottom-start" classes={{ tooltip: "tooltipBox1" }}  >
              <Button 
               sx={{
                '&.MuiButtonBase-root':{
                  borderColor:theme.palette.primary.light, 
                  color:theme.palette.primary.light
                },
               
              }}
              variant="outlined" endIcon={<Close onClick={handleClearClickAirline}  />} onClick={handleAirlinesClick}  >
                {airlineSelectedValue[0]}
                <Add sx={{'&.MuiSvgIcon-root':{
                     fontSize:'12px'
                }}}/>
              {airlineSelectedValue.length}
              </Button>
            </Tooltip>
          ) : (
            <Tooltip
              title={airlineSelectedValue.length > 1 ? airlineSelectedValue.join(', ') : ''}
              placement="bottom-start"
              classes={{ tooltip: "tooltipBox1" }}  
            >
              <Button variant="outlined" endIcon={<ExpandMore />} onClick={handleAirlinesClick}>
                {airlineSelectedValue.length > 0 ? airlineSelectedValue[0] : 'Airlines'}
              </Button>
            </Tooltip>
          )}



          <Popover
            open={isAirlinesPopoverOpen}
            anchorEl={airlinesAnchorEl}
            onClose={handleAirlinesClose}
            anchorOrigin={{
              vertical: 'bottom',
              horizontal: 'center',
            }}
            transformOrigin={{
              vertical: 'top',
              horizontal: 'center',
            }}
          >
             <Card sx={{p:4,minWidth:'21.125rem'}} >
            <Box display="flex" justifyContent="space-between" pr={1}>
              <Typography
               component={'h3'}
               sx={{fontWeight:'600'}}
               >
                 Airlines
              </Typography>
              {/* <IconButton size="small" onClick={handleAirlinesClose}  className="boxShadowBox">
                <Close />
              </IconButton> */}
            </Box>
             <AirlinesFilter  onAirlineClear={handleClearClickAirline} onAirlineSelectedChange={handleAirlineSelectedValue} />

            </Card>
          </Popover>
        </Grid>
        <Grid item>
          {/* <Button variant="outlined" endIcon={<ExpandMore />} onClick={handleTimeClick}>
            Time
            /* {selectedClasses.join(", ")} *
          </Button> */}

          {/* {selectedClasses  ? ( */}
              
          {selectedClasses.length > 0 ? (
              <Tooltip
            title={selectedClasses.length > 1 ? selectedClasses.join(', ') : ''} 
            placement="bottom-start" classes={{ tooltip: "tooltipBox1" }}  >
             <Button variant="outlined"
               sx={{
                '&.MuiButtonBase-root':{
                  borderColor:theme.palette.primary.light, 
                  color:theme.palette.primary.light
                },
               }}
             endIcon={<Close onClick={handleClearClickTime}  />} 
             onClick={handleTimeClick}  >
             {selectedClasses[0]} 
             <Add sx={{'&.MuiSvgIcon-root':{
                     fontSize:'12px'
                }}}/>
             {selectedClasses.length}
             </Button>
           </Tooltip>

         ) : (
           <Tooltip
           title={selectedClasses.length > 1 ? selectedClasses.join(', ') : ''}  
             placement="bottom-start"
             classes={{ tooltip: "tooltipBox1" }}  
           >
             <Button variant="outlined" endIcon={<ExpandMore />} onClick={handleTimeClick}> 
               {selectedClasses.length > 0 ? selectedClasses[0] : 'Time'}
             </Button>
           </Tooltip>
         )}


          <Popover
            open={isTimePopoverOpen}
            anchorEl={timeAnchorEl}
            onClose={handleTimeClose}
            anchorOrigin={{
              vertical: 'bottom',
              horizontal: 'center',
            }}
            transformOrigin={{
              vertical: 'top',
              horizontal: 'center',
            }}
          >
            <Card sx={{ p: 4 }}>
              <Box display="flex" justifyContent="space-between" pr={1}>
                <Typography component="h3" sx={{ fontWeight: '600' }}>
                  Time
                </Typography>
                {/* <IconButton size="small" onClick={handleTimeClose} className="boxShadowBox">
                  <Close />
                </IconButton> */}
              </Box> 
              <TimeFilter  onSelectedClassesChange={handleSelectedClassesChange} onClearAll={handleClearClickTime}/>
            </Card>
          </Popover>
        </Grid>
        <Grid item>
          {/* <Button variant="outlined" endIcon={<ExpandMore />} onClick={handleFlightDurationClick}>
            Flight Duration
            {durationSelectedValue}
          </Button> */}

          {durationSelectedValue > 20 ? (
            <Tooltip
            title={durationSelectedValue > 20 ? `up to ${durationSelectedValue} hr` : ''} 
           
             placement="bottom-start" classes={{ tooltip: "tooltipBox1" }}  >
              <Button variant="outlined" 
                sx={{
                  '&.MuiButtonBase-root':{
                    borderColor:theme.palette.primary.light, 
                    color:theme.palette.primary.light
                  },
                 }}
              endIcon={<Close onClick={handleClearClickDuration}  />} onClick={handleFlightDurationClick}  >
              {`up to ${durationSelectedValue} hr`} 
              </Button>
            </Tooltip>
          ) : (
            <Tooltip
            title={durationSelectedValue > 20 ? `up to ${durationSelectedValue} hr` : ''} 
           
              placement="bottom-start"
              classes={{ tooltip: "tooltipBox1" }}  
            >
              <Button variant="outlined" endIcon={<ExpandMore />} onClick={handleFlightDurationClick}>
                {durationSelectedValue > 20 ? `up to ${durationSelectedValue} hr` : 'Flight Duration'}
              </Button>
            </Tooltip>
          )}


          <Popover
            open={isFlightDurationPopoverOpen}
            anchorEl={flightDurationAnchorEl}
            onClose={handleFlightDurationClose}
            anchorOrigin={{
              vertical: 'bottom',
              horizontal: 'center',
            }}
            transformOrigin={{
              vertical: 'top',
              horizontal: 'center',
            }}
          >
            <Card sx={{p:4,minWidth:'21.125rem'}}>
              <Box display="flex" justifyContent="space-between" pr={1}>
                <Typography component="h3" sx={{ fontWeight: '600' }}>
                  Flight Duration
                </Typography>
                {/* <IconButton size="small" onClick={handleFlightDurationClose} className="boxShadowBox">
                  <Close />
                </IconButton> */}
              </Box>
             <FlightDuration  onDurationClear={handleClearClickDuration} onDurationSelectedChange={handleDurationSelectedValue}/>
            </Card>
          </Popover>
        </Grid>
        <Grid item>
          {/* <Button variant="outlined" endIcon={<ExpandMore />} onClick={handlePriceClick}>
            Price
            {selectedPriceValue}
          </Button> */}
          {selectedPriceValue  ? (
              
               <Tooltip
            title={selectedPriceValue} 
           
             placement="bottom-start" classes={{ tooltip: "tooltipBox1" }}  >
              <Button variant="outlined" 
               sx={{
                '&.MuiButtonBase-root':{
                  borderColor:theme.palette.primary.light, 
                  color:theme.palette.primary.light
                },
               }}
              endIcon={<Close onClick={handleClearClickPrice}  />} onClick={handlePriceClick}  >
              {selectedPriceValue} 
              </Button>
            </Tooltip>

          ) : (
            <Tooltip
            title={selectedPriceValue} 
           
              placement="bottom-start"
              classes={{ tooltip: "tooltipBox1" }}  
            >
              <Button variant="outlined" endIcon={<ExpandMore />} onClick={handlePriceClick}>
                Price
              </Button>
            </Tooltip>
          )}
          <Popover
            open={isPricePopoverOpen}
            anchorEl={priceAnchorEl}
            onClose={handlePriceClose}
            anchorOrigin={{
              vertical: 'bottom',
              horizontal: 'center',
            }}
            transformOrigin={{
              vertical: 'top',
              horizontal: 'center',
            }}
          >
            <Card sx={{p:4,minWidth:'21.125rem'}}>
              <Box display="flex" justifyContent="space-between" pr={1}>
                <Typography component="h3" sx={{ fontWeight: '600' }}>
                  Price
                </Typography>
                {/* <IconButton size="small" onClick={handlePriceClose} className="boxShadowBox">
                  <Close />
                </IconButton> */}
              </Box>
             <Prices  onPriceClear={handleClearClickPrice} onPriceSelectedChange={handlePriceSelectedValue} />  
            </Card>
          </Popover>
        </Grid>
        <Grid item>
          {/* <Button variant="outlined" endIcon={<ExpandMore />} onClick={handleRefundabilityClick}>
            Refundability
          </Button> */}

         {refundSelectedValue.length > 0 ? (
            <Tooltip
            title={refundSelectedValue.length > 1 ? refundSelectedValue.join(', ') : ''} 
             placement="bottom-start" classes={{ tooltip: "tooltipBox1" }}  >
              <Button sx={{
                '&.MuiButtonBase-root':{
                  borderColor:theme.palette.primary.light, 
                  color:theme.palette.primary.light
                },
               
              }}
               variant="outlined" endIcon={<Close onClick={handleClearClickRefund}  />} onClick={handleRefundabilityClick}  >
                {refundSelectedValue[0]}
                <Add sx={{'&.MuiSvgIcon-root':{
                     fontSize:'12px'
                }}}/>
              {refundSelectedValue.length}
              </Button>
            </Tooltip>
          ) : (
            <Tooltip
              title={refundSelectedValue.length > 1 ? refundSelectedValue.join(', ') : ''}
              placement="bottom-start"
              classes={{ tooltip: "tooltipBox1" }}  
            >
              <Button variant="outlined" endIcon={<ExpandMore />} onClick={handleRefundabilityClick}>
                {refundSelectedValue.length > 0 ? refundSelectedValue[0] : 'Refundablity'}
              </Button>
            </Tooltip>
          )}


          <Popover
            open={isRefundabilityPopoverOpen}
            anchorEl={refundabilityAnchorEl}
            onClose={handleRefundabilityClose}
            anchorOrigin={{
              vertical: 'bottom',
              horizontal: 'center',
            }}
            transformOrigin={{
              vertical: 'top',
              horizontal: 'center',
            }}
          >
            <Card sx={{p:4,minWidth:'21.125rem'}}>
              <Box display="flex" justifyContent="space-between" pr={1}>
                <Typography component="h3" sx={{ fontWeight: '600' }}>
                  Refundability
                </Typography>
                {/* <IconButton size="small" onClick={handleRefundabilityClose} className="boxShadowBox">
                  <Close />
                </IconButton> */}
              </Box>
              <Refundability   onRefundClear={handleClearClickRefund}  onRefundSelectedChange={handleRefundSelectedValue} />
            </Card>
          </Popover>
        </Grid>
        <Grid item>
          {/* <Button variant="outlined" endIcon={<ExpandMore />} onClick={handleEmissionsClick}>
            Emissions
          </Button> */}
          {emissionSelectedValue.length > 0 ? (
            <Tooltip
            title={emissionSelectedValue.length > 1 ? emissionSelectedValue.join(', ') : ''} 
             placement="bottom-start" classes={{ tooltip: "tooltipBox1" }}  >
              <Button  sx={{
                '&.MuiButtonBase-root':{
                  borderColor:theme.palette.primary.light, 
                  color:theme.palette.primary.light
                },
              }} 
               variant="outlined" endIcon={<Close onClick={handleClearClickEmission}  />} onClick={handleEmissionsClick}  >
                {emissionSelectedValue[0]}
                <Add sx={{'&.MuiSvgIcon-root':{
                     fontSize:'12px'
                }}}/>
              {emissionSelectedValue.length}
              </Button>
            </Tooltip>
          ) : (
            <Tooltip
              title={emissionSelectedValue.length > 1 ? emissionSelectedValue.join(', ') : ''}
              placement="bottom-start"
              classes={{ tooltip: "tooltipBox1" }}  
            >
              <Button variant="outlined" endIcon={<ExpandMore />} onClick={handleEmissionsClick}>
                {emissionSelectedValue.length > 0 ? emissionSelectedValue[0] : 'Emissions'}
              </Button>
            </Tooltip>
          )}
          <Popover
            open={isEmissionsPopoverOpen}
            anchorEl={emissionsAnchorEl}
            onClose={handleEmissionsClose}
            anchorOrigin={{
              vertical: 'bottom',
              horizontal: 'center',
            }}
            transformOrigin={{
              vertical: 'top',
              horizontal: 'center',
            }}
          >
            <Card sx={{p:4,minWidth:'21.125rem'}}>
              <Box display="flex" justifyContent="space-between" pr={1}>
                <Typography component="h3" sx={{ fontWeight: '600' }}>
                  Emissions
                </Typography>
                {/* <IconButton size="small" onClick={handleEmissionsClose} className="boxShadowBox">
                  <Close />
                </IconButton> */}
              </Box>
              <Emissions onEmissionClear={handleClearClickEmission}  onEmissionSelectedChange={handleEmissionSelectedValue} />
            </Card>
          </Popover>
        </Grid>
        <Grid item>
          {/* <Button variant="outlined" endIcon={<ExpandMore />} onClick={handlePolicyClick}>
            Policy
          </Button> */}

        {policySelectedValue.length > 0 ? (
            <Tooltip
            title={policySelectedValue.length > 1 ? policySelectedValue.join(', ') : ''} 
             placement="bottom-start" classes={{ tooltip: "tooltipBox1" }}  >
              <Button variant="outlined" 
              sx={{
                '&.MuiButtonBase-root':{
                  borderColor:theme.palette.primary.light, 
                  color:theme.palette.primary.light
                },
               
              }}
              endIcon={<Close onClick={handleClearClickPolicy}  />} onClick={handlePolicyClick}  >
                {policySelectedValue[0]}
                <Add sx={{'&.MuiSvgIcon-root':{
                     fontSize:'12px'
                }}}/>
              {policySelectedValue.length}
              </Button>
            </Tooltip>
          ) : (
            <Tooltip
              title={policySelectedValue.length > 1 ? policySelectedValue.join(', ') : ''}
              placement="bottom-start"
              classes={{ tooltip: "tooltipBox1" }}  
            >
              <Button variant="outlined" endIcon={<ExpandMore />} onClick={handlePolicyClick}>
                {policySelectedValue.length > 0 ? policySelectedValue[0] : 'Policy'}
              </Button>
            </Tooltip>
          )}
          <Popover
            open={isPolicyPopoverOpen}
            anchorEl={policyAnchorEl}
            onClose={handlePolicyClose}
            anchorOrigin={{
              vertical: 'bottom',
              horizontal: 'center',
            }}
            transformOrigin={{
              vertical: 'top',
              horizontal: 'center',
            }}
          >
           <Card sx={{p:4,minWidth:'21.125rem'}}>
              <Box display="flex" justifyContent="space-between" pr={1}>
                <Typography component="h3" sx={{ fontWeight: '600' }}>
                  Policy
                </Typography>
                {/* <IconButton size="small" onClick={handlePolicyClose} className="boxShadowBox">
                  <Close />
                </IconButton> */}
              </Box>
              <Policy onPolicyClear={handleClearClickPolicy} onPolicySelectedChange={handlePolicySelectedValue}  />
            </Card>
          </Popover>
        </Grid>
        </Grid>
        <Grid item >
          <Button variant="text" onClick={resetAllFilter}>
             Reset
          </Button>
        </Grid>
       
      </Grid>
    </>
  );
}

export default FilterSection;
