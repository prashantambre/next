
// ** MUI Imports
import Box from '@mui/material/Box'
import { Theme } from '@mui/material/styles'
import TextField from '@mui/material/TextField'
import IconButton from '@mui/material/IconButton'
import useMediaQuery from '@mui/material/useMediaQuery'
import InputAdornment from '@mui/material/InputAdornment' 
import VerticalNavHeader from 'src/@core/layouts/components/vertical/navigation/VerticalNavHeader'

// ** Icons Imports
// import CurrencyRupeeIcon from '@mui/icons-material/CurrencyRupee'; 
import Menu from 'mdi-material-ui/Menu'
import Magnify from 'mdi-material-ui/Magnify' 

// import { styled } from '@mui/material/styles'

import { useTheme } from '@mui/material/styles'

// ** Type Import
import { Settings } from 'src/@core/context/settingsContext'

// ** Components
import UserDropdown from 'src/@core/layouts/components/shared-components/UserDropdown'
import LanguageDropdown from 'src/@core/layouts/components/shared-components/LanguageDropdown'
import NotificationDropdown from 'src/@core/layouts/components/shared-components/NotificationDropdown'

// import Typography from '@mui/material/Typography'

// import { TypographyProps } from '@mui/material/Typography' 


// import dynamic from 'next/dynamic'

import WalletDropdown from 'src/@core/layouts/components/shared-components/WalletDropdown'

// import Paper from '@mui/material/Paper';

// Dynamically import the Typography component  

// const Typography = dynamic(() => import('@mui/material/Typography'), {
//   ssr: false // Set `ssr` option to `false` to prevent hydration errors
// })

// import { IntlProvider,FormattedMessage } from 'react-intl';

import CurrencyDropdown from 'src/@core/layouts/components/shared-components/CurrencyDropdown'
import { Grid } from '@mui/material'

import InnerMenu from './InnerMenu'

interface Props {
  hidden: boolean
  settings: Settings
  toggleNavVisibility: () => void
  saveSettings: (values: Settings) => void
}

// const MenuItemTitle = styled(Typography)<TypographyProps>(({ theme }) => ({
//   fontWeight: 600,
//   flex: '1 1 100%',
//   overflow: 'hidden',
//   fontSize: '0.875rem',
//   whiteSpace: 'nowrap',
//   textOverflow: 'ellipsis',
//   marginBottom: theme.spacing(0.75)
// }))

// const Item = styled(Paper)(({ theme }) => ({
//   backgroundColor: theme.palette.mode === 'dark' ? '#1A2027' : '#fff',
//   ...theme.typography.body2,
//   padding: theme.spacing(1),
//   textAlign: 'center',
//   color: theme.palette.text.secondary,
// }));


const AppBarContent = (props: Props) => {
  // ** Props
  // const { hidden, settings, saveSettings, toggleNavVisibility } = props

  const {  toggleNavVisibility } = props

  // ** Hook
  const theme = useTheme()
  const hiddenSm = useMediaQuery((theme: Theme) => theme.breakpoints.down('sm'))

  return (
    <>
    
    <Grid container spacing={2}>
    <Grid item xs={12}>
    <Box sx={{ width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap:'wrap' }}>
      <Box className='actions-left' sx={{ mr: 2, display: 'flex', alignItems: 'center' }}>
        {/* {hidden ? ( */}
          <IconButton
            color='inherit'
            onClick={toggleNavVisibility}
            sx={{ ml: -2.75, ...(hiddenSm ? {} : { mr: 3.5 }) }}
            
          >
            <Menu />
          </IconButton>
        {/* ) : null} */}
         <VerticalNavHeader {...props} /> 
         <LanguageDropdown/>
         <CurrencyDropdown/>
      </Box>
      <Box sx={{ mx: 'auto' }}>
        <TextField 
          size='small' 
          sx={{ 
            '& .MuiOutlinedInput-root': { 
              borderRadius: 21.5,
              boxShadow: '0px 0px 20px rgba(22, 22, 22, 0.08)', // add box shadow
              paddingLeft:'6px',
              width:{xs:'30rem',sm:'17rem',md:'30rem'},
              '&:hover:not(.Mui-disabled)': { // remove hover color
                borderColor: 'transparent'
              },
              '&.Mui-focused .MuiOutlinedInput-notchedOutline': { // remove focus color
                borderColor: 'transparent'
              }
            },
            '& .MuiSvgIcon-root': { // add background color to search icon
              backgroundColor: '#F0971A',
              borderRadius:'50%',
              width:'30px',
              height:'30px',
              padding:'4px',
              color:'#fff'
            },
            '& .MuiOutlinedInput-notchedOutline':{
              borderColor:'transparent'
            },
            [theme.breakpoints.down('sm')]: {
              '& .MuiOutlinedInput-root': {
                width: '11rem'
              }
            }
             
          }}
          InputProps={{
            startAdornment: (
              <InputAdornment position='start'>
                <Magnify fontSize='small' />
              </InputAdornment>
            )
          }}
        />
        </Box>
      <Box className='actions-right' sx={{ display: 'flex', alignItems: 'center' }}>

        {/* {hiddenSm ? null : (
          <Typography sx={{ mr: 10, display: 'flex' }} variant='h6'>
            <FormattedMessage id='WELCOME_MSG' defaultMessage='Welcome {name},' values={{ name: 'Rupesh' }} />
          </Typography>
        )} */}
        
        <WalletDropdown />
        <NotificationDropdown />
        {/* <UserDropdown settings={settings} saveSettings={saveSettings} />
      */}

        <UserDropdown />

      </Box>
    </Box>
     </Grid>
     <Grid item xs={12} sx={{ width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', flexWrap:'wrap' }}>
        <InnerMenu/>
     </Grid>
    </Grid>
    </>
  )
}

export default AppBarContent
